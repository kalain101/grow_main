<?php get_header(); ?>

		<main>
			<?php $about_banner = get_theme_mod( 'gfjp_bs3_about_banner_image_setting', GFJP_IMG_URL. '/banner_pc.png' );  ?>
			<section class="banner aligncenter white_txt" style="background-image: url(<?php echo ( is_int( $about_banner ) )? wp_get_attachment_url( $about_banner ) : $about_banner;?>);">
				<h1><?php echo get_theme_mod('gfjp_bs3_about_banner_title_setting','We are Grow')?></h1>
			</section>

			<div class="about" id="about">
				<div class="maxwidth flex itemcenter">
					<?php $ab_img = get_theme_mod( 'gfjp_bs3_about_entry_image_setting', GFJP_IMG_URL. '/about.png' );  ?>
					<img class="desktop_ab" src="<?php echo ( is_int( $ab_img ) )? wp_get_attachment_url( $ab_img ) : $ab_img; ?>" alt="">
					<section> 
						<h2><?php echo get_theme_mod('gfjp_bs3_about_entry_title_setting','We are a team of expert people with creative ideas')?></h2>
						<?php echo wpautop(get_theme_mod('gfjp_bs3_about_entry_desc_setting','Cum tempus tristique pellentesque vulputate euismod at in sit at. Ac augue orci platea egestas eros, quis nisl sit. Lobortis integer sed facilisis neque. Tortor, sagittis massa magna odio egestas sodales tincidunt. Diam consectetur interdum dolor tincidunt proin lectus turpis eu.

						Lectus risus cursus pharetra, quis venenatis a facilisis turpis. Diam lectus mauris auctor massa adipiscing vulputate tortor dapibus nam. Tristique quam ut diam interdum aenean pulvinar in eget. Aliquet cursus in mauris ultrices bibendum leo malesuada. Pellentesque erat maecenas integer et bibendum. Odio sit id arcu, sit quis justo molestie mi. Nisi in dis velit lectus. Pretium neque facilisi rhoncus dui, egestas integer aliquet nunc.'));?>
					</section>
					<img class="mobile_ab" src="<?php echo ( is_int( $ab_img ) )? wp_get_attachment_url( $ab_img ) : $ab_img; ?>" alt="">
				</div>
			</div>

			<div class="expertise">
				<div class="maxwidth flex">
					<section class="left_expertise">
						<h2><?php echo get_theme_mod('gfjp_bs3_about_expertise_title_setting','Our Expertise')?></h2>
						<p><?php echo get_theme_mod('gfjp_bs3_about_expertise_content_setting','Mollis pulvinar in ornare ipsum elit. Eget amet est semper fames fermentum at dis quisque purus.')?></p>
					</section>
					<ul class="bar_ab">
						<li class="bar_marketing">
							<p class="bar_label"><?php echo get_theme_mod('gfjp_bs3_about_progress1_title_setting','Marketing')?></p>
							<p class="bar_percent" style="right: calc(99% - <?php echo get_theme_mod('gfjp_bs3_about_progress1_value_setting','92')?>%);"><?php echo get_theme_mod('gfjp_bs3_about_progress1_value_setting','92')?>%</p>
							<p class="bar_base">
								<span class="bar_rate" style="width: <?php echo get_theme_mod('gfjp_bs3_about_progress1_value_setting','92')?>%;"></span>
							</p>
						</li>
						<li class="bar_development">
							<p class="bar_label"><?php echo get_theme_mod('gfjp_bs3_about_progress2_title_setting','Development')?></p>
							<p class="bar_percent" style="right: calc(99% - <?php echo get_theme_mod('gfjp_bs3_about_progress2_value_setting','87')?>%);"><?php echo get_theme_mod('gfjp_bs3_about_progress2_value_setting','87')?>%</p>
							<p class="bar_base">
								<span class="bar_rate" style="width: <?php echo get_theme_mod('gfjp_bs3_about_progress2_value_setting','87')?>%;"></span>
							</p>
						</li>
						<li class="bar_design">
							<p class="bar_label"><?php echo get_theme_mod('gfjp_bs3_about_progress3_title_setting','Design')?></p>
							<p class="bar_percent" style="right: calc(99% - <?php echo get_theme_mod('gfjp_bs3_about_progress3_value_setting','90')?>%);"><?php echo get_theme_mod('gfjp_bs3_about_progress3_value_setting','90')?>%</p>
							<p class="bar_base">
								<span class="bar_rate" style="width: <?php echo get_theme_mod('gfjp_bs3_about_progress3_value_setting','90')?>%;"></span>
							</p>
						</li>
					</ul>
				</div>
			</div>

			<div class="meet_team">
				<div class="wrap_team">
					<section class="left_team white_txt">
						<h2><?php echo get_theme_mod('gfjp_bs3_about_team_title_setting','Meet our team')?></h2>
						<p><?php echo get_theme_mod('gfjp_bs3_about_team_content_setting','We are dedicated staffs who work efficiently and effectively to deliver you high quality products and services.')?></p>
					</section>

					<div class="slick_team">

						<?php
                        $team_list_args = array(
                            'posts_per_page' => -1,
                            'post_type'     => 'teams',
                        );
                        $team_list_query = new WP_Query( $team_list_args );

                        if( $team_list_query->have_posts() ){
                            while( $team_list_query->have_posts() ){
                            $team_list_query->the_post(); 
                                if( has_post_thumbnail(get_the_ID()) ) {
                                    $team_featured_img_arr = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'team_image_size');
                                    $team_featured_img = $team_featured_img_arr[0];
                                } else {
                                    $team_featured_img = GFJP_IMG_URL .'/proj_1.png';
                                } ?>
                                <div class="team_slides">
									<img src="<?php echo $team_featured_img ?>" alt="">
									<div class="team_content">
										<p><?php echo get_the_title();?></p>
										<p><?php echo get_post_meta( get_the_id(), 'positions', true ); ?></p>
									</div>
								</div>
                                <?php
                            }
                            wp_reset_postdata();
                        } else {
                            echo '<p class="aligncenter white_txt">No team found</p>';
                        } ?>

					</div>
				</div>
			</div>

			<div class="testimony">
				<section class="maxwidth">
					<h2 class="aligncenter"><?php echo get_theme_mod('gfjp_bs3_about_testimonial_title_setting','What our Clients say')?></h2>
					<div class="slick_testimony">
						<?php
                        $testimonials_list_args = array(
                            'posts_per_page' => -1,
                            'post_type'     => 'testimonials',
                        );
                        $testimonials_list_query = new WP_Query( $testimonials_list_args );

                        if( $testimonials_list_query->have_posts() ){
                            while( $testimonials_list_query->have_posts() ){
                                $testimonials_list_query->the_post(); 
                                $testimonials_img = ( has_post_thumbnail( get_the_id() ) )? get_the_post_thumbnail_url() : GFJP_IMG_URL .'/profile_1.png';
                                ?>
                                <div>
                                    <div class="testimonial_wrap flex">
                                        <div class="testimonials_image">
                                            <img src="<?php echo $testimonials_img?>" alt="">
                                        </div>
                                        <div class="testimonial_content">
                                            <p class="testimonials">“<?php echo get_the_content();?>”</p>
                                            <p class="testimonial_name"><?php echo get_the_title();?></p>
                                            <p class="testimonial_position"><?php echo get_post_meta( get_the_id(), 'position', true ); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            wp_reset_postdata();
                        } else {
                            echo 'No testimonials found';
                        } ?>
					</div>
				</section>
			</div>

		</main>

<?php get_footer(); ?>