
$(function(){
    $('.slick_testimony').slick({
        autoplay: true,
        adaptiveHeight:false,
        autoplaySpeed: 6000,
        speed: 600,
        pauseOnHover: true,
        pauseOnDotsHover: true,
        cssEase: 'ease',
        dots: false,
        fade: false,
        slidesToShow: 2,
        centerMode: false,
        centerPadding: '20px',
        slidesToScroll: 2,
        infinite: true,
        swipe: true,
        vertical: false,
        prevArrow: '<span class="testimonial_arrow left_arrow"><div class="iconify" data-icon="carbon:arrow-left" data-inline="false"></span>',
        nextArrow: '<span class="testimonial_arrow right_arrow"><div class="iconify" data-icon="carbon:arrow-right" data-inline="false"></span>',
        arrows: true,
        responsive: [
            {
                breakpoint: 769,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 641,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            },
        ]
    });
});

$(function(){
    $('.slick_team').slick({
        autoplay: true,
        adaptiveHeight:false,
        autoplaySpeed: 5000,
        speed: 600,
        pauseOnHover: true,
        pauseOnDotsHover: true,
        cssEase: 'ease',
        dots: false,
        dotsClass: 'slick-dots',
        fade: false,
        slidesToShow: 4,
        centerPadding: '20px',
        slidesToScroll: 1,
        infinite: true,
        swipe: true,
        vertical: false,
        arrows: false,
        variableWidth: true
    });
});