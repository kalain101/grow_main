$(function(){

    $('.slick_banner').slick({
        autoplay: true,
        adaptiveHeight:false,
        autoplaySpeed: 5000,
        speed: 600,
        pauseOnHover: true,
        pauseOnDotsHover: true,
        cssEase: 'ease',
        dots: false,
        dotsClass: 'slick-dots',
        fade: false,
        slidesToShow: 1,
        centerMode: false,
        centerPadding: '20px',
        slidesToScroll: 1,
        infinite: true,
        initialSlide: -1,
        swipe: true,
        vertical: false,
        prevArrow: '<span class="sliders-arrow left-arrow slick-arrow"><div class="iconify" data-icon="carbon:arrow-left" data-inline="false"></div></span>',
        nextArrow: '<span class="sliders-arrow right-arrow slick-arrow"><div class="iconify" data-icon="carbon:arrow-right" data-inline="false"></div></span>',
        arrows: true
    });

    $('.slick_testimony_a').slick({
        autoplay: true,
        adaptiveHeight:false,
        autoplaySpeed: 1000,
        speed: 600,
        pauseOnHover: true,
        pauseOnDotsHover: true,
        cssEase: 'ease',
        dots: false,
        dotsClass: 'slick-dots',
        fade: false,
        slidesToShow: 2,
        centerMode: false,
        centerPadding: '20px',
        slidesToScroll: 2,
        infinite: true,
        initialSlide: -1,
        swipe: true,
        vertical: false,
        prevArrow: '<a href="#"><img src="../common/images/arrow_prev.png" class="slide-arrow prev-arrow"></a>',
        nextArrow: '<a href="#"><img src="../common/images/arrow_next.png" class="slide-arrow next-arrow"></a>',
        arrows: true,
        responsive: [
            {
                breakpoint: 769,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 641,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            },
        ]
    });

    $('.slick_testimony').slick({
        autoplay: true,
        adaptiveHeight:false,
        autoplaySpeed: 6000,
        speed: 600,
        pauseOnHover: true,
        pauseOnDotsHover: true,
        cssEase: 'ease',
        dots: false,
        fade: false,
        slidesToShow: 2,
        centerMode: false,
        centerPadding: '20px',
        slidesToScroll: 2,
        infinite: true,
        swipe: true,
        vertical: false,
        prevArrow: '<span class="testimonial_arrow left_arrow"><div class="iconify" data-icon="carbon:arrow-left" data-inline="false"></span>',
        nextArrow: '<span class="testimonial_arrow right_arrow"><div class="iconify" data-icon="carbon:arrow-right" data-inline="false"></span>',
        arrows: true,
        responsive: [
            {
                breakpoint: 769,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 641,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            },
        ]
    });

    $('.slick_proj').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 6000,
        speed: 600,
        mobileFirst: true,
        dots: true,
        responsive: [
            {
                breakpoint: 768,
                settings: "unslick"
            },
            {
                breakpoint: 640,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: true
                }
            }
        ]
    });

    $(window).on('resize', function() {
        $('.slick_proj').slick('resize');
    });

});