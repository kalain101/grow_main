// ========================= GO TO TOP ===========================
jQuery(document).ready(function($) {
    var pagetop = $('.gotoTop');

    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            pagetop.fadeIn();
        } else {
            pagetop.fadeOut();
        }
    });

    pagetop.click(function () {
        $('body, html').animate({ scrollTop: 0 }, 500);
        return false;
    });

    $(window).scroll(function() {
        scrollHeight = $(document).height();
        scrollPosition = $(window).height() + $(window).scrollTop();
        footerHeight = $("footer").innerHeight();
        if ( scrollHeight - scrollPosition  <= footerHeight ) {
            $(".gotoTop").css({
                "position":"static",
                "bottom": footerHeight
            });
            console.log(footerHeight);
        } else {
            var mq1 = window.matchMedia( "(max-width: 1440px)" );
            var mq2 = window.matchMedia( "(max-width: 768px)" );
            var mq3 = window.matchMedia( "(max-width: 640px)" );
            if (mq1.matches) {
                $(".gotoTop").css({
                    "position":"fixed",
                    "bottom": "3%",
                    "right":"114px",
                });
            }
            if (mq2.matches) {
                $(".gotoTop").css({
                    "position":"fixed",
                    "bottom": "3%",
                    "right":"30px",
                });
            }
            if (mq3.matches) {
                $(".gotoTop").css({
                    "position":"fixed",
                    "bottom": "3%",
                    "right":"30px",
                });
            }
        }
    });

    // ====================== MENU BAR ==========================

    $('.mobile_menu_header').click(function() {
        $(this).toggleClass('active');
        $('body').toggleClass('active');
        if ($(this).hasClass('active')) {
            $('.main_menu').addClass('active');
        } else {
            $('.main_menu').removeClass('active');
        }
    });

    // ======================== MODAL ===============================

    var close = $('.modal_close');
    var modal = $('#project_modal');

    $('.project_content').on('click', function(event){

        var modal_title = $(this).find('.project_name').text();
        var modal_description = $(this).find('.project_description').text();
        var modal_img = $(this).find('img').attr('src');
        var modal_imgfull = $(this).find('.full_project_image').attr('src');
        var modal_client = $(this).find('.project_client').text();
        var modal_category = $(this).find('.project_category').text();
        var modal_date = $(this).find('.project_date').text();

        // console.log(modal_img);
        $('.modal_project_img_con img').attr('src', modal_img);
        $('.modal_project_img_con a').attr('href', modal_imgfull);
        $('.modal_project_name').text(modal_title);
        $('.modal_project_desc').text(modal_description);
        $('.modal_project_client').html("<span>Client: </span>" + modal_client);
        $('.modal_project_category').html("<span>Category: </span>" + modal_category);
        $('.modal_project_date').html("<span>Date: </span>" + modal_date);
        modal.addClass('active');

    });

    close.on('click', function(event){
        modal.removeClass('active');
    });

    $('#project_modal').on('click', function(event){
        if ( $(event.target).attr('class') == "modal active") {
            modal.removeClass('active');
        }
    });

});
