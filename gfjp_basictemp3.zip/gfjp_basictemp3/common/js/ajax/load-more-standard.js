jQuery(document).ready(function($){
    
    $('.projects .primary_btn').click(function(e) {
        e.preventDefault();
        var $load_more_btn = $(this);
        var post_type = 'post'; // this is optional and can be set from anywhere, stored in mockup etc...
        var offset = $('.slick_proj li').length;
        var nonce = $load_more_btn.attr('data-nonce');
        $.ajax({
            type : "post",
            context: this,
            dataType : "json",
            url : ajax_object_standard.ajaxurl,
            data : {action: "load_more_standard", offset:offset, nonce:nonce, post_type:post_type, posts_per_page:ajax_object_standard.posts_per_page},
            timeout: 3000,
            beforeSend: function(data) {
                // here u can do some loading animation...
                $load_more_btn.addClass('loading').html('Loading...');// good for styling and also to prevent ajax calls before content is loaded by adding loading class
            },
            //timeout: 3000;
            success: function(response) {
                if (response['have_posts'] == 1){//if have posts:
                    $load_more_btn.removeClass('loading').html('Load More');
                    var $newElems = $(response['html'].replace(/(\r\n|\n|\r)/gm, ''));// here removing extra breaklines and spaces
                    $('.slick_proj').append($newElems);
                } else {
                    //end of posts (no posts found)
                    $load_more_btn.removeClass('loading').addClass('end_of_posts').html('<span>End of projects</span>'); // change buttom styles if no more posts
                }

                var close = $('.modal_close');
                var modal = $('#project_modal');

                $('.project_content').on('click', function(event){

                    var modal_title = $(this).find('.project_name').text();
                    var modal_description = $(this).find('.project_description').text();
                    var modal_img = $(this).find('img').attr('src');
                    var modal_imgfull = $(this).find('.full_project_image').attr('src');
                    var modal_client = $(this).find('.project_client').text();
                    var modal_category = $(this).find('.project_category').text();
                    var modal_date = $(this).find('.project_date').text();

                    // console.log(modal_img);
                    $('.modal_project_img_con img').attr('src', modal_img);
                    $('.modal_project_img_con a').attr('href', modal_imgfull);
                    $('.modal_project_name').text(modal_title);
                    $('.modal_project_desc').text(modal_description);
                    $('.modal_project_client').html("<span>Client: </span>" + modal_client);
                    $('.modal_project_category').html("<span>Category: </span>" + modal_category);
                    $('.modal_project_date').html("<span>Date: </span>" + modal_date);
                    modal.addClass('active');

                });

                close.on('click', function(event){
                    modal.removeClass('active');
                });

                $('#project_modal').on('click', function(event){
                    if ( $(event.target).attr('class') == "modal active") {
                        modal.removeClass('active');
                    }
                });
            }
        });
    });
});