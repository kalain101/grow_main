jQuery(document).ready(function($){
    $('#contactForm').on('submit', function(e){
        e.preventDefault();
        var that = $(this),
        url = that.attr('action'),
        type = that.attr('method');
        var fname = $('#fname').val();
        var lname = $('#lname').val();
        var email = $('#email').val();
        var subject = $('#subject').val();
        var message = $('#message').val();
        $.ajax({
            url: ajax_object_contact.ajax_url,
            type:"POST",
            dataType:'text',
            data: {
                action:'set_form',
                fname:fname,
                lname:lname,
                email:email,
                subject:subject,
                message:message,
            },   
            success: function(response){
                $(".success_msg").css("display","block");
            }, 
            error: function(data){
                $(".error_msg").css("display","block");      
            }
        });
        $('#contactForm')[0].reset();
    });
});