<?php get_header(); ?>

		<main>
			<?php 
			$projects_banner = get_theme_mod( 'gfjp_bs3_projects_banner_image_setting', GFJP_IMG_URL. '/banner_pc.png' ); 
			$projects_layout = get_theme_mod( 'gfjp_bs3_projects_layout_setting', 'standard' );
			?>
			<section class="banner aligncenter white_txt" style="background-image: url(<?php echo ( is_int( $projects_banner ) )? wp_get_attachment_url( $projects_banner ) : $projects_banner; ?>);">
				<h1><?php echo get_theme_mod('gfjp_bs3_projects_banner_title_setting','Our Projects')?></h1>
				<p><?php echo get_theme_mod('gfjp_bs3_projects_banner_subtitle_setting','Standard')?></p>
			</section>

			<div class="projects">
				<div class="maxwidth">
					<div id="project_modal" class="modal">
						<!-- Modal content -->
						<div class="modal_content">
							<div class="modal_close">
								<span class="bar_1"></span>
								<span class="bar_2"></span>
								<p>CLOSE</p>
							</div>
							<div class="modal_container flex itemcenter">
								<div class="modal_project_img_con">
									<a href="#" target="_blank"><img src="<?php echo GFJP_IMG_URL?>/proj_1.png" alt=""></a>
								</div>
								<div class="modal_project_content">
									<p class="modal_project_name"></p>
									<p class="modal_project_desc"></p>
									<p class="modal_project_client"></p>
									<p class="modal_project_category"></p>
									<p class="modal_project_date"></p>
								</div>
							</div>
						</div>
					</div>

					<?php
					if (( $projects_layout == 'standard' ) ) {
						$proj_class = "slick_proj";
						$proj_count = 8;
					} else if ( $projects_layout == 'gallery' ) {
						$proj_class = "gallery";
						$proj_count = 6;
					} else if ( $projects_layout == 'slideout' ) {
						$proj_class = "slide";
						$proj_count = 6;
					} else {
						$proj_class = "slick_proj";
						$proj_count = 8;
					}
					?>
					
					<ul class="<?php echo $proj_class ?> flex">
						<?php
                        $project_list_args = array(
                            'posts_per_page' => $proj_count,
                            'post_type'      => 'project',
                            'post_status' 	 => 'publish',
                        );
                        $project_list_query = new WP_Query( $project_list_args );
						$num = $project_list_query->post_count; 

                        if( $project_list_query->have_posts() ){
                            while( $project_list_query->have_posts() ){

                            	$project_list_query->the_post(); 

                                if( has_post_thumbnail(get_the_ID()) ) {
                                    $projects_featured_img_arr = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'project_image_size');
                                    $projects_featured_img_arr_full = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');

                                    $projects_featured_img = $projects_featured_img_arr[0];
                                    $projects_featured_img_full = $projects_featured_img_arr_full[0];
                                } else {
                                    $projects_featured_img = GFJP_IMG_URL .'/proj_1.png';
                                    $projects_featured_img_full = GFJP_IMG_URL .'/proj_1.png';
                                }

                                $current_project_cats = get_the_terms( $post->ID, 'project_category' );
                                $current_project_categories = '';

                                foreach ( $current_project_cats as $current_project_cats_key => $current_project_cats_value ){
                                    if( $current_project_cats_key != count( $current_project_cats ) - 1 ){
                                        $current_project_categories .= $current_project_cats_value->name .', ';
                                    } else {
                                        $current_project_categories .= $current_project_cats_value->name;
                                    }
                                } ?>
								<?php if( $projects_layout == 'standard' ){ ?>

									<li class="project_content">
	                                    <div class="project_img_con">
	                                        <img src="<?php echo $projects_featured_img ?>" alt="">
	                                    </div>
	                                    <img class="full_project_image" src="<?php echo $projects_featured_img_full ?>" alt="">
	                                    <p class="project_name"><?php echo get_the_title();?></p>
	                                    <p class="project_category"><?php echo $current_project_categories?></p>

	                                    <div class="more_info">
	                                        <p class="project_description"><?php echo get_the_content();?></p>
	                                        <p class="project_client"><?php echo get_post_meta( get_the_id(), 'position', true ); ?></p>
	                                        <p class="project_date"><?php echo get_the_date();?></p>
	                                    </div>
	                                </li>

								<?php }  else if( $projects_layout == 'gallery' ){ ?>

									<li class="project_content">
										<div class="proj_img_con">
											<img src="<?php echo $projects_featured_img ?>" alt="">
											<div class="project_overlay"></div>		
										</div>
										<img class="full_project_image" src="<?php echo $projects_featured_img_full ?>" alt="">

										<div class="gallery_semicontent">
											<p class="project_name white_txt"><?php echo get_the_title();?></p>
											<p class="project_category white_txt"><?php echo $current_project_categories?></p>
										</div>

										<div class="more_info">
											<p class="project_description"><?php echo get_the_content();?></p>
											<p class="project_client"><?php echo get_post_meta( get_the_id(), 'position', true ); ?></p>
											<p class="project_date"><?php echo get_the_date();?></p>
										</div>
									</li>

								<?php }  else if( $projects_layout == 'slideout' ){ ?>

									<li class="project_content">
										<div class="proj_img_con">
											<img src="<?php echo $projects_featured_img ?>" alt="">
											<div class="project_overlay"></div>		
										</div>
										<img class="full_project_image" src="<?php echo $projects_featured_img_full ?>" alt="">
										
										<div class="hover_slide">
											<p class="project_name"><?php echo get_the_title();?></p>
											<p class="project_category"><?php echo $current_project_categories?></p>
										</div>

										<div class="more_info">
											<p class="project_description"><?php echo get_the_content();?></p>
											<p class="project_client"><?php echo get_post_meta( get_the_id(), 'position', true ); ?></p>
											<p class="project_date"><?php echo get_the_date();?></p>
										</div>
									</li>

								<?php } else { ?>

									<li class="project_content">
	                                    <div class="project_img_con">
	                                        <img src="<?php echo $projects_featured_img ?>" alt="">
	                                    </div>
	                                    <img class="full_project_image" src="<?php echo $projects_featured_img_full ?>" alt="">
	                                    <p class="project_name"><?php echo get_the_title();?></p>
	                                    <p class="project_category"><?php echo $current_project_categories?></p>

	                                    <div class="more_info">
	                                        <p class="project_description"><?php echo get_the_content();?></p>
	                                        <p class="project_client"><?php echo get_post_meta( get_the_id(), 'position', true ); ?></p>
	                                        <p class="project_date"><?php echo get_the_date();?></p>
	                                    </div>
	                                </li>
								<?php } ?>

							<?php
                            }
                            wp_reset_postdata();
                        } else {
                            echo 'No projects found';
                        } ?>
					</ul>

					<?php if ( $project_list_query->have_posts() && ( $num >= $proj_count ) ) { ?>
						<div class="aligncenter">
							<a class="primary_btn brown_btn" href="" data-nonce="<?php echo wp_create_nonce('load_posts') ?>">Load More</a>
						</div>
					<?php } ?>

				</div>
			</div>
		</main>

<?php get_footer(); ?>
