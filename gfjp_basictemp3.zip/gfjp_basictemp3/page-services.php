<?php get_header(); ?>

		<main>
			<?php $service_banner = get_theme_mod( 'gfjp_bs3_service_banner_image_setting', GFJP_IMG_URL. '/banner_pc.png' );  ?>
			<section class="banner" style="background-image: url(<?php echo ( is_int( $service_banner ) )? wp_get_attachment_url( $service_banner ) : $service_banner; ?>);">
				<h1 class="aligncenter white_txt"><?php echo get_theme_mod('gfjp_bs3_service_banner_title_setting','Our Services')?></h1>
			</section>

			<div class="services">
				<div class="maxwidth">
					<ul class="flex">
                        <?php
                        $service_list_args = array(
                            'posts_per_page' => -1,
                            'post_type'     => 'service',
                        );
                        $service_list_query = new WP_Query( $service_list_args );

                        if( $service_list_query->have_posts() ){
                            while( $service_list_query->have_posts() ){
                                $service_list_query->the_post();
                                $service_img = ( has_post_thumbnail( get_the_id() ) )? get_the_post_thumbnail_url() : GFJP_IMG_URL .'/icon_dev.png';
                                ?>
                                <li>
									<section class="content_service flex itemcenter">
									    <img src="<?php echo $service_img?>" alt="">
									    <h2><?php echo get_the_title();?></h2>
									    <p><?php echo get_the_content()?></p>
									</section>
								</li>
                                <?php
                            }
                            wp_reset_postdata();
                        } else {
                            echo 'No services found';
                        } ?>
                    </ul>
				</div>
			</div>

		</main>

<?php get_footer(); ?>