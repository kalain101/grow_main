<?php get_header(); ?>

<?php
$privacy_content ='
<p>Effective date: June 20, 2020</p>
<p>This page informs you of our policies regarding the collection, use, disclosure of personal data when you use our Service and the choices you have associated with that data.</p>
<section>
	<h2>Information Collection and Use</h2>
	<p>We collect several different types of information for various purposes to provide and improve our Service to you.</p>
	<section>
		<h3>Types of Data Collected</h3>
		<section>
			<h4>Personal Data</h4>
			<p>While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you (“Personal Data”). Personally identifiable information may include, but is not limited to:</p>
			<ul class="ul_policy">
				<li>Email Address</li>
				<li>First name and last name</li>
				<li>Phone Number</li>
				<li>Address, State, Province, ZIP/Postal code, City</li>
				<li>Cookies and Usage Data</li>
			</ul>
		</section>
		<section>
			<h4>Usage Data</h4>
			<p>This may include information such as your computer’s Internet Protocol address (e.g. IP address), browser type, browser version, the pages of our Service that you visit, the time and date of your visit, the time spent on those pages, unique device identifiers and other diagnostic data.</p>
		</section>
		<section>
			<h4>Tracking & Cookies Data</h4>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ipsum rhoncus maecenas orci, mi. Imperdiet sed orci lobortis ut tristique nunc at fermentum nulla. Mauris sit nam cursus tellus mi pharetra. Gravida dignissim ultricies bibendum ac aliquam in elit, lobortis nibh.</p>
			<p>Feugiat magna a proin libero, elit metus, iaculis turpis viverra. Odio nec enim leo arcu, amet praesent ut feugiat donec. Risus augue sagittis vitae, nulla scelerisque. Sed diam neque vel tempus. Magna est nibh nibh cras.</p>
		</section>
	</section>
</section>
<section>
	<h2>How We Use Your Information</h2>
	<p>Nunc volutpat, leo, leo interdum tristique porttitor fames. Odio nec facilisi aenean diam quisque sed. In vitae odio donec scelerisque in. Morbi condimentum consectetur sem platea neque, nisl, nulla. Malesuada nunc tincidunt eu, tellus in porta magna bibendum hendrerit. Elementum ac mattis pellentesque amet, in. Donec dignissim mattis montes, leo libero, massa mauris. Nisi, vel nibh volutpat in tincidunt elementum sed pellentesque. Tempor, sit arcu pellentesque viverra. Aliquam molestie arcu pharetra consectetur. Nec vel aliquet mauris maecenas aliquet rutrum. Tellus cursus quam tempus scelerisque diam ac egestas semper porta. Mauris facilisi ut ut in elementum sociis lectus.</p>
</section>
<section>
	<h2>Links To Other Sites</h2>
	<p>Nascetur malesuada ac proin elementum feugiat. Urna non velit purus quis massa bibendum urna lorem eu. Pulvinar odio lacinia vulputate ullamcorper.</p>
	<p>Pharetra dolor nunc vel lobortis sed nec eget. Maecenas scelerisque orci, sed vitae.</p>
</section>
<section>
	<h2>Changes To This Privacy Policy</h2>
	<p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.</p>
	<p>Nibh nullam diam enim odio. Adipiscing at a praesent vitae a pharetra sed morbi condimentum.</p>
	<p>Vehicula nascetur sed vitae nunc sed neque sodales. Odio scelerisque elit pharetra sit. Etiam ultrices in lobortis id vel, scelerisque. Sem varius lectus nunc lorem eu a.</p>
</section>
<section>
	<h2>Contact Us</h2>
	<p>If you have any questions about this Privacy Policy, please contact us:</p>
	<ul class="ul_policy">
		<li>By email: companysupport@gmail.com</li>
		<li>By phone number: +1 (123) 4567 1238</li>
	</ul>
</section>
';
?>
		<main>
			<?php $privacy_banner = get_theme_mod( 'gfjp_bs3_privacy_banner_image_setting', GFJP_IMG_URL. '/banner_pc.png' ); ?>
			<div class="banner_pt" style="background-image: url(<?php echo ( is_int( $privacy_banner ) )? wp_get_attachment_url( $privacy_banner ) : $privacy_banner; ?>);">
			</div>

			<div class="policy maxwidth">
				<section>
					<h1><?php echo get_theme_mod('gfjp_bs3_privacy_page_title_setting','Privacy Policy')?></h1>
					<?php echo wpautop(get_option('privacy_content',$privacy_content));?>
				</section>
			</div>

		</main>

<?php get_footer(); ?>