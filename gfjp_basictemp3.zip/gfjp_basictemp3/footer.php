        <?php 
        $address        = get_theme_mod('gfjp_bs3_footer_address_setting','Jaro, Iloilo City Philippines');
        $email          = get_theme_mod('gfjp_bs3_footer_email_setting','companysupport@gmail.com');
        $phone_numbers  = get_theme_mod('gfjp_bs3_footer_phone_setting','+1 (123) 4567 1238');
        $phones         = preg_replace('/\D+/', '', $phone_numbers);

        $facebookLink   = get_theme_mod('gfjp_bs3_link_facebook_setting', 'https://www.facebook.com/'); 
        $twitterLink    = get_theme_mod('gfjp_bs3_link_twitter_setting', 'https://www.twitter.com/'); 
        $instagramLink  = get_theme_mod('gfjp_bs3_link_instagram_setting', 'https://www.instagram.com/'); 
        $linkedinLink   = get_theme_mod('gfjp_bs3_link_linkedin_setting', 'https://www.linkedin.com/'); 
        $behanceLink    = get_theme_mod('gfjp_bs3_link_behance_setting', 'https://www.behance.net/');

        $copyright      = get_theme_mod('gfjp_bs3_footer_bottom_setting','©2020 GROW FORWARD JP INC. | DEVELOPMENT BY <a href="https://growforwardjp.com/" target="_blank">GROW ITECH</a>');
        ?>

        <footer class="main_footer">
            <div class="maxwidth">
                <p class="aligncenter">
                    <a class="logo_footer" href="<?php echo home_url();?>">
                        <?php $footer_logo_url = get_theme_mod( 'gfjp_bs3_footer_logo_setting', GFJP_IMG_URL. '/logo_footer.png' ); ?>
                        <img class="logo_footer" src="<?php echo ( is_int( $footer_logo_url ) )? wp_get_attachment_url( $footer_logo_url ) : $footer_logo_url ?>" alt="">
                    </a>
                </p>
                <ul class="comp_info aligncenter flex">
                    <li>Address: <span><?php echo $address ?></span></li>
                    <li>Phone: <a href="tel:<?php echo $phones?>"><?php echo $phone_numbers?></a></li>
                    <li>Email: <a href="mailto:<?php echo $email?>"><?php echo $email?></a></li>
                </ul>
                <ul class="social_media aligncenter">
                    <?php if (!empty($facebookLink)) { ?>
                        <li><a href="<?php echo $facebookLink?>" target="_blank"><span class="iconify" data-icon="bx:bxl-facebook" data-inline="false"></span></a></li>
                    <?php } 
                    if (!empty($twitterLink)) { ?>
                        <li><a href="<?php echo $twitterLink?>" target="_blank"><span class="iconify" data-icon="bx:bxl-twitter" data-inline="false"></span></a></li>
                    <?php } 
                    if (!empty($instagramLink)) { ?>
                        <li><a href="<?php echo $instagramLink?>" target="_blank"><span class="iconify" data-icon="bx:bxl-instagram-alt" data-inline="false"></span></a></li>
                    <?php }
                    if (!empty($linkedinLink)) { ?>
                        <li><a href="<?php echo $linkedinLink?>" target="_blank"><span class="iconify" data-icon="bx:bxl-linkedin" data-inline="false"></span></a></li>
                    <?php } 
                    if (!empty($behanceLink)) { ?>
                        <li><a href="<?php echo $behanceLink?>" target="_blank"><span class="iconify" data-icon="bx:bxl-behance" data-inline="false"></span></a></li>
                    <?php } ?>
                </ul>
                <div class="gotoTopContainer clearfix">
                    <a class="gotoTop" href="#"></a>
                </div>
                <div class="copyright flex">
                    <p><?php echo $copyright?></p>
                    <ul>
                        <li><a href="<?php echo home_url()?>/privacy-policy">Privacy Policy</a></li>
                        <li><a href="<?php echo home_url()?>/terms-and-conditions">Terms and Conditions</a></li>
                    </ul>
                </div>
            </div>
        </footer>
        <?php wp_footer(); ?>
    </body>
</html>