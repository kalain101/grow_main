<?php
define( 'GFJP_BASICTEMP3',  'Grow Forward JP Standard Basic 3' );
define( 'CUSTOMIZER_REPEATER_VERSION', '1.1.0' );

define( 'GFJP_DIR',       get_template_directory() );
define( 'GFJP_INC_DIR',   GFJP_DIR . '/includes' );
define( 'GFJP_CLASS_DIR', GFJP_DIR . '/class' );
define( 'GFJP_ADMIN_DIR', GFJP_INC_DIR . '/admin' );
define( 'GFJP_URL',       get_template_directory_uri() );

define( 'GFJP_COMMON_URL', GFJP_URL . '/common' );
define( 'GFJP_JS_URL',     GFJP_COMMON_URL . '/js' );
define( 'GFJP_CSS_URL',    GFJP_COMMON_URL . '/css' );
define( 'GFJP_IMG_URL',    GFJP_COMMON_URL . '/images' );

/* 
    INCLUDE TEMPLATES 
-------------------------------- */
include_once ( GFJP_ADMIN_DIR . '/create_pages.php' );
include_once ( GFJP_ADMIN_DIR . '/customizer/add_customizer.php' );
include_once ( GFJP_ADMIN_DIR . '/customizer/repeater_customizer.php' );

// CUSTOM POST TYPE
include_once ( GFJP_ADMIN_DIR . '/custom-post-type/projects.php' );
include_once ( GFJP_ADMIN_DIR . '/custom-post-type/testimonials.php' );
include_once ( GFJP_ADMIN_DIR . '/custom-post-type/services.php' );
include_once ( GFJP_ADMIN_DIR . '/custom-post-type/team.php' );

// USER RESTRICTIONS
include_once ( GFJP_ADMIN_DIR . '/create_client_admin.php' );
include_once ( GFJP_ADMIN_DIR . '/minor_admin_access_restriction.php' );

// PRIVACY POLICY AND TERMS AND CONDITIONS
include_once ( GFJP_ADMIN_DIR . '/privacy_policy_settings.php' );
include_once ( GFJP_ADMIN_DIR . '/terms_and_conditions_settings.php' );

/* 
    ENQUEUE FRONTEND SCRIPTS AND STYLES 
-------------------------------------- */
add_action( 'wp_enqueue_scripts', 'gfjp_bs3_add_theme_scripts' );
function gfjp_bs3_add_theme_scripts(){
  
    wp_enqueue_style( 'style_css_style', GFJP_URL . '/style.css' );
    wp_enqueue_style( 'common_style', GFJP_CSS_URL . '/common.css' );
    wp_enqueue_style( 'slick_style', GFJP_CSS_URL . '/slick.css' );
    wp_enqueue_style( 'slick_theme_style', GFJP_CSS_URL . '/slick_theme.css' );

    wp_enqueue_script( 'jquery_script', GFJP_JS_URL .'/jquery-3.4.1.min.js', NULL, 1.1, true );
    wp_enqueue_script( 'slick_script', GFJP_JS_URL .'/slick.min.js', array ( 'jquery' ), 1.1, true );
    wp_enqueue_script( 'iconify_script', GFJP_JS_URL .'/iconify.min.js', array ( 'jquery' ), 1.1, true );
    wp_enqueue_script( 'common_script', GFJP_JS_URL .'/common.js', array ( 'jquery' ), 1.1, true );
    
    if( is_page( 'home' ) ) {
        wp_enqueue_style( 'home_style', GFJP_CSS_URL . '/home.css' );
        wp_enqueue_script( 'slide_script', GFJP_JS_URL .'/slick.js', array ( 'jquery' ), 1.1, true );
    }
    if( is_page( 'about' ) ) {
        wp_enqueue_style( 'about_style', GFJP_CSS_URL . '/about.css' );
        wp_enqueue_script( 'about_script', GFJP_JS_URL .'/about.js', array ( 'jquery' ), 1.1, true );
    }
    if( is_page( 'services' ) ) {
        wp_enqueue_style( 'services_style', GFJP_CSS_URL . '/services.css' );
    }
    if( is_page( 'contact' ) ) {
        wp_enqueue_style( 'contact_style', GFJP_CSS_URL . '/contact.css' );
    }
    if( is_page( 'projects' ) ) {
        wp_enqueue_style( 'projects_style', GFJP_CSS_URL . '/projects.css' );
    }
    if( is_page( 'privacy-policy' ) ) {
        wp_enqueue_style( 'policy_style', GFJP_CSS_URL . '/policy.css' );
    }
    if( is_page( 'terms-and-conditions' ) ) {
        wp_enqueue_style( 'terms_style', GFJP_CSS_URL . '/terms.css' );
    }

    if( is_page( 'projects' ) && get_theme_mod( 'gfjp_bs3_projects_layout_setting' ) == 'standard' ) {
        wp_enqueue_script( 'load_standard', GFJP_JS_URL . '/ajax/load-more-standard.js', array( 'jquery' ), '1.0', false );
        wp_localize_script( 'load_standard', 'ajax_object_standard', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );

    } else if( is_page( 'projects' ) && get_theme_mod( 'gfjp_bs3_projects_layout_setting' ) == 'gallery' ) {
        wp_enqueue_script( 'load_gallery', GFJP_JS_URL . '/ajax/load-more-gallery.js', array( 'jquery' ), '1.0', false );
        wp_localize_script( 'load_gallery', 'ajax_object_gallery', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );

    } else if( is_page( 'projects' ) && get_theme_mod( 'gfjp_bs3_projects_layout_setting' ) == 'slideout' ) {
        wp_enqueue_script( 'load_slideout', GFJP_JS_URL . '/ajax/load-more-slideout.js', array( 'jquery' ), '1.0', false );
        wp_localize_script( 'load_slideout', 'ajax_object_slideout', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );

    } else if ( is_page( 'projects' ) ) {
        wp_enqueue_script( 'load_standard', GFJP_JS_URL . '/ajax/load-more-standard.js', array( 'jquery' ), '1.0', false );
        wp_localize_script( 'load_standard', 'ajax_object_standard', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
    }

    if( is_page(array( 'home', 'contact' ) ) ) {
        wp_enqueue_script( 'contact_submit', GFJP_JS_URL . '/contact-submit.js', array( 'jquery' ), '1.0', false );
        wp_localize_script( 'contact_submit', 'ajax_object_contact', array('ajax_url' => admin_url( 'admin-ajax.php' ) ) );
    }
}


/*
    ADD THEME SUPPORT 
-------------------------------- */
function gfjp_bs3_theme_support(){
    add_theme_support( 'post-thumbnails' );
}
add_action( 'init', 'gfjp_bs3_theme_support' );

// DEFAULT EDITOR
add_filter( 'use_block_editor_for_post', '__return_false' );

// IMAGE SIZE
add_image_size( 'project_image_size', 470, 485, true );
add_image_size( 'team_image_size', 275, 265, true );
add_image_size( 'testimonial_image_size', 60, 60, true );


/*
    ADMIN STYLE
-------------------------------- */
function gfjp_bs3_admin_script($hook_suffix){
    if($hook_suffix == 'toplevel_page_privacy-policy') {
        wp_enqueue_style( 'privacy_admin_style', GFJP_CSS_URL . '/admin/privacy_policy.css' );
    }
    if($hook_suffix == 'toplevel_page_terms-condtions') {
        wp_enqueue_style( 'terms_admin_style', GFJP_CSS_URL . '/admin/terms_conditions.css' );
    }
}
add_action( 'admin_enqueue_scripts', 'gfjp_bs3_admin_script' );


/* 
    TITLE PLACEHOLDER
-------------------------------- */
function gfjp_bs3_title_text( $title ){
    $screen = get_current_screen();
    if  ( 'testimonials' == $screen->post_type ) {
        $title = 'Add New Name';
    }
    if  ( 'teams' == $screen->post_type ) {
        $title = 'Add New Team';
    }
    return $title;
}
add_filter( 'enter_title_here', 'gfjp_bs3_title_text' );


/* 
    AJAX FORM
-------------------------------- */
function gfjp_bs3_set_contact_form(){
    require_once ( GFJP_INC_DIR . '/form-ajax/contact-submit.php' );  
}
add_action( 'wp_ajax_set_form', 'gfjp_bs3_set_contact_form' );   
add_action( 'wp_ajax_nopriv_set_form', 'gfjp_bs3_set_contact_form'); 


/*
    AJAX LOAD MORE
--------------------------------- */
function gfjp_bs3_load_more_standard_func() {
    require_once ( GFJP_INC_DIR . '/load-more/standard-load.php' );  
}
add_action( "wp_ajax_load_more_standard", "gfjp_bs3_load_more_standard_func" ); 
add_action( "wp_ajax_nopriv_load_more_standard", "gfjp_bs3_load_more_standard_func" );

function gfjp_bs3_load_more_gallery_func() {
    require_once ( GFJP_INC_DIR . '/load-more/gallery-load.php' );  
}
add_action( "wp_ajax_load_more_gallery", "gfjp_bs3_load_more_gallery_func" ); 
add_action( "wp_ajax_nopriv_load_more_gallery", "gfjp_bs3_load_more_gallery_func" );

function gfjp_bs3_load_more_slideout_func() {
    require_once ( GFJP_INC_DIR . '/load-more/slideout-load.php' );  
}
add_action( "wp_ajax_load_more_slideout", "gfjp_bs3_load_more_slideout_func" ); 
add_action( "wp_ajax_nopriv_load_more_slideout", "gfjp_bs3_load_more_slideout_func" );