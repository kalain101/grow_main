<?php
$emailTo   = get_bloginfo('admin_email');
$fname     = $_POST['fname'];
$lname     = $_POST['lname'];
$email     = $_POST['email'];
$message   = $_POST['message'];
$subject   = $_POST['subject'];

$subject = $subject;
$message = $message? $_POST['message'] .' <br><br> - '. $fname.' '. $lname: 'Message is empty';
$headers = array( 'From: '.$fname.' '.$lname.' <'.$email .'>', 'Content-Type: text/html; charset=UTF-8' );

$usubject = 'Message confirmation from '. get_home_url();
$umessage = 'Thank you for getting in touch! <br><br>We appreciate you contacting us/ '. get_bloginfo( 'name' ) .'. One of our colleagues will get back in touch with you soon! <br><br>Have a great day!';
$uheaders = array( 'From: '. get_bloginfo( 'name' ).' <'. $emailTo .'>', 'Content-Type: text/html; charset=UTF-8' );

wp_mail($emailTo, $subject, $message, $headers);
wp_mail($email, $usubject, $umessage, $uheaders); 

die();