<?php
ob_start(); // buffer output instead of echoing it

//verifying nonce here
if ( !wp_verify_nonce( $_REQUEST['nonce'], "load_posts" ) ) {
    exit("No projects found");
}     

$offset = isset($_REQUEST['offset'])?intval($_REQUEST['offset']):0;

$project_list_args = array(
    'offset'            => $offset,
    'posts_per_page'    => 3,
    'post_type'         => 'project',
    'post_status'       => 'publish',
);
$project_list_query = new WP_Query( $project_list_args );

if( $project_list_query->have_posts() ){

    $result['have_posts'] = true; 
    while ( $project_list_query->have_posts() ) : $project_list_query->the_post();                       

        if( has_post_thumbnail(get_the_ID()) ) {
            $projects_featured_img_arr = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'project_image_size');
            $projects_featured_img_arr_full = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');

            $projects_featured_img = $projects_featured_img_arr[0];
            $projects_featured_img_full = $projects_featured_img_arr_full[0];
        } else {
            $projects_featured_img = GFJP_IMG_URL .'/proj_1.png';
            $projects_featured_img_full = GFJP_IMG_URL .'/proj_1.png';
        }

        $current_project_cats = get_the_terms( $post->ID, 'project_category' );
        $current_project_categories = '';

        foreach ( $current_project_cats as $current_project_cats_key => $current_project_cats_value ){
            if( $current_project_cats_key != count( $current_project_cats ) - 1 ){
                $current_project_categories .= $current_project_cats_value->name .', ';
            } else {
                $current_project_categories .= $current_project_cats_value->name;
            }
        } ?>
        <li class="project_content">
            <div class="proj_img_con">
                <img src="<?php echo $projects_featured_img ?>" alt="">
                <div class="project_overlay"></div>     
            </div>
            <img class="full_project_image" src="<?php echo $projects_featured_img_full ?>" alt="">

            <div class="gallery_semicontent">
                <p class="project_name white_txt"><?php echo get_the_title();?></p>
                <p class="project_category white_txt"><?php echo $current_project_categories?></p>
            </div>
            
            <div class="more_info">
                <p class="project_description"><?php echo get_the_content();?></p>
                <p class="project_client"><?php echo get_post_meta( get_the_id(), 'position', true ); ?></p>
                <p class="project_date"><?php echo get_the_date();?></p>
            </div>
        </li>
    <?php endwhile;

    $result['html'] = ob_get_clean(); // put alloutput data into "html" item
} else {
    $result['have_posts'] = false; // return that there is no posts found
} 
if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
    $result = json_encode($result); // encode result array into json feed
    echo $result; // by echo we return JSON feed on POST request sent via AJAX
}
else { 
    header("Location: ".$_SERVER["HTTP_REFERER"]);
}
die();