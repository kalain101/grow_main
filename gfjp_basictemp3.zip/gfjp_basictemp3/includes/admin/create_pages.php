<?php
//  Create the homepage
add_action( 'init', 'create_home_page' );
function create_home_page(){

    if( is_null( get_page_by_path( 'home' ) ) ){
        $post_details   = array(
            'post_title'    => 'Home',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
            'post_name'     => 'home'
        );
        wp_insert_post( $post_details );

        //  Set the home page as homepage
        $home = get_page_by_path( 'home' );
        update_option( 'page_on_front', $home->ID );
        update_option( 'show_on_front', 'page' );
    }
}

//  Create the about page
add_action( 'init', 'create_about_page' );
function create_about_page(){

    if( is_null( get_page_by_path( 'about' ) ) ){
        $post_details   = array(
            'post_title'    => 'About',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
            'post_name'     => 'about'
        );
        wp_insert_post( $post_details );
    }
}

//  Create the services page
add_action( 'init', 'create_services_page' );
function create_services_page(){

    if( is_null( get_page_by_path( 'services' ) ) ){
        $post_details   = array(
            'post_title'    => 'Services',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
            'post_name'     => 'services'
        );
        wp_insert_post( $post_details );
    }
}

//  Create the contact page
add_action( 'init', 'create_contact_page' );
function create_contact_page(){

    if( is_null( get_page_by_path( 'contact' ) ) ){
        $post_details   = array(
            'post_title'    => 'Contact',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
            'post_name'     => 'contact'
        );
        wp_insert_post( $post_details );
    }
}

//  Create the projects page
add_action( 'init', 'create_projects_page' );
function create_projects_page(){

    if( is_null( get_page_by_path( 'projects' ) ) ){
        $post_details   = array(
            'post_title'    => 'Projects',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
            'post_name'     => 'projects'
        );
        wp_insert_post( $post_details );
    }
}

//  Create the privacy policy page
add_action( 'init', 'create_privacy_page' );
function create_privacy_page(){

    if( is_null( get_page_by_path( 'privacy-policy' ) ) ){
        $post_details   = array(
            'post_title'    => 'Privacy Policy',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
            'post_name'     => 'privacy-policy'
        );
        wp_insert_post( $post_details );
    }
}

//  Create the terms page
add_action( 'init', 'create_terms_page' );
function create_terms_page(){

    if( is_null( get_page_by_path( 'terms-and-conditions' ) ) ){
        $post_details   = array(
            'post_title'    => 'Terms and Conditions',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
            'post_name'     => 'terms-and-conditions'
        );
        wp_insert_post( $post_details );
    }
}

