<?php

function minor_admin_access_restriction(){

    $user_id = get_current_user_id();

    $user = wp_get_current_user();
    $roles = ( array )$user->roles;

    if( $user_id !== 1 and !in_array( 'subscriber', $roles ) ){
        add_action( 'admin_init', 'remove_menu_pages' );
    }
}
add_action( 'init', 'minor_admin_access_restriction' );

function remove_menu_pages(){

    // Remove Dashboard
    remove_menu_page( 'index.php' );
    //  Remove Pages
    remove_menu_page( 'edit.php?post_type=page' );
    // Remove theme access
    remove_submenu_page( 'themes.php', 'themes.php' );
    // Remove theme editor
    remove_submenu_page( 'themes.php', 'theme-editor.php' );
    // Remove Plugins
    remove_menu_page( 'plugins.php' );
    // Remove Users
    remove_menu_page( 'users.php' );
    // Remove Tools
    remove_menu_page( 'tools.php' );
    // Remove Settings
    remove_menu_page( 'options-general.php' );
    //  Remove yoast
    remove_menu_page( 'wpseo_dashboard' );
}

// Remove the admin bar
if(!current_user_can('administrator')) {
    add_filter('show_admin_bar', '__return_false');
}