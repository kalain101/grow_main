<?php

add_action( 'customize_register', 'gfjp_bs3_about' );
function gfjp_bs3_about( $wp_customize ){

    $wp_customize->add_panel( 'gfjp_bs3_about_panel', array(
        'title'       => 'About Page Content',
        'priority'    => 186,
    ) );

    $wp_customize->add_section( 'gfjp_bs3_about_banner_section', array(
        'title'       => 'Banner Section',
        'panel'       => 'gfjp_bs3_about_panel'
    ) );

    $wp_customize->add_section( 'gfjp_bs3_about_entry_section', array(
        'title'       => 'About Entry Section',
        'panel'       => 'gfjp_bs3_about_panel'
    ) );

    $wp_customize->add_section( 'gfjp_bs3_about_expertise_section', array(
        'title'       => 'Expertise Section',
        'panel'       => 'gfjp_bs3_about_panel'
    ) );

    $wp_customize->add_section( 'gfjp_bs3_about_team_section', array(
        'title'       => 'Team Section',
        'panel'       => 'gfjp_bs3_about_panel'
    ) );

    $wp_customize->add_section( 'gfjp_bs3_about_testimonial_section', array(
        'title'       => 'Testimonial Section',
        'panel'       => 'gfjp_bs3_about_panel'
    ) );


    /*
        BANNER
    -----------------------*/
    $wp_customize->add_setting( 'gfjp_bs3_about_banner_title_setting', array(
        'default'  => 'We are Grow'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_about_banner_title_control', array(
        'label'    => 'Banner Title',
        'section'  => 'gfjp_bs3_about_banner_section',
        'settings' => 'gfjp_bs3_about_banner_title_setting',
        'type'     => 'text'
    ) ) );

    $wp_customize->add_setting('gfjp_bs3_about_banner_image_setting', array(
        'default'       => GFJP_IMG_URL .'/banner_pc.png'
    ));
    $wp_customize->add_control(new WP_Customize_Cropped_Image_Control($wp_customize, 'gfjp_bs3_about_banner_image_', array(
        'label'         => 'Banner Background Image',
        'description'   => 'Suggested image dimensions: 1440 by 400 pixels',
        'settings'      => 'gfjp_bs3_about_banner_image_setting',
        'section'       => 'gfjp_bs3_about_banner_section',
        'flex_width'    => true,
        'flex_height'   => true,
    ) ) );


    /*
        ENTRY ABOUT 
    -----------------------*/
    $wp_customize->add_setting('gfjp_bs3_about_entry_image_setting', array(
        'default'       => GFJP_IMG_URL .'/about.png'
    ));
    $wp_customize->add_control(new WP_Customize_Cropped_Image_Control($wp_customize, 'gfjp_bs3_about_entry_image_control', array(
        'label'         => 'Left Image',
        'description'   => 'Suggested image dimensions: 475 by 490 pixels',
        'settings'      => 'gfjp_bs3_about_entry_image_setting',
        'section'       => 'gfjp_bs3_about_entry_section',
        'flex_width'    => false,
        'flex_height'   => false,
        'height'        => 475,
        'width'         => 490,
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_about_entry_title_setting', array(
        'default'  => 'We are a team of expert people with creative ideas'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_about_entry_title_control', array(
        'label'    => 'About Title',
        'section'  => 'gfjp_bs3_about_entry_section',
        'settings' => 'gfjp_bs3_about_entry_title_setting',
        'type'     => 'textarea'
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_about_entry_desc_setting', array(
        'default'  => 'Cum tempus tristique pellentesque vulputate euismod at in sit at. Ac augue orci platea egestas eros, quis nisl sit. Lobortis integer sed facilisis neque. Tortor, sagittis massa magna odio egestas sodales tincidunt. Diam consectetur interdum dolor tincidunt proin lectus turpis eu.

Lectus risus cursus pharetra, quis venenatis a facilisis turpis. Diam lectus mauris auctor massa adipiscing vulputate tortor dapibus nam. Tristique quam ut diam interdum aenean pulvinar in eget. Aliquet cursus in mauris ultrices bibendum leo malesuada. Pellentesque erat maecenas integer et bibendum. Odio sit id arcu, sit quis justo molestie mi. Nisi in dis velit lectus. Pretium neque facilisi rhoncus dui, egestas integer aliquet nunc.'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_about_entry_desc_control', array(
        'label'    => 'About Content',
        'section'  => 'gfjp_bs3_about_entry_section',
        'settings' => 'gfjp_bs3_about_entry_desc_setting',
        'type'     => 'textarea'
    ) ) );


    /*
        EXPERTISE
    -----------------------*/
    $wp_customize->add_setting( 'gfjp_bs3_about_expertise_title_setting', array(
        'default'  => 'Our Expertise'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_about_expertise_title_control', array(
        'label'    => 'Expertise Title',
        'section'  => 'gfjp_bs3_about_expertise_section',
        'settings' => 'gfjp_bs3_about_expertise_title_setting',
        'type'     => 'text'
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_about_expertise_content_setting', array(
        'default'  => 'Mollis pulvinar in ornare ipsum elit. Eget amet est semper fames fermentum at dis quisque purus.'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_about_expertise_content_control', array(
        'label'    => 'Expertise Entry Content',
        'section'  => 'gfjp_bs3_about_expertise_section',
        'settings' => 'gfjp_bs3_about_expertise_content_setting',
        'type'     => 'textarea'
    ) ) );

    // PROGRESS BAR
    // 1 //
    $wp_customize->add_setting( 'gfjp_bs3_about_progress1_title_setting', array(
        'default'  => 'Marketing'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_about_progress1_title_control', array(
        'label'    => 'Progress Bar 1 Title',
        'section'  => 'gfjp_bs3_about_expertise_section',
        'settings' => 'gfjp_bs3_about_progress1_title_setting',
        'type'     => 'text'
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_about_progress1_value_setting', array(
        'default'  => '92'
    ) );
    $wp_customize->add_control( new Customizer_Range_Value_Control( $wp_customize, 'gfjp_bs3_about_progress1_value_control', array(
        'label'    => 'Progress Bar 1 Value',
        'type'     => 'range-value',
        'section'  => 'gfjp_bs3_about_expertise_section',
        'settings' => 'gfjp_bs3_about_progress1_value_setting',
        'input_attrs' => array(
            'min'    => 1,
            'max'    => 100,
            'step'   => 1,
            'suffix' => '%',
        ),
    ) ) );

    // 2 //
    $wp_customize->add_setting( 'gfjp_bs3_about_progress2_title_setting', array(
        'default'  => 'Development'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_about_progress2_title_control', array(
        'label'    => 'Progress Bar 2 Title',
        'section'  => 'gfjp_bs3_about_expertise_section',
        'settings' => 'gfjp_bs3_about_progress2_title_setting',
        'type'     => 'text'
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_about_progress2_value_setting', array(
        'default'  => '87'
    ) );
    $wp_customize->add_control( new Customizer_Range_Value_Control( $wp_customize, 'gfjp_bs3_about_progress2_value_control', array(
        'label'    => 'Progress Bar 2 Value',
        'type'     => 'range-value',
        'section'  => 'gfjp_bs3_about_expertise_section',
        'settings' => 'gfjp_bs3_about_progress2_value_setting',
        'input_attrs' => array(
            'min'    => 1,
            'max'    => 100,
            'step'   => 1,
            'suffix' => '%',
        ),
    ) ) );

    // 3 //
    $wp_customize->add_setting( 'gfjp_bs3_about_progress3_title_setting', array(
        'default'  => 'Design'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_about_progress3_title_control', array(
        'label'    => 'Progress Bar 3 Title',
        'section'  => 'gfjp_bs3_about_expertise_section',
        'settings' => 'gfjp_bs3_about_progress3_title_setting',
        'type'     => 'text'
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_about_progress3_value_setting', array(
        'default'  => '90'
    ) );
    $wp_customize->add_control( new Customizer_Range_Value_Control( $wp_customize, 'gfjp_bs3_about_progress3_value_control', array(
        'label'    => 'Progress Bar 3 Value',
        'type'     => 'range-value',
        'section'  => 'gfjp_bs3_about_expertise_section',
        'settings' => 'gfjp_bs3_about_progress3_value_setting',
        'input_attrs' => array(
            'min'    => 1,
            'max'    => 100,
            'step'   => 1,
            'suffix' => '%',
        ),
    ) ) );


    /*
        MEET TEAM
    -----------------------*/
    $wp_customize->add_setting( 'gfjp_bs3_about_team_title_setting', array(
        'default'  => 'Meet our team'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_about_team_title_control', array(
        'label'    => 'Team Title',
        'section'  => 'gfjp_bs3_about_team_section',
        'settings' => 'gfjp_bs3_about_team_title_setting',
        'type'     => 'text'
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_about_team_content_setting', array(
        'default'  => 'We are dedicated staffs who work efficiently and effectively to deliver you high quality products and services.'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_about_team_content_control', array(
        'label'    => 'Team Entry Content',
        'section'  => 'gfjp_bs3_about_team_section',
        'settings' => 'gfjp_bs3_about_team_content_setting',
        'type'     => 'textarea'
    ) ) );


    /*
        TESTIMONIALS
    -----------------------*/
    $wp_customize->add_setting( 'gfjp_bs3_about_testimonial_title_setting', array(
        'default'  => 'What our Clients say'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_about_testimonial_title_control', array(
        'label'    => 'Testimonial Title',
        'section'  => 'gfjp_bs3_about_testimonial_section',
        'settings' => 'gfjp_bs3_about_testimonial_title_setting',
        'type'     => 'text'
    ) ) );

}