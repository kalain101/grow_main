<?php

add_action( 'customize_register', 'gfjp_bs3_header' );
function gfjp_bs3_header( $wp_customize ){

    $wp_customize->add_section( 'gfjp_bs3_header_section', array(
        'title'     => 'Header',
        'priority'  => 80,
    ) );

    //  Header Logo
    $wp_customize->add_setting( 'gfjp_bs3_header_desktop_logo_setting', array(
        'default'     => GFJP_IMG_URL .'/logo_header.png'
    ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_bs3_header_desktop_logo_control', array(
        'label'       => 'Header Logo',
        'section'     => 'gfjp_bs3_header_section',
        'settings'    => 'gfjp_bs3_header_desktop_logo_setting',
        'flex_width'  => true,
        'flex_height' => true
    ) ) );

    //  Contact Number
    $wp_customize->add_setting( 'gfjp_bs3_header_contact_setting', array(
        'default'  => '+1 (123) 4567 1238'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_header_contact_control', array(
        'label'    => 'Header Contact Number',
        'section'  => 'gfjp_bs3_header_section',
        'settings' => 'gfjp_bs3_header_contact_setting',
        'type'     => 'text'
    ) ) );

}


