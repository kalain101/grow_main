<?php

require_once( GFJP_CLASS_DIR.'/customizer-range-value-control.php' );

include_once 'header_customizer.php';
include_once 'footer_customizer.php';
include_once 'homepage_customizer.php';
include_once 'map_customizer.php';
include_once 'contact_customizer.php';
include_once 'services_customizer.php';
include_once 'about_customizer.php';
include_once 'projects_customizer.php';
include_once 'privacy_customizer.php';
include_once 'terms_customizer.php';