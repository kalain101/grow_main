<?php

add_action( 'customize_register', 'gfjp_bs3_privacy' );
function gfjp_bs3_privacy( $wp_customize ){

    $wp_customize->add_section( 'gfjp_bs3_privacy_section', array(
        'title'       => 'Privacy Page Content',
        'priority'    => 192,
    ) );

    /*
        BANNER
    -----------------------*/
    $wp_customize->add_setting('gfjp_bs3_privacy_banner_image_setting', array(
        'default'       => GFJP_IMG_URL .'/banner_pc.png'
    ));
    $wp_customize->add_control(new WP_Customize_Cropped_Image_Control($wp_customize, 'gfjp_bs3_privacy_banner_image_control', array(
        'label'         => 'Banner Background Image',
        'description'   => 'Suggested image dimensions: 1440 by 400 pixels',
        'settings'      => 'gfjp_bs3_privacy_banner_image_setting',
        'section'       => 'gfjp_bs3_privacy_section',
        'flex_width'    => true,
        'flex_height'   => true,
    ) ) );

    /*
        PAGE
    -----------------------*/
    $wp_customize->add_setting( 'gfjp_bs3_privacy_page_title_setting', array(
        'default'  => 'Privacy Policy'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_privacy_page_title_control', array(
        'label'    => 'Page Title',
        'settings' => 'gfjp_bs3_privacy_page_title_setting',
        'section'  => 'gfjp_bs3_privacy_section',
        'type'     => 'text'
    ) ) );


}