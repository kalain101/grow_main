<?php

add_action( 'customize_register', 'gfjp_bs3_home' );
function gfjp_bs3_home( $wp_customize ){

    $wp_customize->add_panel( 'gfjp_bs3_home_panel', array(
        'title'       => 'Homepage Content',
        'priority'    => 180,
    ) );

    $wp_customize->add_section( 'gfjp_bs3_home_banner_section', array(
        'title'       => 'Banner Section',
        'panel'       => 'gfjp_bs3_home_panel'
    ) );

    $wp_customize->add_section( 'gfjp_bs3_home_about_section', array(
        'title'       => 'About Section',
        'panel'       => 'gfjp_bs3_home_panel'
    ) );

    $wp_customize->add_section( 'gfjp_bs3_home_project_section', array(
        'title'       => 'Project Section',
        'panel'       => 'gfjp_bs3_home_panel'
    ) );

    $wp_customize->add_section( 'gfjp_bs3_home_testimonial_section', array(
        'title'       => 'Testimonial Section',
        'panel'       => 'gfjp_bs3_home_panel'
    ) );

    $wp_customize->add_section( 'gfjp_bs3_home_contact_section', array(
        'title'       => 'Contact Section',
        'panel'       => 'gfjp_bs3_home_panel'
    ) );


    /*
        BANNER
    -----------------------*/
    $wp_customize->add_setting( 'gfjp_bs3_home_banner_title_setting', array(
        'default'  => 'Web Development & Digital Agency'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_home_banner_title_control', array(
        'label'    => 'Banner Title',
        'section'  => 'gfjp_bs3_home_banner_section',
        'settings' => 'gfjp_bs3_home_banner_title_setting',
        'type'     => 'text'
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_home_banner_subtitle_setting', array(
        'default'  => 'We turn your ideas into reality.'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_home_banner_subtitle_control', array(
        'label'    => 'Banner Sub Title',
        'section'  => 'gfjp_bs3_home_banner_section',
        'settings' => 'gfjp_bs3_home_banner_subtitle_setting',
        'type'     => 'text'
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_home_banner_btntxt_setting', array(
        'default'  => 'Explore Now'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_home_banner_btntxt_control', array(
        'label'    => 'Button Text',
        'section'  => 'gfjp_bs3_home_banner_section',
        'settings' => 'gfjp_bs3_home_banner_btntxt_setting',
        'type'     => 'text'
    ) ) );

    // SLIDER
    $wp_customize->add_setting( 'customizer_repeater_slider', array(
        'sanitize_callback' => 'customizer_repeater_sanitize',
        'default' => json_encode( array(
            array("image_url" => GFJP_IMG_URL.'/home/banner1_pc.jpg' ,"link" => "#", "id" => "customizer_repeater_56d7ea7f40f56" ), 
            array("image_url" => GFJP_IMG_URL.'/home/banner2_pc.jpg' ,"link" => "#", "id" => "customizer_repeater_56d7ea7f40f57" ),
            array("image_url" => GFJP_IMG_URL.'/home/banner3_pc.jpg' ,"link" => "#", "id" => "customizer_repeater_56d7ea7f40f58" ),
        ) )
    ));
    $wp_customize->add_control( new Customizer_Repeater( $wp_customize, 'customizer_repeater_slider', array(
        'label'     => 'Banner Images',
        'section'   => 'gfjp_bs3_home_banner_section',
        'priority'  => 1,
        'customizer_repeater_image_control'     => true,
        'customizer_repeater_icon_control'      => true,
        'customizer_repeater_repeater_control'  => true
    ) ) );


    /*
        ABOUT
    -----------------------*/
    $wp_customize->add_setting('gfjp_bs3_home_about_image_setting', array(
        'default'       => GFJP_IMG_URL .'/about.png'
    ));
    $wp_customize->add_control(new WP_Customize_Cropped_Image_Control($wp_customize, 'gfjp_bs3_home_about_image_control', array(
        'label'         => 'Left Image',
        'description'   => 'Suggested image dimensions: 475 by 490 pixels',
        'settings'      => 'gfjp_bs3_home_about_image_setting',
        'section'       => 'gfjp_bs3_home_about_section',
        'flex_width'    => false,
        'flex_height'   => false,
        'height'        => 475,
        'width'         => 490,
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_home_about_title_setting', array(
        'default'  => 'We are a team of expert people with creative ideas'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_home_about_title_control', array(
        'label'    => 'About Title',
        'section'  => 'gfjp_bs3_home_about_section',
        'settings' => 'gfjp_bs3_home_about_title_setting',
        'type'     => 'textarea'
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_home_about_desc_setting', array(
        'default'  => 'Cum tempus tristique pellentesque vulputate euismod at in sit at. Ac augue orci platea egestas eros, quis nisl sit. Lobortis integer sed facilisis neque. Tortor, sagittis massa magna odio egestas sodales tincidunt. Diam consectetur interdum dolor tincidunt proin lectus turpis eu.'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_home_about_desc_control', array(
        'label'    => 'About Content',
        'section'  => 'gfjp_bs3_home_about_section',
        'settings' => 'gfjp_bs3_home_about_desc_setting',
        'type'     => 'textarea'
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_home_about_btntxt_setting', array(
        'default'  => 'Learn More'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_home_about_btntxt_control', array(
        'label'    => 'Button Text',
        'section'  => 'gfjp_bs3_home_about_section',
        'settings' => 'gfjp_bs3_home_about_btntxt_setting',
        'type'     => 'text'
    ) ) );


    /*
        PROJECT
    -----------------------*/
    $wp_customize->add_setting( 'gfjp_bs3_home_project_title_setting', array(
        'default'  => 'Our Projects'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_home_project_title_control', array(
        'label'    => 'Projects Title',
        'section'  => 'gfjp_bs3_home_project_section',
        'settings' => 'gfjp_bs3_home_project_title_setting',
        'type'     => 'text'
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_home_project_btntxt_setting', array(
        'default'  => 'View Our Project'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_home_project_btntxt_control', array(
        'label'    => 'Button Text',
        'section'  => 'gfjp_bs3_home_project_section',
        'settings' => 'gfjp_bs3_home_project_btntxt_setting',
        'type'     => 'text'
    ) ) );


    /*
        TESTIMONIALS
    -----------------------*/
    $wp_customize->add_setting( 'gfjp_bs3_home_testimonial_title_setting', array(
        'default'  => 'What our Clients say'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_home_testimonial_title_control', array(
        'label'    => 'Testimonial Title',
        'section'  => 'gfjp_bs3_home_testimonial_section',
        'settings' => 'gfjp_bs3_home_testimonial_title_setting',
        'type'     => 'text'
    ) ) );


    /*
        CONTACT
    -----------------------*/
    $wp_customize->add_setting( 'gfjp_bs3_home_contact_title_setting', array(
        'default'  => 'Keep in Touch with Us'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_home_contact_title_control', array(
        'label'    => 'Contact Title',
        'section'  => 'gfjp_bs3_home_contact_section',
        'settings' => 'gfjp_bs3_home_contact_title_setting',
        'type'     => 'text'
    ) ) );

}