<?php

add_action( 'customize_register', 'gfjp_bs3_projects' );
function gfjp_bs3_projects( $wp_customize ){

    $wp_customize->add_section( 'gfjp_bs3_projects_section', array(
        'title'       => 'Projects Page Content',
        'priority'    => 184,
    ) );

    /*
        BANNER
    -----------------------*/
    $wp_customize->add_setting( 'gfjp_bs3_projects_banner_title_setting', array(
        'default'  => 'Our Projects'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_projects_banner_title_control', array(
        'label'    => 'Banner Title',
        'section'  => 'gfjp_bs3_projects_section',
        'settings' => 'gfjp_bs3_projects_banner_title_setting',
        'type'     => 'text'
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_projects_banner_subtitle_setting', array(
        'default'  => 'Standard'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_projects_banner_subtitle_control', array(
        'label'    => 'Banner Sub Title',
        'section'  => 'gfjp_bs3_projects_section',
        'settings' => 'gfjp_bs3_projects_banner_subtitle_setting',
        'type'     => 'text'
    ) ) );

    $wp_customize->add_setting('gfjp_bs3_projects_banner_image_setting', array(
        'default'       => GFJP_IMG_URL .'/banner_pc.png'
    ));
    $wp_customize->add_control(new WP_Customize_Cropped_Image_Control($wp_customize, 'gfjp_bs3_projects_banner_image_control', array(
        'label'         => 'Banner Background Image',
        'description'   => 'Suggested image dimensions: 1440 by 400 pixels',
        'settings'      => 'gfjp_bs3_projects_banner_image_setting',
        'section'       => 'gfjp_bs3_projects_section',
        'flex_width'    => true,
        'flex_height'   => true,
    ) ) );

    /*
        BODY
    -----------------------*/
    $wp_customize->add_setting( 'gfjp_bs3_projects_layout_setting', array(
        'default'   => 'standard'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_projects_layout_control', array(
        'label'     => 'Select Projects Layout',
        'section'   => 'gfjp_bs3_projects_section',
        'settings'  => 'gfjp_bs3_projects_layout_setting',
        'type'      => 'select',
        'choices'   => array(
            'standard'  => 'Standard Layout',
            'gallery'   => 'Gallery Layout',
            'slideout'  => 'Slide Out Layout',
        )
    ) ) );

}