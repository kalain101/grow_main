<?php

add_action( 'customize_register', 'gfjp_bs3_footer' );
function gfjp_bs3_footer( $wp_customize ){

    $wp_customize->add_panel( 'gfjp_bs3_footer_panel', array(
        'title'       => 'Footer',
        'priority'    => 100,
    ) );

    $wp_customize->add_section( 'gfjp_st3_footer_logo_section', array(
        'title'       => 'Footer Logo',
        'panel'       => 'gfjp_bs3_footer_panel'
    ) );

    $wp_customize->add_section( 'gfjp_st3_footer_contact_section', array(
        'title'       => 'Contact Details',
        'panel'       => 'gfjp_bs3_footer_panel'
    ) );

    $wp_customize->add_section( 'gfjp_st3_footer_social_section', array(
        'title'       => 'Social Networks',
        'panel'       => 'gfjp_bs3_footer_panel'
    ) );

    $wp_customize->add_section( 'gfjp_st3_footer_bottom_section', array(
        'title'       => 'Bottom Bar',
        'panel'       => 'gfjp_bs3_footer_panel'
    ) );

    //  Footer Logo
    $wp_customize->add_setting( 'gfjp_bs3_footer_logo_setting', array(
        'default'     => GFJP_IMG_URL .'/logo_footer.png'
    ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_bs3_footer_logo_control', array(
        'label'       => 'Footer Logo',
        'section'     => 'gfjp_st3_footer_logo_section',
        'settings'    => 'gfjp_bs3_footer_logo_setting',
        'flex_width'  => true,
        'flex_height' => true
    ) ) );


    //  Address
    $wp_customize->add_setting( 'gfjp_bs3_footer_address_setting', array(
        'default'  => 'Jaro, Iloilo City Philippines'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_footer_address_control', array(
        'label'    => 'Footer Address',
        'section'  => 'gfjp_st3_footer_contact_section',
        'settings' => 'gfjp_bs3_footer_address_setting',
        'type'     => 'text'
    ) ) );

    //  Address
    $wp_customize->add_setting( 'gfjp_bs3_footer_phone_setting', array(
        'default'  => '+1 (123) 4567 1238'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_footer_phone_control', array(
        'label'    => 'Footer Phone',
        'section'  => 'gfjp_st3_footer_contact_section',
        'settings' => 'gfjp_bs3_footer_phone_setting',
        'type'     => 'text'
    ) ) );

    //  Email
    $wp_customize->add_setting( 'gfjp_bs3_footer_email_setting', array(
        'default'  => 'companysupport@gmail.com'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_footer_email_control', array(
        'label'    => 'Footer Phone',
        'section'  => 'gfjp_st3_footer_contact_section',
        'settings' => 'gfjp_bs3_footer_email_setting',
        'type'     => 'text'
    ) ) );


    // SOCIAL NETWORKS
    $wp_customize->add_setting( 'gfjp_bs3_link_facebook_setting', array (
        'default'     => 'https://www.facebook.com/',
    ));
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_link_facebook_control', array(
        'label'       => 'Facebook',
        'section'     => 'gfjp_st3_footer_social_section',
        'settings'    => 'gfjp_bs3_link_facebook_setting',
        'type'        => 'url',
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_link_twitter_setting', array (
        'default'     => 'https://twitter.com/',
    ));
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_link_twitter_control', array(
        'label'       => 'Twitter',
        'section'     => 'gfjp_st3_footer_social_section',
        'settings'    => 'gfjp_bs3_link_twitter_setting',
        'type'        => 'url',
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_link_instagram_setting', array (
        'default'     => 'https://www.instagram.com/',
    ));
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_link_instagram_control', array(
        'label'       => 'Instagram',
        'section'     => 'gfjp_st3_footer_social_section',
        'settings'    => 'gfjp_bs3_link_instagram_setting',
        'type'        => 'url',
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_link_linkedin_setting', array (
        'default'     => 'https://www.linkedin.com/',
    ));
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_link_linkedin_control', array(
        'label'       => 'LinkedIn',
        'section'     => 'gfjp_st3_footer_social_section',
        'settings'    => 'gfjp_bs3_link_linkedin_setting',
        'type'        => 'url',
    ) ) );

    $wp_customize->add_setting( 'gfjp_bs3_link_behance_setting', array (
        'default'     => 'https://www.behance.net/',
    ));
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_link_behance_control', array(
        'label'       => 'Behance',
        'section'     => 'gfjp_st3_footer_social_section',
        'settings'    => 'gfjp_bs3_link_behance_setting',
        'type'        => 'url',
    ) ) );

    // BOTTOM BAR
    $wp_customize->add_setting( 'gfjp_bs3_footer_bottom_setting', array (
        'default'     => '©2020 GROW FORWARD JP INC. | DEVELOPMENT BY <a href="https://growforwardjp.com/" target="_blank">GROW ITECH</a>',
    ));
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_footer_bottom_control', array(
        'label'       => 'Copyright Text',
        'section'     => 'gfjp_st3_footer_bottom_section',
        'settings'    => 'gfjp_bs3_footer_bottom_setting',
        'type'        => 'textarea',
    ) ) );

}