<?php

add_action( 'customize_register', 'gfjp_bs3_map' );
function gfjp_bs3_map( $wp_customize ){

    $wp_customize->add_section( 'gfjp_bs3_map_section', array(
        'title'       => 'Map Settings',
        'priority'    => 200,
    ) );

    //  MAP
    $wp_customize->add_setting( 'gfjp_bs3_map_setting', array(
        'default'  => '<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15680.489804730247!2d122.5563697!3d10.7250377!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x28de841d5567073a!2sGrow%20Forward%20Jp%20Inc.!5e0!3m2!1sen!2sph!4v1596175658623!5m2!1sen!2sph" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_bs3_map_control', array(
        'label'    => 'Map iframe',
        'section'  => 'gfjp_bs3_map_section',
        'settings' => 'gfjp_bs3_map_setting',
        'type'     => 'textarea'
    ) ) );

}