<?php

class gfjp_bs3_project_Post_Type {

    function __construct() {
        add_action( 'init', array( $this, 'gfjp_bs3_create_project_post_type' ) );
        add_action( 'add_meta_boxes', array( $this, 'gfjp_bs3_project_add_meta_box' ) );
        add_action( 'save_post', array( $this, 'gfjp_bs3_project_save_meta_box' ) ); 
        add_action( 'init', array( $this,'gfjp_bs3_project_taxonomies') );
    }

    function gfjp_bs3_create_project_post_type(){

        if( !post_type_exists( 'project' ) ){

            $labels = array(
                'name'               => 'Projects',
                'singular_name'      => 'project',
                'add_new'            => 'Add New Project',
                'all_items'          => 'All project',
                'add_new_item'       => 'Add New project Item',
                'edit_item'          => 'Edit A Project',
                'new_item'           => 'New Project',
                'view_item'          => 'View Project',
                'search_item'        => 'Search Project',
                'not_found'          => 'No Items Found in This',
                'not_found_in_trash' => 'No items found in Trash',
                'parent_item_column' => 'Parent Item'
            );

            $args = array(
                'labels'                => $labels,
                'supports'              => array( 'title', 'editor', 'excerpt', 'thumbnail', ),
                'hierarchical'          => false,
                'public'                => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'menu_position'         => 5,
                'show_in_admin_bar'     => true,
                'show_in_nav_menus'     => true,
                'can_export'            => true,
                'has_archive'           => true,        
                'exclude_from_search'   => false,
                'publicly_queryable'    => true,
                'capability_type'       => 'page',
            );
            register_post_type( 'project', $args );
        }
    }

    function gfjp_bs3_project_add_meta_box(){
        add_meta_box(
            'gfjp_meta_box', __( 'Extra Fields', GFJP_BASICTEMP3 ),
            array( $this, 'gfjp_bs3_project_meta_box_callback' ), 'project', 'normal'
        );
    }

    function gfjp_bs3_project_meta_box_callback( $post ) {
        wp_nonce_field( 'gfjp_bs3_project_meta_box', 'gfjp_bs3_project_meta_box_nonce' );
        $img_url = GFJP_IMG_URL . '/proj_1.png';
        if( get_post_meta( $post->ID, 'cover_image', true ) ){
            $img_url = wp_get_attachment_image_url( get_post_meta( $post->ID, 'cover_image', true ), 'full' );
        }
        ?>
        <table>
            <tbody>
                <tr>
                    <td><h4><?php _e( 'Client', GFJP_BASICTEMP3 ); ?></h4></td>
                    <td><input type="text" id="gfjp_bs3_project_position" name="gfjp_bs3_project_position" autocomplete="off" value="<?php echo get_post_meta( $post->ID, 'position', true ); ?>" /></td>
                </tr>
            </tbody>
        </table>
        <?php
    }

    function gfjp_bs3_project_save_meta_box( $post_id ) {
        if ( ! isset( $_POST['gfjp_bs3_project_meta_box_nonce'] ) ) {
            return;
        }
        if ( ! wp_verify_nonce( $_POST['gfjp_bs3_project_meta_box_nonce'], 'gfjp_bs3_project_meta_box' ) ) {
            return;
        }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( isset( $_POST['post_type'] ) && 'project' == $_POST['post_type'] ) {
            if ( ! current_user_can( 'edit_page', $post_id ) ) {
                return;
            }
        } else {
            if ( ! current_user_can( 'edit_post', $post_id ) ) {
                return;
            }
        }
        $position = sanitize_text_field( $_POST['gfjp_bs3_project_position'] );
        update_post_meta( $post_id, 'position', $position );
    }

    function gfjp_bs3_project_taxonomies() {
        $labels = array(
            'name'              => _x( 'Project Categories', 'taxonomy general name' ),
            'singular_name'     => _x( 'Project Category', 'taxonomy singular name' ),
            'search_items'      => __( 'Search Project Categories' ),
            'all_items'         => __( 'All Project Categories' ),
            'parent_item'       => __( 'Parent Project Category' ),
            'parent_item_colon' => __( 'Parent Project Category:' ),
            'edit_item'         => __( 'Edit Project Category' ), 
            'update_item'       => __( 'Update Project Category' ),
            'add_new_item'      => __( 'Add New Project Category' ),
            'new_item_name'     => __( 'New Project Category' ),
            'menu_name'         => __( 'Project Categories' ),
        );
        $args = array(
            'labels' => $labels,
            'hierarchical' => true,
        );
        register_taxonomy( 'project_category', 'project', $args );
    }

}

new gfjp_bs3_project_Post_Type;