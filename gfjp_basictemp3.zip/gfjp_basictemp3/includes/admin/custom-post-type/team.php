<?php

class gfjp_bs3_Team_Post_Type {

    function __construct() {
        add_action( 'init', array( $this, 'gfjp_bs3_create_teams_post_type' ) );
        add_action( 'add_meta_boxes', array( $this, 'gfjp_bs3_teams_add_meta_box' ) );
        add_action( 'save_post', array( $this, 'gfjp_bs3_teams_save_meta_box' ) ); 
    }

    function gfjp_bs3_create_teams_post_type(){

        if( !post_type_exists( 'teams' ) ){

            $labels = array(
                'name'               => 'Team',
                'singular_name'      => 'team',
                'add_new'            => 'Add New Team',
                'all_items'          => 'All Team',
                'add_new_item'       => 'Add New Team Item',
                'edit_item'          => 'Edit A Team',
                'new_item'           => 'New Team',
                'view_item'          => 'View Team',
                'search_item'        => 'Search Team',
                'not_found'          => 'No Items Found in This',
                'not_found_in_trash' => 'No items found in Trash',
                'parent_item_column' => 'Parent Item'
            );

            $args = array(
                'labels'                => $labels,
                'supports'              => array( 'title', 'editor', 'excerpt', 'thumbnail', ),
                'hierarchical'          => false,
                'public'                => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'menu_position'         => 5,
                'show_in_admin_bar'     => true,
                'show_in_nav_menus'     => true,
                'can_export'            => true,
                'has_archive'           => true,        
                'exclude_from_search'   => false,
                'publicly_queryable'    => true,
                'capability_type'       => 'page',
            );
            register_post_type( 'teams', $args );
        }
    }

    function gfjp_bs3_teams_add_meta_box(){
        add_meta_box(
            'gfjp_meta_box', __( 'Extra Fields', GFJP_BASICTEMP3 ),
            array( $this, 'gfjp_bs3_teams_meta_box_callback' ), 'teams', 'normal'
        );
    }

    function gfjp_bs3_teams_meta_box_callback( $post ) {
        wp_nonce_field( 'gfjp_bs3_teams_meta_box', 'gfjp_bs3_teams_meta_box_nonce' );
        $img_url = GFJP_IMG_URL . '/profile_1.png';
        if( get_post_meta( $post->ID, 'cover_image', true ) ){
            $img_url = wp_get_attachment_image_url( get_post_meta( $post->ID, 'cover_image', true ), 'full' );
        }
        ?>
        <table>
            <tbody>
                <tr>
                    <td><h4><?php _e( 'Position', GFJP_BASICTEMP3 ); ?></h4></td>
                    <td><input type="text" id="gfjp_bs3_teams_position" name="gfjp_bs3_teams_position" autocomplete="off" value="<?php echo get_post_meta( $post->ID, 'positions', true ); ?>" /></td>
                </tr>
            </tbody>
        </table>
        <?php
    }

    function gfjp_bs3_teams_save_meta_box( $post_id ) {
        if ( ! isset( $_POST['gfjp_bs3_teams_meta_box_nonce'] ) ) {
            return;
        }
        if ( ! wp_verify_nonce( $_POST['gfjp_bs3_teams_meta_box_nonce'], 'gfjp_bs3_teams_meta_box' ) ) {
            return;
        }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( isset( $_POST['post_type'] ) && 'teams' == $_POST['post_type'] ) {
            if ( ! current_user_can( 'edit_page', $post_id ) ) {
                return;
            }
        } else {
            if ( ! current_user_can( 'edit_post', $post_id ) ) {
                return;
            }
        }
        $positions = sanitize_text_field( $_POST['gfjp_bs3_teams_position'] );
        update_post_meta( $post_id, 'positions', $positions );
    }

}

new gfjp_bs3_Team_Post_Type;