<?php

class gfjp_bs3_Services_Post_Type {

    function __construct() {
        add_action( 'init', array( $this, 'gfjp_bs3_create_services_post_type' ) );
    }

    function gfjp_bs3_create_services_post_type(){

        if( !post_type_exists( 'service' ) ){

        $labels = array(
            'name'               => 'Services',
            'singular_name'      => 'Service',
            'add_new'            => 'Add New Service',
            'all_items'          => 'All Services',
            'add_new_item'       => 'Add New Services Item',
            'edit_item'          => 'Edit A Service',
            'new_item'           => 'New Service',
            'view_item'          => 'View Service',
            'search_item'        => 'Search Service',
            'not_found'          => 'No Items Found in This',
            'not_found_in_trash' => 'No items found in Trash',
            'parent_item_column' => 'Parent Item'
        );

        $args = array(
            'labels'                => $labels,
            'supports'              => array( 'title', 'editor', 'excerpt', 'thumbnail', ),
            'hierarchical'          => false,
            'public'                => true,
            'show_ui'               => true,
            'show_in_menu'          => true,
            'menu_position'         => 5,
            'show_in_admin_bar'     => true,
            'show_in_nav_menus'     => true,
            'can_export'            => true,
            'has_archive'           => true,        
            'exclude_from_search'   => false,
            'publicly_queryable'    => true,
            'capability_type'       => 'page',
        );

        register_post_type( 'service', $args );

        }
    }
}

new gfjp_bs3_Services_Post_Type;