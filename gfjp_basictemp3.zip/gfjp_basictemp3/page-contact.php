<?php get_header(); ?>

		<main>
			<?php $contact_banner = get_theme_mod( 'gfjp_bs3_contact_banner_image_setting', GFJP_IMG_URL. '/banner_pc.png' );  ?>
			<section class="banner" style="background-image: url(<?php echo ( is_int( $contact_banner ) )? wp_get_attachment_url( $contact_banner ) : $contact_banner; ?>);">
				<h1 class="white_txt aligncenter"><?php echo get_theme_mod('gfjp_bs3_contact_banner_title_setting','Keep in touch with us')?></h1>
			</section>

			<div class="contact">
				<section class="maxwidth">
					<h2 class="aligncenter"><?php echo get_theme_mod('gfjp_bs3_contact_form_title_setting','Keep in Touch with Us')?></h2>

					<form action="POST" id="contactForm" method="post" class="contact_form" enctype="multipart/form-data">
                        <div class="col_form_half">
                            <input type="text" name="fname" id="fname" placeholder="Enter first name..." required>
                        </div>
                        <div class="col_form_half">
                            <input type="text" name="lname" id="lname" placeholder="Enter last name..." required>
                        </div>
                        <div class="col_form_half email_col">
                            <input type="email" name="email" id="email" placeholder="Enter your email..." required>
                        </div>
                        <div class="col_form_half subject_col">
                            <input type="text" name="subject" id="subject" placeholder="Subject" required>   
                        </div>      
                        <textarea id="message" name="message" placeholder="Enter your message..." required></textarea>

                        <div class="success_msg " style="display: none">Message Sent Successfully</div>
                        <div class="error_msg" style="display: none">Message Not Sent, There is some error.</div>

                        <div class="aligncenter">
                            <input class="primary_btn brown_btn" type="submit" value="Send Message" id="submit">
                        </div>
                    </form>

				</section>
			</div>

			<div class="map_area">
				<?php echo get_theme_mod('gfjp_bs3_map_setting','<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15680.489804730247!2d122.5563697!3d10.7250377!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x28de841d5567073a!2sGrow%20Forward%20Jp%20Inc.!5e0!3m2!1sen!2sph!4v1596175658623!5m2!1sen!2sph" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>')?>
			</div>

		</main>

<?php get_footer(); ?>
