<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="format-detection" content="telephone=no">
        <title><?php echo get_bloginfo( 'name' ); ?></title>
        <!-- CSS -->
        <?php wp_head(); ?>
    </head>

    <body>
        <header class="main_header">
            <div class="maxwidth flex itemcenter">

                <!-- BRANDING -->
                <<?php echo ( is_page( 'home' ) )? 'h1': 'div'; ?> class="logo_header">
                    <a href="<?php echo home_url();?>" class="header_logo">
                        <?php $header_desktop_logo_url = get_theme_mod( 'gfjp_bs3_header_desktop_logo_setting', GFJP_IMG_URL. '/logo_header.png' ); ?>
                        <img src="<?php echo ( is_int( $header_desktop_logo_url ) )? wp_get_attachment_url( $header_desktop_logo_url ) : $header_desktop_logo_url ?>" alt="">
                    </a>
                </<?php echo ( is_page( 'home' ) )? 'h1': 'div'; ?>>

                <!-- MAIN MENU -->
                <ul class="main_menu">
                    <li <?php echo ( is_page( 'home' ) )? 'class="active"': ''; ?>><a href="<?php echo home_url();?>">Home</a></li>
                    <li <?php echo ( is_page( 'services' ) )? 'class="active"': ''; ?>><a href="<?php echo home_url();?>/services">Services</a></li>
                    <li <?php echo ( is_page( 'projects' ) )? 'class="active"': ''; ?>><a href="<?php echo home_url();?>/projects">Projects</a></li>
                    <li <?php echo ( is_page( 'about' ) )? 'class="active"': ''; ?>><a href="<?php echo home_url();?>/about">About</a></li>
                    <li <?php echo ( is_page( 'contact' ) )? 'class="active"': ''; ?>><a href="<?php echo home_url();?>/contact">Contact</a></li>
                    <!-- PHONE NUMBER -->
                    <?php 
                    $phone_number = get_theme_mod( 'gfjp_bs3_header_contact_setting', '+1 (123) 4567 1238');
                    $phone = preg_replace('/\D+/', '', $phone_number);
                    ?>
                    <li class="phone_header">
                        <a href="tel:<?php echo $phone;?>">
                            <span class="iconify" data-icon="carbon:phone-filled" data-inline="false"></span>
                            <span class="inner_phone"><?php echo $phone_number;?></span>
                        </a>
                    </li>
                </ul>

                <!-- MOBILE MENU -->
                <div class="mobile_menu_header">
                    <div class="menu">
                        <span class="bar_1"></span>
                        <span class="bar_2"></span>
                        <span class="bar_3"></span>
                        <span class="bar_4"></span>
                    </div>
                    <p class="mmobile_capt white_txt">
                        <span class="menu_capt">MENU</span>
                        <span class="close_capt">CLOSE</span>
                    </p>
                </div>
            </div>
        </header>