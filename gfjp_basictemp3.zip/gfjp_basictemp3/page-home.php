<?php get_header(); ?>

        <main>
            <div class="banner_home">
                <ul class="slick_banner">
                    <?php
                    $customizer_repeater_slider = get_theme_mod('customizer_repeater_slider', json_encode( array(
                        array("image_url" => GFJP_IMG_URL.'/home/banner1_pc.jpg' ,"link" => "#", "id" => "customizer_repeater_56d7ea7f40f56" ), 
                        array("image_url" => GFJP_IMG_URL.'/home/banner2_pc.jpg' ,"link" => "#", "id" => "customizer_repeater_56d7ea7f40f57" ),
                        array("image_url" => GFJP_IMG_URL.'/home/banner3_pc.jpg' ,"link" => "#", "id" => "customizer_repeater_56d7ea7f40f58" ),
                    )));
                    $customizer_repeater_slider_decoded = json_decode($customizer_repeater_slider);
                    foreach($customizer_repeater_slider_decoded as $repeater_item){
                        ?><li style="background-image: url('<?php echo $repeater_item->image_url; ?>');"></li><?php
                    } ?>
                </ul>

                <div>
                    <section class="maxwidth aligncenter">
                        <h2 class="white_txt"><?php echo get_theme_mod('gfjp_bs3_home_banner_title_setting','Web Development & Digital Agency')?></h2>
                        <p class="white_txt"><?php echo get_theme_mod('gfjp_bs3_home_banner_subtitle_setting','We turn your ideas into reality.')?></p>
                        <a class="primary_btn white_btn" href="#about"><?php echo get_theme_mod('gfjp_bs3_home_banner_btntxt_setting','Explore Now')?></a>
                    </section>
                </div>
            </div>

            <div class="about" id="about">
                <div class="maxwidth flex itemcenter">
                    <?php $ab_img = get_theme_mod( 'gfjp_bs3_home_about_image_setting', GFJP_IMG_URL. '/about.png' );  ?>
                    <img class="ab_desktop" src="<?php echo ( is_int( $ab_img ) )? wp_get_attachment_url( $ab_img ) : $ab_img; ?>" alt="">
                    <section> 
                        <h2><?php echo get_theme_mod('gfjp_bs3_home_about_title_setting','We are a team of expert people with creative ideas')?></h2>
                        <p><?php echo get_theme_mod('gfjp_bs3_home_about_desc_setting','Cum tempus tristique pellentesque vulputate euismod at in sit at. Ac augue orci platea egestas eros, quis nisl sit. Lobortis integer sed facilisis neque. Tortor, sagittis massa magna odio egestas sodales tincidunt. Diam consectetur interdum dolor tincidunt proin lectus turpis eu.')?></p>
                        <a class="primary_btn brown_btn" href="<?php echo home_url();?>/about"><?php echo get_theme_mod('gfjp_bs3_home_about_btntxt_setting','Learn More')?></a>
                    </section>
                    <img class="ab_mobile" src="<?php echo ( is_int( $ab_img ) )? wp_get_attachment_url( $ab_img ) : $ab_img; ?>" alt="">
                </div>
            </div>

            <div class="services">
                <div class="maxwidth">
                    <ul class="flex">
                        <?php
                        $service_list_args = array(
                            'posts_per_page' => 6,
                            'post_type'     => 'service',
                        );
                        $service_list_query = new WP_Query( $service_list_args );

                        if( $service_list_query->have_posts() ){
                            while( $service_list_query->have_posts() ){
                                $service_list_query->the_post(); 
                                $service_content = has_excerpt() ? get_the_excerpt() : wp_trim_words(get_the_content(), 14, '...'); 
                                $service_img = ( has_post_thumbnail( get_the_id() ) )? get_the_post_thumbnail_url() : GFJP_IMG_URL .'/icon_dev.png';
                                ?>
                                <li>
                                    <img src="<?php echo $service_img?>" alt="">
                                    <section class="content_service">
                                        <h2><?php echo get_the_title();?></h2>
                                        <span><?php echo $service_content?></span>
                                    </section>
                                </li>
                                <?php
                            }
                            wp_reset_postdata();
                        } else {
                            echo 'No services found';
                        } ?>
                    </ul>
                </div>
            </div>

            <div class="projects">
                <section class="maxwidth">
                    <h2 class="aligncenter"><?php echo get_theme_mod('gfjp_bs3_home_project_title_setting','Our Projects')?></h2>
                    <div id="project_modal" class="modal">
                        <!-- Modal content -->
                        <div class="modal_content">
                            <div class="modal_close">
                                <span class="bar_1"></span>
                                <span class="bar_2"></span>
                                <p>CLOSE</p>
                            </div>
                            <div class="modal_container flex itemcenter">
                                <div class="modal_project_img_con">
                                    <a href="#" target="_blank"><img src="<?php echo GFJP_IMG_URL?>/proj_1.png" alt=""></a>
                                </div>
                                <div class="modal_project_content">
                                    <p class="modal_project_name"></p>
                                    <p class="modal_project_desc"></p>
                                    <p class="modal_project_client"></p>
                                    <p class="modal_project_category"></p>
                                    <p class="modal_project_date"></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <ul class="slick_proj flex">
                        <?php
                        $project_list_args = array(
                            'posts_per_page' => 8,
                            'post_type'     => 'project',
                        );
                        $project_list_query = new WP_Query( $project_list_args );

                        if( $project_list_query->have_posts() ){
                            while( $project_list_query->have_posts() ){
                            $project_list_query->the_post(); 
                            
                                if( has_post_thumbnail(get_the_ID()) ) {
                                    $projects_featured_img_arr = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'project_image_size');
                                    $projects_featured_img_arr_full = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');

                                    $projects_featured_img = $projects_featured_img_arr[0];
                                    $projects_featured_img_full = $projects_featured_img_arr_full[0];
                                } else {
                                    $projects_featured_img = GFJP_IMG_URL .'/proj_1.png';
                                    $projects_featured_img_full = GFJP_IMG_URL .'/proj_1.png';
                                }

                                $current_project_cats = get_the_terms( $post->ID, 'project_category' );
                                $current_project_categories = '';

                                foreach ( $current_project_cats as $current_project_cats_key => $current_project_cats_value ){
                                    if( $current_project_cats_key != count( $current_project_cats ) - 1 ){
                                        $current_project_categories .= $current_project_cats_value->name .', ';
                                    } else {
                                        $current_project_categories .= $current_project_cats_value->name;
                                    }
                                }
                                ?>
                                <li class="project_content">
                                    <div class="project_img_con">
                                        <img src="<?php echo $projects_featured_img ?>" alt="">
                                    </div>
                                    <img class="full_project_image" src="<?php echo $projects_featured_img_full ?>" alt="">
                                    <p class="project_name"><?php echo get_the_title();?></p>
                                    <p class="project_category"><?php echo $current_project_categories?></p>

                                    <div class="more_info">
                                        <p class="project_description"><?php echo get_the_content();?></p>
                                        <p class="project_client"><?php echo get_post_meta( get_the_id(), 'position', true ); ?></p>
                                        <p class="project_date"><?php echo get_the_date();?></p>
                                    </div>
                                </li>
                                <?php
                            }
                            wp_reset_postdata();
                        } else {
                            echo 'No projects found';
                        } ?>
                    </ul>
                    <div class="aligncenter"><a class="primary_btn brown_btn" href="<?php echo home_url()?>/projects"><?php echo get_theme_mod('gfjp_bs3_home_project_btntxt_setting','View Our Project')?></a></div>
                </section>
            </div>

            <div class="testimony">
                <section class="maxwidth">
                    <h2 class="aligncenter white_txt"><?php echo get_theme_mod('gfjp_bs3_home_testimonial_title_setting','What our Clients say')?></h2>
                    <div class="slick_testimony">
                        <?php
                        $testimonials_list_args = array(
                            'posts_per_page' => -1,
                            'post_type'     => 'testimonials',
                        );
                        $testimonials_list_query = new WP_Query( $testimonials_list_args );

                        if( $testimonials_list_query->have_posts() ){
                            while( $testimonials_list_query->have_posts() ){
                                $testimonials_list_query->the_post(); 
                                $testimonials_img = ( has_post_thumbnail( get_the_id() ) )? get_the_post_thumbnail_url() : GFJP_IMG_URL .'/profile_1.png';
                                ?>
                                <div>
                                    <div class="testimonial_wrap flex">
                                        <div class="testimonials_image">
                                            <img src="<?php echo $testimonials_img?>" alt="">
                                        </div>
                                        <div class="testimonial_content">
                                            <p class="testimonials">“<?php echo get_the_content();?>”</p>
                                            <p class="testimonial_name"><?php echo get_the_title();?></p>
                                            <p class="testimonial_position"><?php echo get_post_meta( get_the_id(), 'position', true ); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            wp_reset_postdata();
                        } else {
                            echo 'No testimonials found';
                        } ?>
                    </div>
                </section>
            </div>

            <div class="contact">
                <section class="maxwidth">
                    <h2 class="aligncenter"><?php echo get_theme_mod('gfjp_bs3_home_contact_title_setting','Keep in Touch with Us')?></h2>
                    <form action="POST" id="contactForm" method="post" class="contact_form" enctype="multipart/form-data">

                        <div class="col_form_half">
                            <input type="text" name="fname" id="fname" placeholder="Enter first name..." required>
                        </div>
                        <div class="col_form_half">
                            <input type="text" name="lname" id="lname" placeholder="Enter last name..." required>
                        </div>
                        <div class="col_form_half email_col">
                            <input type="email" name="email" id="email" placeholder="Enter your email..." required>
                        </div>
                        <div class="col_form_half subject_col">
                            <input type="text" name="subject" id="subject" placeholder="Subject" required>   
                        </div>      
                        <textarea id="message" name="message" placeholder="Enter your message..." required></textarea>

                        <div class="success_msg " style="display: none">Message Sent Successfully</div>
                        <div class="error_msg" style="display: none">Message Not Sent, There is some error.</div>

                        <div class="aligncenter">
                            <input class="primary_btn brown_btn" type="submit" value="Send Message" id="submit">
                        </div>
                    </form>
                </section>
            </div>

            <div class="map_area">
                <?php echo get_theme_mod('gfjp_bs3_map_setting','<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15680.489804730247!2d122.5563697!3d10.7250377!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x28de841d5567073a!2sGrow%20Forward%20Jp%20Inc.!5e0!3m2!1sen!2sph!4v1596175658623!5m2!1sen!2sph" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>')?>
            </div>

        </main>

<?php get_footer(); ?>