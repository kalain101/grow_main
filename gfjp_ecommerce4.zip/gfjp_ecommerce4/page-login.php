<?php get_header(); ?>

	<main>

	<?php $default_banner = get_theme_mod( 'gfjp_ec4_gen_banner_background_setting', GFJP_IMG_URL. '/bg_banner.jpg' ); ?>
	<?php $signin_banner = get_theme_mod( 'gfjp_ec4_signin_banner_background_setting', $default_banner); ?>

	<?php if ($signin_banner !== '' ) { ?>
		<div class="inner_banner" style="background-image: url(<?php echo ( is_int( $signin_banner ) )? wp_get_attachment_url( $signin_banner ) : $signin_banner; ?>);"></div>
	<?php } else { ?>
		<div class="inner_banner" style="background-image: url(<?php echo ( is_int( $default_banner ) )? wp_get_attachment_url( $default_banner ) : $default_banner; ?>);"></div>
	<?php } ?>

		<div class="inner_content login_content aligncenter">
			<section class="maxwidth">
				<h1><?php echo get_theme_mod('gfjp_ec4_signin_title_setting','Login')?></h1>
				<p class="form_sub_label">New to this site? <a href="<?php echo home_url();?>/signup" class="bright_red_txt underline">Sign up</a></p>

				<form name="login_form" class="login_form" id="loginForm" action="login" method="post">

					<div class="msg_display"></div>

					<div class="floating_label_wrap login-username">
						<input type="text" name="username" id="username" class="login_email floating_label_field input" placeholder="Email" value="" required>
						<label class="floating_label" for="username">Username or Email</label>
					</div>

					<div class="floating_label_wrap login-password">
						<input type="password" name="password" id="password" class="login_pword floating_label_field" placeholder="Password" required>
						<label class="floating_label" for="password">Password</label>
						<span class="iconify toggle_pword" data-toggle="#password" data-icon="carbon:view-filled" data-inline="false"></span>
					</div>
					
					<p class="forgot_pword_wrap"><a href="<?php echo home_url();?>/forgot-password" class="bright_red_txt underline">Forgot your password?</a></p>

					<p class="login-submit">
						<input type="submit" name="submit" class="button button-primary btn_default uppercase submit_button" value="Sign In">
					</p>
					<?php wp_nonce_field( 'ajax-login-nonce', 'security' ); ?>
				</form>

			</section>
		</div>
	</main>

<?php get_footer(); ?>