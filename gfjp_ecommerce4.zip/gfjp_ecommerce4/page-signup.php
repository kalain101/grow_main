<?php get_header(); ?>

		<main>

		<?php $default_banner = get_theme_mod( 'gfjp_ec4_gen_banner_background_setting', GFJP_IMG_URL. '/bg_banner.jpg' ); ?>
		<?php $signup_banner = get_theme_mod( 'gfjp_ec4_signup_banner_background_setting', $default_banner); ?>

		<?php if ($signup_banner !== '' ) { ?>
			<div class="inner_banner" style="background-image: url(<?php echo ( is_int( $signup_banner ) )? wp_get_attachment_url( $signup_banner ) : $signup_banner; ?>);"></div>
		<?php } else { ?>
			<div class="inner_banner" style="background-image: url(<?php echo ( is_int( $default_banner ) )? wp_get_attachment_url( $default_banner ) : $default_banner; ?>);"></div>
		<?php } ?>

			<div class="inner_content signup_content aligncenter">
				<section class="maxwidth">
					<h1><?php echo get_theme_mod('gfjp_ec4_signup_title_setting','Sign Up')?></h1>
					<p class="form_sub_label">Already a member?  <a href="<?php echo home_url();?>/login" class="bright_red_txt underline">Log in</a></p>

					<?php //gfjp_ec4_show_error_messages(); ?>

					<form action="" id="signupForm" method="POST" class="signup_form">

						<div class="msg_display"></div>

						<div class="floating_label_wrap">
							<input type="text" name="gfjp_ec4_user_login" id="gfjp_ec4_user_login" class="fname floating_label_field" placeholder="First Name" required>
							<label class="floating_label">Username</label>
						</div>

						<div class="floating_label_wrap">
							<input type="text" name="gfjp_ec4_fname" id="gfjp_ec4_fname" class="fname floating_label_field" placeholder="First Name" required>
							<label class="floating_label">First Name</label>
						</div>

						<div class="floating_label_wrap">
							<input type="text" name="gfjp_ec4_lname" id="gfjp_ec4_lname" class="lname floating_label_field" placeholder="Last Name" required>
							<label class="floating_label">Last Name</label>
						</div>

						<div class="floating_label_wrap">
							<input type="email" name="gfjp_ec4_email" id="gfjp_ec4_email" class="signup_email floating_label_field" placeholder="Email" required>
							<label class="floating_label">Email</label>
						</div>

						<div class="floating_label_wrap">
							<input type="password" name="gfjp_ec4_pword" id="password" class="signup_pword floating_label_field" placeholder="Password" required>
							<label class="floating_label">Password</label>
							<span class="iconify toggle_pword" data-toggle="#password" data-icon="carbon:view-filled" data-inline="false"></span>
						</div>

						<div class="floating_label_wrap">
							<input type="password" name="gfjp_ec4_pword_confirm" id="password_again" class="signup_pword_confirm floating_label_field" placeholder="Password" required>
							<label class="floating_label">Confirm Password</label>
							<span class="iconify toggle_pword" data-toggle="#password_again" data-icon="carbon:view-filled" data-inline="false"></span>
						</div>

						<input type="submit" class="btn_default uppercase" value="Sign Up">
						<!--<input type="hidden" name="gfjp_ec4_register_nonce" value="<?php echo wp_create_nonce('gfjp_ec4-register-nonce'); ?>"/>-->
						<?php wp_nonce_field( 'gfjp_ec4-register-nonce', 'security' ); ?>
					</form>
				</section>
			</div>
		</main>

<?php get_footer(); ?>