<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

the_title( '<h1 class="single_product_name bright_red_txt alegreya_regular">', '</h1>' );

