							<li>
                    			<?php $prod_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );?>
                    			<?php $temp_image = wc_placeholder_img_src('full'); ?>
								<div class="product_col_main aligncenter" data-id="<?php echo $post->ID; ?>">
								    
									<a href="<?php echo get_permalink();?>"><div class="product_image" style="background-image: url(<?php echo $prod_image ? $prod_image[0] : $temp_image ?>)">
										<div class="inner_product_hover">
											<span class="btn_default btn_small uppercase">View Product</span>
										</div>
									</div></a>
									<div class="product_info">
										<?php
										$terms = get_the_terms( $post->ID, 'product_cat' );
										if ( $terms && ! is_wp_error( $terms ) ) :
										    $cat_links = array();
										    foreach ( $terms as $term ) {
										        $cat_links[] = $term->name;
										    }
										    $on_cat = join( ", ", $cat_links );
										    ?>
										    <p class="product_category uppercase"><?php echo $on_cat; ?></p>
										<?php endif; ?>
										<a href="<?php echo get_permalink();?>"><h3 class="product_title alegreya_regular"><?php the_title(); ?></h3></a>
										<?php $product = wc_get_product( get_the_ID() );?>
										<p class="product_price alegreya_bold"><?php echo $product->get_price_html(); ?></p>
									</div>
								</div>
							</li>