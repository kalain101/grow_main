<?php defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_cart_is_empty' );

if ( wc_get_page_id( 'shop' ) > 0 ) : ?>

    <section class="maxwidth aligncenter">
        <h1>Cart</h1>
        <p class="form_sub_label">Your cart is currently empty. </p>
        <a class="btn_default uppercase btn_border" href="<?php echo esc_url( apply_filters( 'woocommerce_return_to_shop_redirect', wc_get_page_permalink( 'shop' ) ) ); ?>">Continue Shopping</a>
    </section>

<?php endif; ?>
