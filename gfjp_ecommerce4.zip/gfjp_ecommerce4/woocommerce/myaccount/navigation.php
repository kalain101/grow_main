<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<nav class="woocommerce-myaccount-navigation">
  <p class="menu_account_lbl alegreya_bold">My account <span class="iconify" data-icon="bx:bx-chevron-down" data-inline="false"></span></p>
	<ul class="myaccount_list">
		<?php foreach ( wc_get_account_menu_items() as $endpoint => $label ) : ?>
			<li class="<?php echo wc_get_account_menu_item_classes( $endpoint ); ?>">
				<a href="<?php echo esc_url( wc_get_account_endpoint_url( $endpoint ) ); ?>"><?php echo esc_html( $label ); ?></a>
			</li>
		<?php endforeach; ?>
	</ul>
</nav>