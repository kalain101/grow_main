<?php
defined( 'ABSPATH' ) || exit;

  do_action( 'woocommerce_account_navigation' ); ?> 
  <section class="account_right_account">
  	<?php
  		do_action( 'woocommerce_account_content' );
  	?>
  </section>
