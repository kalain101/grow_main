<?php

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_account_orders', $has_orders ); ?>

	<h1>Order History</h1>

	<?php if ( $has_orders ) : ?>

		<ul class="history_col_dropdown">
			<?php
			foreach ( $customer_orders->orders as $customer_order ) {
				$order      = wc_get_order( $customer_order ); 
				$item_count = $order->get_item_count() - $order->get_item_count_refunded();

				$order_items           = $order->get_items( apply_filters( 'woocommerce_purchase_order_item_types', 'line_item' ) );
				$show_purchase_note    = $order->has_status( apply_filters( 'woocommerce_purchase_note_order_statuses', array( 'completed', 'processing' ) ) );
				$show_customer_details = is_user_logged_in() && $order->get_user_id() === get_current_user_id();

				$show_shipping = ! wc_ship_to_billing_address_only() && $order->needs_shipping_address();

			?>

				<li class="history_order_list">
					<div class="order_heading_id"><span class="order_lbl_id">Order ID:</span> <span class="order_id"><?php echo esc_html( _x( '#', 'hash before order number', 'woocommerce' ) . $order->get_order_number() ); ?></span><span class="iconify" data-icon="bx:bx-chevron-down" data-inline="false"></span></div>
					<div class="order_details">

						<!-- ORDER STATUS -->
						<div class="order_status"><span class="order_lbl_details">Order Status:</span> <?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?>. </div>

						<!-- ORDER DATE -->
						<div class="order_date"><span class="order_lbl_details">Order Date:</span> <time datetime="<?php echo esc_attr( $order->get_date_created()->date( 'c' ) ); ?>"><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></time> </div>

						<!-- ORDER ADDRESS -->
						<div class="order_delivery_address">
							<?php if ( $show_shipping ) : ?>
								<div class="order_billing_address">
									<?php endif; ?>
									<p class="order_lbl_details">Billing Address</p>
									<div class="delivery_details_info order_indent">
										<?php echo wp_kses_post( $order->get_formatted_billing_address( esc_html__( 'N/A', 'woocommerce' ) ) ); ?>

										<?php if ( $order->get_billing_phone() ) : ?>
											<p class="woocommerce-customer-details--phone"><?php echo esc_html( $order->get_billing_phone() ); ?></p>
										<?php endif; ?>

										<?php if ( $order->get_billing_email() ) : ?>
											<p class="woocommerce-customer-details--email"><?php echo esc_html( $order->get_billing_email() ); ?></p>
										<?php endif; ?>
									</div>
									<?php if ( $show_shipping ) : ?>
								</div>

								<div class="order_shipping_address">
									<p class="order_lbl_details">Shipping Address</p>
									<div class="delivery_details_info order_indent">
										<?php echo wp_kses_post( $order->get_formatted_shipping_address( esc_html__( 'N/A', 'woocommerce' ) ) ); ?>
									</div>
								</div>
							<?php endif; ?>
						</div>

						<!-- PAYMENT INFO -->
						<div class="order_payment_info">
							<p class="order_lbl_details">Payment Information</p>
							<table class="order_indent order_payment_tbl">
								<tbody>
									<tr>
										<td>Merchandise Subtotal</td>
										<td><?php echo $order->get_subtotal_to_display();?></td>
									</tr>
									<tr>
										<td>Shipping</td>
										<td><?php echo $order->get_shipping_to_display();?></td>
									</tr>
									<tr class="payment_total">
										<td>Order Total</td>
										<td class="bright_red_txt"><?php echo $order->get_formatted_order_total();?></td>
									</tr>
								</tbody>
							</table>
						</div>

						<!-- PAYMENT METHOD -->
						<div class="order_payment_method">
							<p class="order_lbl_details">Payment Method</p>
							<p class="order_indent"><?php echo $order->get_payment_method_title(); ?></p>
						</div>

						<!-- YOUR ORDER -->
						<div class="order_products">
							<p class="order_lbl_details">Your order</p>
							<table class="order_indent order_products_tbl">
								<tbody>
									<?php
									foreach ( $order->get_items() as $item_id => $item ) { 
										$product_id = $item->get_product_id();
										$product = wc_get_product( $product_id );
										?>
									   <tr>
											<td class="order_prod_img"><?php echo $product->get_image()?></td>
											<td class="order_prod_name"><?php echo $item->get_name(); ?></td>
											<td class="order_prod_totalqty"><span class="order_prod_quantity">x<?php echo $item->get_quantity();?></span><span class="order_prod_total"><?php echo $order->get_formatted_line_subtotal( $item );?></span></td>
										</tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</li>
			<?php
			}
			?>

		</ul>

	<?php do_action( 'woocommerce_before_account_orders_pagination' ); ?>

	<?php if ( 1 < $customer_orders->max_num_pages ) : ?>
		<div class="woocommerce-pagination woocommerce-pagination--without-numbers woocommerce-Pagination">
			<?php if ( 1 !== $current_page ) : ?>
				<a class="woocommerce-button woocommerce-button--previous woocommerce-Button woocommerce-Button--previous button" href="<?php echo esc_url( wc_get_endpoint_url( 'orders', $current_page - 1 ) ); ?>"><?php esc_html_e( 'Previous', 'woocommerce' ); ?></a>
			<?php endif; ?>

			<?php if ( intval( $customer_orders->max_num_pages ) !== $current_page ) : ?>
				<a class="woocommerce-button woocommerce-button--next woocommerce-Button woocommerce-Button--next button" href="<?php echo esc_url( wc_get_endpoint_url( 'orders', $current_page + 1 ) ); ?>"><?php esc_html_e( 'Next', 'woocommerce' ); ?></a>
			<?php endif; ?>
		</div>
	<?php endif; ?>



	<!-- NO ORDERS -->
	<?php else : ?>
		<p class="no_order_history">You haven’t placed any order yet.</p>
	<?php endif; ?>