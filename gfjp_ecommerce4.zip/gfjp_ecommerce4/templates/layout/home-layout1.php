        <section class="right_bg_pattern">
            <div class="featured_wrap col_float clearfix">
                <div class="two_col featured_col_content">
                    <span class="uppercase italic_font"><?php echo get_theme_mod('gfjp_ec4_home_featuredProduct1_subtitle_setting','Radiant Glow Series');?></span>
                    <h2><?php echo get_theme_mod('gfjp_ec4_home_featuredProduct1_title_setting','Radiant Glow <br>Day Cream');?></h2>
                    <ul class="brown_list">
                        <?php echo get_theme_mod('gfjp_ec4_home_featuredProduct1_desc_setting','<li>SPF 50</li> <li>Natural Ingredients</li> <li>Perfect for dull, dry, and sensitive skin</li> <li>Feel fresh all day</li> <li>Achieve that natural glow</li>');?>
                    </ul>
                </div>
                <div class="two_col">
                    <?php $homepage_prod1 = get_theme_mod( 'gfjp_ec4_home_featuredProduct1_img_setting', GFJP_IMG_URL. '/product_home_1.png' );?>
                    <img src="<?php echo ( is_int( $homepage_prod1 ) )? wp_get_attachment_url( $homepage_prod1 ) : $homepage_prod1; ?>" alt="">
                </div>
            </div>
        </section>

        <section class="left_bg_pattern">
            <div class="featured_wrap col_float clearfix">
                <?php $homepage_prod2 = get_theme_mod( 'gfjp_ec4_home_featuredProduct2_img_setting', GFJP_IMG_URL. '/product_home_2.png' );?>
                <div class="two_col desktop_col">
                    <img src="<?php echo ( is_int( $homepage_prod2 ) )? wp_get_attachment_url( $homepage_prod2 ) : $homepage_prod2; ?>" alt="">
                </div>
                <div class="two_col featured_col_content">
                    <span class="uppercase italic_font"><?php echo get_theme_mod('gfjp_ec4_home_featuredProduct2_subtitle_setting','Hydrating Boost Series');?></span>
                    <h2><?php echo get_theme_mod('gfjp_ec4_home_featuredProduct2_title_setting','All Natural <br>Moisturizing Boost');?></h2>
                    <ul class="brown_list">
                        <?php echo get_theme_mod('gfjp_ec4_home_featuredProduct2_desc_setting','<li>Hypoallergenic</li> <li>Natural Ingredients</li> <li>Perfect for dull, dry, and sensitive skin</li> <li>Has brigthening effect</li> <li>24-hour moisturizing effect</li>');?>
                    </ul>
                </div>
                <div class="two_col mobile_col">
                    <img src="<?php echo ( is_int( $homepage_prod2 ) )? wp_get_attachment_url( $homepage_prod2 ) : $homepage_prod2; ?>" alt="">
                </div>
            </div>
        </section>

        <section class="featured_products aligncenter">
            <div class="maxwidth">
                <div class="product_featured_icon">
                    <?php $fav_img = get_theme_mod( 'gfjp_ec4_home_favProd_img_setting', GFJP_IMG_URL. '/home/ico_cake.png' );?>
                    <img src="<?php echo ( is_int( $fav_img ) )? wp_get_attachment_url( $fav_img ) : $fav_img; ?>" alt="">
                </div>
                <h2><?php echo get_theme_mod('gfjp_ec4_home_favProd_title_setting','Our Customers’ Favorites')?></h2>
                    <ul class="product_featured_list flex"> 
                    <?php
                    $args = array(
                        'post_type' => 'product',
                        'orderby' => 'date',
                        'order' => 'DESC',
                        'posts_per_page' => 4,
                        'paged' => get_query_var( 'paged' ),
                        'meta_query' => array(
                            array(
                                'key' => 'featured-prod',
                                'value' => 'yes'
                            )
                        )
                    );
                    $products = new WP_Query( $args );?>
                    
                    <?php if ( $products->have_posts() ) :
                        while ( $products->have_posts() ) : $products->the_post(); ?>
                            <li>
                                <?php $prod_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );?>
                                <?php $temp_image = wc_placeholder_img_src('full'); ?>
                                <div class="product_col_main aligncenter" data-id="<?php echo $post->ID; ?>">
                                    <a href="<?php echo get_permalink();?>"><div class="product_image" style="background-image: url(<?php echo $prod_image ? $prod_image[0] : $temp_image ?>)">
                                        <div class="inner_product_hover">
                                            <span class="btn_default btn_small uppercase">View Product</span>
                                        </div>
                                    </div></a>
                                    <div class="product_info">
                                        <?php
                                        $terms = get_the_terms( $post->ID, 'product_cat' );
                                        if ( $terms && ! is_wp_error( $terms ) ) :
                                            $cat_links = array();
                                            foreach ( $terms as $term ) {
                                                $cat_links[] = $term->name;
                                            }
                                            $on_cat = join( ", ", $cat_links );
                                            ?>
                                            <p class="product_category uppercase"><?php echo $on_cat; ?></p>
                                        <?php endif; ?>
                                        <a href="<?php echo get_permalink();?>"><h3 class="product_title alegreya_regular"><?php the_title(); ?></h3></a>
                                        <?php $product = wc_get_product( get_the_ID() );?>
                                        <p class="product_price alegreya_bold"><?php echo $product->get_price_html(); ?></p>
                                    </div>
                                </div>
                            </li>
                            <?php
                        endwhile;
                        else:
                            echo '<p class="aligncenter">No products has been found....</p>';
                        wp_reset_postdata();
                    endif; ?>
                 </ul>
            </div>
        </section>

        <section class="left_bg_pattern shop_section">
            <div class="maxwidth clearfix">
                <?php $shop_img = get_theme_mod( 'gfjp_ec4_home_shopProd_img_setting', GFJP_IMG_URL. '/home/bg_shop_now.jpg' );?>
                <div class="shop_now_img" style="background-image:url(<?php echo ( is_int( $shop_img ) )? wp_get_attachment_url( $shop_img ) : $shop_img; ?>);"></div>
                <div class="shop_now_right">
                    <h2><?php echo get_theme_mod('gfjp_ec4_home_shopProd_title_setting','Products made <br>just for you')?></h2>
                    <p class="italic_font"><?php echo get_theme_mod('gfjp_ec4_home_shopProd_desc_setting','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ultricies amet pellentesque vulputate sed id.')?></p>
                    <a class="btn_default uppercase" href="<?php echo home_url();?>/shop">Shop Now</a>
                </div>
            </div>
        </section>