        <section class="left_bg_product" id="first_row_product">
            <div class="maxwidth flex">
                <div class="img_featured_pattern">
                    <div class="product_category">
                        <span class="uppercase"><?php echo get_theme_mod('gfjp_ec4_home2_category1_cat_setting','Bath & Body')?></span>
                    </div>
                    <div class="product_cat_img">
                        <?php $home2_cat1_img = get_theme_mod( 'gfjp_ec4_home2_category1_img_setting', GFJP_IMG_URL. '/home/bg_bath.jpg' );  ?>
                        <img src="<?php echo ( is_int( $home2_cat1_img ) )? wp_get_attachment_url( $home2_cat1_img, 'home_category_size' ) : $home2_cat1_img; ?>" alt=""/>
                    </div>
                </div>
                <div class="product_featured_details">
                    <h2><?php echo get_theme_mod('gfjp_ec4_home2_category1_tl_setting','Always stay fresh')?></h2>
                    <p><?php echo get_theme_mod('gfjp_ec4_home2_category1_desc_setting','Aliquam purus habitasse consequat felis sociis lobortis ullamcorper eget. Pretium turpis felis ut morbi congue amet. Vulputate aliquet ullamcorper hac eu proin lorem mi.')?></p>
                    <a class="btn_default uppercase btn_border" href="<?php echo home_url(), get_theme_mod('gfjp_ec4_home2_category1_btnlnk_setting','/shop')?>"><?php echo get_theme_mod('gfjp_ec4_home2_category1_btntxt_setting','Shop Now');?></a>
                </div>
            </div>
        </section>

        <section class="right_bg_product" id="second_row_product">
            <div class="maxwidth flex">
                <div class="product_featured_details desktop_featured">
                    <h2><?php echo get_theme_mod('gfjp_ec4_home2_category2_tl_setting','Glow naturally')?></h2>
                    <p><?php echo get_theme_mod('gfjp_ec4_home2_category2_desc_setting','Aliquam purus habitasse consequat felis sociis lobortis ullamcorper eget. Pretium turpis felis ut morbi congue amet. Vulputate aliquet ullamcorper hac eu proin lorem mi.')?></p>
                    <a class="btn_default uppercase btn_border" href="<?php echo home_url(), get_theme_mod('gfjp_ec4_home2_category2_btnlnk_setting','/shop')?>"><?php echo get_theme_mod('gfjp_ec4_home2_category2_btntxt_setting','Shop Now');?></a>
                </div>
                <div class="img_featured_pattern">
                    <div class="product_category">
                        <span class="uppercase"><?php echo get_theme_mod('gfjp_ec4_home2_category2_cat_setting','Skin Care')?></span>
                    </div>
                    <div class="product_cat_img">
                        <?php $home2_cat2_img = get_theme_mod( 'gfjp_ec4_home2_category2_img_setting', GFJP_IMG_URL. '/home/bg_skin.jpg' );  ?>
                        <img src="<?php echo ( is_int( $home2_cat2_img ) )? wp_get_attachment_url( $home2_cat2_img, 'home_category_size' ) : $home2_cat2_img; ?>" alt=""/>
                    </div>
                </div>
                <div class="product_featured_details mobile_featured">
                    <h2><?php echo get_theme_mod('gfjp_ec4_home2_category2_tl_setting','Glow naturally')?></h2>
                    <p><?php echo get_theme_mod('gfjp_ec4_home2_category2_desc_setting','Aliquam purus habitasse consequat felis sociis lobortis ullamcorper eget. Pretium turpis felis ut morbi congue amet. Vulputate aliquet ullamcorper hac eu proin lorem mi.')?></p>
                    <a class="btn_default uppercase btn_border" href="<?php echo home_url(), get_theme_mod('gfjp_ec4_home2_category2_btnlnk_setting','/shop')?>"><?php echo get_theme_mod('gfjp_ec4_home2_category2_btntxt_setting','Shop Now');?></a>
                </div>
            </div>
        </section>

        <section class="left_bg_product" id="third_row_product">
            <div class="maxwidth flex">
                <div class="img_featured_pattern">
                    <div class="product_category">
                        <span class="uppercase"><?php echo get_theme_mod('gfjp_ec4_home2_category3_cat_setting','Make Up')?></span>
                    </div>
                    <div class="product_cat_img">
                        <?php $home2_cat3_img = get_theme_mod( 'gfjp_ec4_home2_category3_img_setting', GFJP_IMG_URL. '/home/bg_makeup.jpg' );  ?>
                        <img src="<?php echo ( is_int( $home2_cat3_img ) )? wp_get_attachment_url( $home2_cat3_img, 'home_category_size' ) : $home2_cat3_img; ?>" alt=""/>
                    </div>
                </div>
                <div class="product_featured_details">
                    <h2><?php echo get_theme_mod('gfjp_ec4_home2_category3_tl_setting','Pure Beauty')?></h2>
                    <p><?php echo get_theme_mod('gfjp_ec4_home2_category3_desc_setting','Aliquam purus habitasse consequat felis sociis lobortis ullamcorper eget. Pretium turpis felis ut morbi congue amet. Vulputate aliquet ullamcorper hac eu proin lorem mi.')?></p>
                    <a class="btn_default uppercase btn_border" href="<?php echo home_url(), get_theme_mod('gfjp_ec4_home2_category3_btnlnk_setting','/shop')?>"><?php echo get_theme_mod('gfjp_ec4_home2_category3_btntxt_setting','Shop Now');?></a>
                </div>
            </div>
        </section>

        <section class="featured_products aligncenter">
            <div class="maxwidth">
                <div class="product_featured_icon">
                    <?php $fav_img = get_theme_mod( 'gfjp_ec4_home_favProd_img_setting', GFJP_IMG_URL. '/home/ico_cake.png' );?>
                    <img src="<?php echo ( is_int( $fav_img ) )? wp_get_attachment_url( $fav_img ) : $fav_img; ?>" alt="">
                </div>
                <h2><?php echo get_theme_mod('gfjp_ec4_home_favProd_title_setting','Our Customers’ Favorites')?></h2>
                    <ul class="product_featured_list flex"> 
                    <?php
                        $args = array(
                        'post_type' => 'product',
                        'orderby' => 'date',
                        'order' => 'DESC',
                        'posts_per_page' => 8,
                        'paged' => get_query_var( 'paged' ),
                        'meta_query' => array(
                            array(
                                'key' => 'featured-prod',
                                'value' => 'yes'
                            )
                        )
                    );
                    $products = new WP_Query( $args );?> 
                    
                    <?php if ( $products->have_posts() ) :
                        while ( $products->have_posts() ) : $products->the_post(); ?>
                            <li>
                            <?php $prod_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );?>
                            <?php $temp_image = wc_placeholder_img_src('full'); ?>
                                <div class="product_col_main aligncenter" data-id="<?php echo $post->ID; ?>">
                                    <a href="<?php echo get_permalink();?>"><div class="product_image" style="background-image: url(<?php echo $prod_image ? $prod_image[0] : $temp_image ?>)">
                                        <div class="inner_product_hover">
                                            <span class="btn_default btn_small uppercase">View Product</span>
                                        </div>
                                    </div></a>
                                    <div class="product_info">
                                        <?php
                                        $terms = get_the_terms( $post->ID, 'product_cat' );
                                        if ( $terms && ! is_wp_error( $terms ) ) :
                                            $cat_links = array();
                                            foreach ( $terms as $term ) {
                                                $cat_links[] = $term->name;
                                            }
                                            $on_cat = join( ", ", $cat_links );
                                            ?>
                                            <p class="product_category uppercase"><?php echo $on_cat; ?></p>
                                        <?php endif; ?>
                                        <a href="<?php echo get_permalink();?>"><h3 class="product_title alegreya_regular"><?php the_title(); ?></h3></a>
                                        <?php $product = wc_get_product( get_the_ID() );?>
                                        <p class="product_price alegreya_bold"><?php echo $product->get_price_html(); ?></p>
                                    </div>
                                </div>
                            </li>
                        <?php
                        endwhile;
                        else:
                            echo '<p class="aligncenter">No products has been found....</p>';
                        wp_reset_postdata();
                        endif; ?>
                    </ul>
                <a class="btn_default uppercase" href="<?php echo home_url()?>/shop">All Products</a>
            </div>
        </section>