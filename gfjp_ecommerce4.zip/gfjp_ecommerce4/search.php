<?php get_header(); ?>
    <main>
    <?php
    $s=get_search_query();
    $args = array( 's' =>$s );
    $default_banner = get_theme_mod( 'gfjp_ec4_gen_banner_background_setting', GFJP_IMG_URL. '/bg_banner.jpg' );
    ?>
    <div class="inner_banner" style="background-image: url(<?php echo ( is_int( $default_banner ) )? wp_get_attachment_url( $default_banner ) : $default_banner; ?>);"></div>
    
        <div class="inner_content faq_content">
			<section class="maxwidth ">
                <?php
                $the_query = new WP_Query( $args );
                if ( $the_query->have_posts() ) {
                    _e("<h2 class='aligncenter'>Search Results for: ".get_query_var('s')."</h2>");
                    while ( $the_query->have_posts() ) {
                       $the_query->the_post();
                        ?>
                        <li>
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </li>
                        <?php
                    }
                }else{ ?>
                    <h2 class='aligncenter'>Nothing Found</h2>
                    <div class="alert alert-info">
                      <p class="aligncenter">Sorry, but nothing matched your search criteria. Please try again with some different keywords.</p>
                    </div>
                <?php } ?>
            </section>
        </div>
    </main>
<?php get_footer(); ?>