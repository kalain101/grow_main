<?php get_header();?>

	<main>
	<?php $default_banner = get_theme_mod( 'gfjp_ec4_gen_banner_background_setting', GFJP_IMG_URL. '/bg_banner.jpg' ); ?>
	<?php $forgot_banner  = get_theme_mod( 'gfjp_ec4_forgot_banner_background_setting', $default_banner); ?>
	<?php $captcha_key    = get_theme_mod('gfjp_ec4_recaptha_sitekey_setting',''); ?>

	<?php if ($forgot_banner !== '' ) { ?>
		<div class="inner_banner" style="background-image: url(<?php echo ( is_int( $forgot_banner ) )? wp_get_attachment_url( $forgot_banner ) : $forgot_banner; ?>);"></div>
	<?php } else { ?>
		<div class="inner_banner" style="background-image: url(<?php echo ( is_int( $default_banner ) )? wp_get_attachment_url( $default_banner ) : $default_banner; ?>);"></div>
	<?php } ?>

		<div class="inner_content reset_content aligncenter">
			<section class="maxwidth">
				<h1><?php echo get_theme_mod('gfjp_ec4_forgot_title_setting','Reset your password')?></h1>
				<p class="form_sub_label"><?php echo get_theme_mod('gfjp_ec4_forgot_subtitle_setting','We will send you an email to reset your password.')?></p>

				<div id="message"></div>
				<form id="resetPwordForm" method="post" class="reset_pword_form" autocomplete="off">
					<?php
					if ( function_exists( 'wp_nonce_field' ) ) 
						wp_nonce_field( 'rs_user_lost_password_action', 'rs_user_lost_password_nonce' );
					?>
					<div class="floating_label_wrap">
						<input type="email" name="user_login" id="user_login" class="form-control reset_email floating_label_field input" value="<?php echo esc_attr($user_login); ?>" placeholder="Email" />
						<label class="floating_label">Email</label>
					</div>
                    
                    <?php if ($captcha_key !=='') { ?>
					    <div class="g-recaptcha" data-sitekey="<?php echo $captcha_key ?>" required="required" required></div>
					<?php } else { ?>
					    <div id="message"><p>Please setup Google site key first on your theme settings....</p></div>
					<?php } ?>
					
					<?php do_action( 'lostpassword_form' ); ?>
			
					<input type="submit" name="wp-submit" id="wp-submit" class="btn_default uppercase" value="Submit" />
					<img src="<?php echo GFJP_IMG_URL ?>/ajax-loader.gif" id="preloader" alt="Preloader" />
				</form>

			</section>
		</div>

	</main>

<?php get_footer(); ?>