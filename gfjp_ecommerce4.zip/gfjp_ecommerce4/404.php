<?php get_header(); ?>
    <main role="main">

        <div class="inner_content">
            <h1 class="aligncenter">Page Not Found!</h1>
        </div>
    </main>

<?php get_footer();