
<?php get_header('shop'); 

defined( 'ABSPATH' ) || exit;

global $product;

$product = wc_get_product();
$prod_id = $product->get_id();

$default_banner = get_theme_mod( 'gfjp_ec4_gen_banner_background_setting', GFJP_IMG_URL. '/bg_banner.jpg' );
$product_banner = get_theme_mod( 'gfjp_ec4_product_banner_background_setting', $default_banner);

?>  
        <main>

        <?php if ($product_banner !== '' ) { ?>
            <div class="inner_banner" style="background-image: url(<?php echo ( is_int( $product_banner ) )? wp_get_attachment_url( $product_banner ) : $product_banner; ?>);"></div>
        <?php } else { ?>
            <div class="inner_banner" style="background-image: url(<?php echo ( is_int( $default_banner ) )? wp_get_attachment_url( $default_banner ) : $default_banner; ?>);"></div>
        <?php } ?>

            <div class="inner_content single_product_content">
                <div id="product-<?php the_ID(); ?>" <?php wc_product_class( '', $product ); ?>>
                    <div class="maxwidth flex">

                        <?php do_action( 'woocommerce_before_single_product' );?>

                        <div class="product_breadcrumb uppercase">
                            <a href="<?php echo home_url();?>">Home</a> 
                            <span class="iconify" data-icon="bx:bx-chevron-right" data-inline="false"></span> 
                            <div class="single_cat"><?php echo wc_get_product_category_list( $product->get_id(), ', ', '<span class="posted_in">' . _n( '', '', count( $product->get_category_ids() ), 'woocommerce' ) . ' ', '</span>' ); ?> </div> 
                            <span class="iconify" data-icon="bx:bx-chevron-right" data-inline="false"></span> 
                            <a href="#"><?php echo the_title();?></a>
                        </div>

                        <div class="product_col_image">
                            <?php
                            if ( ! function_exists( 'wc_get_gallery_image_html' ) ) {
                                return;
                            }
                            $columns           = apply_filters( 'woocommerce_product_thumbnails_columns', 4 );
                            $post_thumbnail_id = $product->get_image_id();
                            $wrapper_classes   = apply_filters(
                                'woocommerce_single_product_image_gallery_classes',
                                array(
                                    'woocommerce-product-gallery',
                                    'woocommerce-product-gallery--' . ( $product->get_image_id() ? 'with-images' : 'without-images' ),
                                    'woocommerce-product-gallery--columns-' . absint( $columns ),
                                    'images',
                                )
                            );
                            ?>
                            <div class="<?php echo esc_attr( implode( ' ', array_map( 'sanitize_html_class', $wrapper_classes ) ) ); ?>" data-columns="<?php echo esc_attr( $columns ); ?>" style="opacity: 0; transition: opacity .25s ease-in-out;">
                                <figure class="woocommerce-product-gallery__wrapper">
                                    <?php
                                    if ( $product->get_image_id() ) {
                                        $html = wc_get_gallery_image_html( $post_thumbnail_id, true );
                                    } else {
                                        $html  = '<div class="woocommerce-product-gallery__image--placeholder">';
                                        $html .= sprintf( '<img src="%s" alt="%s" class="wp-post-image" />', esc_url( wc_placeholder_img_src( 'woocommerce_single' ) ), esc_html__( 'Awaiting product image', 'woocommerce' ) );
                                        $html .= '</div>';
                                    }

                                    echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', $html, $post_thumbnail_id );

                                    do_action( 'woocommerce_product_thumbnails' );
                                    ?>
                                </figure>
                            </div>  

                        </div>

                        <section class="product_col_info">

                            <?php do_action( 'woocommerce_single_product_summary' ); ?>

                            <!-- PRODUCT BOTTOM -->
                            <div class="product_bottom_details">
                                <p><?php echo get_post_meta($post->ID, 'addition_info_1', true); ?></p>
                                <p><?php echo get_post_meta($post->ID, 'addition_info_2', true); ?></p>
                            </div>
                            <!-- END PRODUCT BOTTOM -->
                        </section>  
                    </div>
                </div>
            </div>

            <div class="modal_cart_container woocommerce widget_shopping_cart"> 
                <div class="modal_cart_filter" hidden="hidden"></div>
                <div class="modal_cart widget_cart" hidden="hidden">
                    <div class="modal_cart_header flex">
                        <div class="modal_cart_close">
                            <span class="iconify" data-icon="bx:bx-chevron-right" data-inline="false"></span>
                        </div>
                        <div class="modal_cart_title alegreya_bold">Cart</div>
                    </div>
                    <div class="widget_shopping_cart_content">
                        <div class="modal_cart_body">
                            <ul class="woocommerce-mini-cart cart_list ">
                                <li class="woocommerce-mini-cart-item mini_cart_item">
                                    
                                </li>
                            </ul>
                        </div>
                        <div class="modal_cart_footer">
                            <div class="modal_cart_subtotal">
                                <p class="woocommerce-mini-cart__total total uk-clearfix">
                                    <strong>Subtotal:</strong> 
                                    <span class="woocommerce-Price-amount amount">
                                    </span>
                                </p>
                            </div>
                            <div class="modal_cart_btn woocommerce-mini-cart__buttons buttons">
                                <a class="btn_default uppercase btn_border" href="#">View Cart</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

<?php get_footer('shop'); ?>



