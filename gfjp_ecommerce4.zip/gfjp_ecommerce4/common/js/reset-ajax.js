
jQuery(document).ready(function($) {
    
    // for lost password
    $("#resetPwordForm").submit(function(){

        response = grecaptcha.getResponse();
        if(response.length == 0) { 
            alert("Please verify you are human!"); 
            event.preventDefault();
            return false;
        }
        var submitP = $("#wp-submit"),
            preloaderP = $(".reset_content #preloader"),
            messageP = $(".reset_content #message"),
            
            contentsP = {
                action:     'lost_pass',
                nonce:      this.rs_user_lost_password_nonce.value,
                user_login: this.user_login.value
            };
        submitP.addClass('disabled');
        preloaderP.css({'visibility':'visible'});
        
        $.post( theme_ajax.url, contentsP, 
        function( data ){
            submitP.removeClass('disabled');
            preloaderP.css({'visibility':'hidden'});
            messageP.html( data );
        });
        return false;
    });
    
    // for reset password
    $("#resetPasswordForm").submit(function(e){
		$('#resetPasswordForm #message').show().html(theme_ajax.loadingmessage);
        $.ajax({
        	type: 'POST',
            dataType: 'json',
            url: theme_ajax.url,
            data: {
            	'action':     'reset_pass',
            	'rs_user_reset_password_nonce': $('#resetPasswordForm #rs_user_reset_password_nonce').val(),
                'pass1': $('#resetPasswordForm #pass1').val(),
                'pass2': $('#resetPasswordForm #pass2').val(),
                'user_key': $('#resetPasswordForm #user_key').val(),
                'user_login': $('#resetPasswordForm #user_login').val(),
            },
            success: function(data){ 
            	$('#resetPasswordForm #message').html(data.message);
            	if (data.reset == true){
                    document.location.href = theme_ajax.redirecturl;
                }
            }
        });
        e.preventDefault();
    });
});