$(document).ready(function(){

	var close = $('.modal_close');
	var modal = $('#project_modal');

	$('.project_content').on('click', function(event){
		modal_title = $(this).find('.project_name').text();
    modal_description = $(this).find('.project_description').text();
    modal_img = $(this).find('img').attr('src');
    modal_client = $(this).find('.project_client').text();
    modal_category = $(this).find('.project_category').text();
    modal_date = $(this).find('.project_date').text();

    console.log(modal_img);
    $('.modal_project_img_con img').attr('src', modal_img);
    $('.modal_project_name').text(modal_title);
    $('.modal_project_desc').text(modal_description);
    $('.modal_project_client').html("<span>Client: </span>" + modal_client);
    $('.modal_project_category').html("<span>Category: </span>" + modal_category);
    $('.modal_project_date').html("<span>Date: </span>" + modal_date);
		modal.addClass('active');
	});

	close.on('click', function(event){
		modal.removeClass('active');
	});

	window.onclick = function(event) {
	  if (event.target == modal) {
	    modal.style.display = "none";
	  }
	}

});