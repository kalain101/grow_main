$(document).ready(function($){
	$('.woocommerce .woocommerce-billing-fields__field-wrapper .form-row').each(function() {
	    var inputText = $('.input-text', this)
	    $('label', this).insertAfter(inputText);
	});
	$('.woocommerce .woocommerce-shipping-fields__field-wrapper .form-row').each(function() {
	    var inputText = $('.input-text', this)
	    $('label', this).insertAfter(inputText);
	});
});