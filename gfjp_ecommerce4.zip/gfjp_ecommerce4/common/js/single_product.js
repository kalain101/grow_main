$(document).ready(function($){
	$('form.cart').on('submit', function (e) {
	    e.preventDefault();

	    $('.cart').block({
	        message: null,
	        overlayCSS: {
	            cursor: 'none',
	            opacity: 0.3
	        }
	    });
	    var product_url = window.location, form = $(this);

	    $.post(product_url, form.serialize() + '&_wp_http_referer=' + product_url, function (result) {
	        var cart_dropdown = $('.widget_shopping_cart', result)
	        // update dropdown cart
	        $('.widget_shopping_cart').replaceWith(cart_dropdown);
	        // update fragments
	        $.ajax($warp_fragment_refresh);
	        $('.cart').unblock();

	    });
	});

	// Ajax add to cart on the product page
	var $warp_fragment_refresh = {
	    url: wc_cart_fragments_params.wc_ajax_url.toString().replace( '%%endpoint%%', 'get_refreshed_fragments' ),
	    type: 'POST',
	    success: function( data ) {
	        if ( data && data.fragments ) {
	            $.each( data.fragments, function( key, value ) {
	                $( key ).replaceWith( value );
	            });
	            $( document.body ).trigger( 'wc_fragments_refreshed' );

	            $('.modal_cart_filter').fadeIn(200);
        		$('.modal_cart').addClass('active-cart');
	        }
	    }
	};

	// Close cart popup
	$(document).mousemove(function(event){
		$('.modal_cart_close .iconify, .modal_cart_filter').on('click', function() {
	        $('.modal_cart_filter').fadeOut(200);
	        $('.modal_cart').removeClass('active-cart');
	        $( document.body ).trigger( 'wc_fragments_refreshed' );
	    });
	});

	// Buy It now btn events
	$('.variation_id').on('change', function(){
        if( '' != $('.variation_id').val() ) {           
			var var_id   = $('.variation_id').val();
			var qty 	 = $('.quantity .qty').val();

			$('.var_id').attr("href",object_name.home_urls + "/checkout/?add-to-cart=" + var_id + "&quantity=" + qty);
			$('body').addClass('active_buynow');
        } else {
        	$('body').removeClass('active_buynow');
        }
    });

	$('.quantity .qty').on('change', function(){
        if( '' != $('.variation_id').val() ) {
            var var_id  = $('.variation_id').val();
            var qty     = $('.quantity .qty').val();

			$('.var_id').attr("href",object_name.home_urls + "/checkout/?add-to-cart=" + var_id + "&quantity=" + qty);
        }
    });
});