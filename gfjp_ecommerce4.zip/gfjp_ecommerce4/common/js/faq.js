$(document).ready(function(){

    $('.faq_accordion .faq_question').click(function(){
        var answer = $(this).next();
        $(this).children('.faq_inner_question').toggleClass('brown');
        if (answer.is(':hidden')){
            answer.slideDown();
            $(this).children('.iconify').css({
                'transform': 'rotate(180deg)',
                '-moz-transition': 'all 0.2s ease-in-out 0s',
                '-webkit-transition': 'all 0.2s ease-in-out 0s',
                'transition': 'all 0.2s ease-in-out 0s'
            });
        }
        else{
            answer.slideUp();
            $(this).children('.iconify').css({
                'transform': 'rotate(360deg)',
                '-moz-transition': 'all 0.2s ease-in-out 0s',
                '-webkit-transition': 'all 0.2s ease-in-out 0s',
                'transition': 'all 0.2s ease-in-out 0s'
            });
        }
    });
    
});