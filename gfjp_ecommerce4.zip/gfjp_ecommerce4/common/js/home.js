$(document).ready(function(){
	$('.carousel_images_list').slick({
		arrows: false,
        dots: true,
		slidesToShow: 1,
		slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 5000
	});
});