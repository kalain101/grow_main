jQuery(document).ready(function($){

    $('.history_col_dropdown .order_heading_id').click(function(){
        var order = $(this).next();
        $(this).children('.order_lbl_id').toggleClass('brown');
        if (order.is(':hidden')){
            order.slideDown();
            $(this).children('.iconify').css({
                'transform': 'rotate(180deg)',
                '-moz-transition': 'all 0.2s ease-in-out 0s',
                '-webkit-transition': 'all 0.2s ease-in-out 0s',
                'transition': 'all 0.2s ease-in-out 0s'
            });
        }
        else{
            order.slideUp();
            $(this).children('.iconify').css({
                'transform': 'rotate(360deg)',
                '-moz-transition': 'all 0.2s ease-in-out 0s',
                '-webkit-transition': 'all 0.2s ease-in-out 0s',
                'transition': 'all 0.2s ease-in-out 0s'
            });
        }
    });


    $('.menu_account_lbl .iconify').click(function(){
        $('.myaccount_list').slideToggle(200);
        $(this).toggleClass('active_account');
    });

    $('.woocommerce form .form-row').each(function() {
        var inputText = $('.input-text', this);
        var billstate = $('#billing_state', this);
        var shipstate = $('#shipping_state', this);
        $('label', this).insertAfter(inputText);
        $('label', this).insertAfter(billstate);
        $('label', this).insertAfter(shipstate);
    });
    
});