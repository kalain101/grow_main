jQuery(document).ready(function($){
    $('#newsletter_form').on('submit', function(e){
        /*
        e.preventDefault();
        var that = $(this),
        url = that.attr('action'),
        type = that.attr('method');
        var newsletter_email = $('#newsletter_email').val();
        var newsletter_security = $('#newsletter_security').val();
        $('#newsletter_form .newsletter_msg').show().html(ajax_object_newsletter.lettermessage);

        $.ajax({
            url: ajax_object_newsletter.ajax_url,
            type:"POST",
            dataType:'json',
            data: {
                action:'set_newsletter_form',
                newsletter_email:newsletter_email,
                newsletter_security:newsletter_security,
            },   
            success: function(data){
                $(".success_msg").css("display","block");
                $('#newsletter_form .newsletter_msg').html(data.letter_message);
            }, 
        });
        $('#newsletter_form')[0].reset();
        */
        $('#newsletter_form .newsletter_msg').show().html(ajax_object_newsletter.lettermessage);
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: ajax_object_newsletter.ajax_url,
            data: { 
                'action': 'set_newsletter_form', //calls wp_ajax_nopriv_ajaxlogin
                'newsletter_email': $('#newsletter_form #newsletter_email').val(),
                'newsletter_security': $('#newsletter_form #newsletter_security').val(),
            },
            success: function(data){
                $('#newsletter_form .newsletter_msg').html(data.message);
                if (data.newsletter == true){
                    document.location.href = ajax_object_newsletter.redirecturl;
                }
            }
        });
        e.preventDefault();
    });
});