jQuery(document).ready(function($){

	if ($('#adminmenu #toplevel_page_newsletter .wp-submenu li').hasClass("current")) {
	    $("#adminmenu #toplevel_page_newsletter").addClass("wp-has-current-submenu");
	}

});