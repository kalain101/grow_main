jQuery(document).ready(function($){
    $('#signupForm').on('submit', function(e){
        $('#signupForm .msg_display').show().html(ajax_signup_object.loadingmessage);
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: ajax_signup_object.ajaxurl,
            data: { 
                'action': 'ajaxsignup', //calls wp_ajax_nopriv_ajaxlogin
                'gfjp_ec4_user_login': $('#signupForm #gfjp_ec4_user_login').val(), 
                'gfjp_ec4_fname': $('#signupForm #gfjp_ec4_fname').val(), 
                'gfjp_ec4_lname': $('#signupForm #gfjp_ec4_lname').val(),
                'gfjp_ec4_email': $('#signupForm #gfjp_ec4_email').val(),
                'gfjp_ec4_pword': $('#signupForm #password').val(),
                'gfjp_ec4_pword_confirm': $('#signupForm #password_again').val(),
                'security': $('#signupForm #security').val(),
            },
            success: function(data){
                $('#signupForm .msg_display').html(data.message);
                if (data.signup == true){
                    document.location.href = ajax_signup_object.redirecturl;
                }
            }
        });
        e.preventDefault();
    });
});