$(document).ready(function(){

	$('.header_search').click(function(){
	    $('.top_search_header').slideToggle('fast');
	    $('.top_search_header').toggleClass('search_active');

	    if($('.mobile_header').hasClass('fixed_header')){
			$('.mobile_header').toggleClass('active_header_search');
	    	$('.top_search_header').toggleClass('active_header_bar');
	    }
	});

	$('.close_form').click(function(){
		$('.top_search_header').slideToggle('fast');
		$('.top_search_header').toggleClass('search_active');

		if($('.mobile_header').hasClass('fixed_header')){
			$('.mobile_header').toggleClass('active_header_search');
	    	$('.top_search_header').toggleClass('active_header_bar');
	    }
	});

	$('.mobile_nav_header .mobile_main_menu .shop_megamenu > a').click(function(){
	    $('.mobile_nav_header .shop_sub_megamenu').slideToggle();
	});
	$('.mobile_menu_header .menu').click(function(){
	    $('.mobile_nav_header').slideToggle();
	    $(this).toggleClass('active');
	});

	$(window).scroll(function(){
	  var sticky = $('.mobile_header');
	  var search_sticky = $('.top_search_header');
	      scroll = $(window).scrollTop();

	  if (scroll >= 200) sticky.addClass('fixed_header');
	  else sticky.removeClass('fixed_header');

	  if (scroll >= 200) search_sticky.addClass('fixed_search');
	  else search_sticky.removeClass('fixed_search');
	});


	var pagetop = $('.back-to-top-con');

	$(window).scroll(function () {
		if ($(this).scrollTop() > 100) {
			pagetop.fadeIn();
		} else {
			pagetop.fadeOut();
		}
	});

	pagetop.click(function () {
		$('body, html').animate({ scrollTop: 0 }, 500);
		return false;
	});
	

	$(window).scroll(function() {
		scrollHeight = $(document).height();
		scrollPosition = $(window).height() + $(window).scrollTop();
		bottomHeight = $(".footer_bootom_bar").innerHeight();
		footerHeight = bottomHeight + 20;
		if ( scrollHeight - scrollPosition  <= footerHeight ) {
			$(".back-to-top-con").css({
				"position":"fixed",
				"bottom": footerHeight,
			});
			console.log(footerHeight);
		} else {
		var mq2 = window.matchMedia( "(max-width: 768px)" );
		var mq3 = window.matchMedia( "(max-width: 360px)" );
		if (mq2.matches) {
			$(".back-to-top-con").css({
				"position":"fixed",
				"bottom": "20px",
			});
		}
		else if (mq3.matches) {
			$(".back-to-top-con").css({
				"position":"fixed",
				"bottom": "20px",
			});
		}
		else{
			$(".back-to-top-con").css({
				"position":"fixed",
				"bottom": "20px",
			});
			}
		}
	});


	$.fn.toggleAttr = function(attr, attr1, attr2) {
	  return this.each(function() {
	    var self = $(this);
	    if (self.attr(attr) == attr1)
	      self.attr(attr, attr2);
	    else
	      self.attr(attr, attr1);
	  });
	};
	$(".toggle_pword").click(function() {
	    $(this).toggleAttr('data-icon', 'carbon:view-filled', 'carbon:view-off-filled');
	    var input = $($(this).attr("data-toggle"));
	    if (input.attr("type") == "password") {
	        input.attr("type", "text");
	    } else {
	        input.attr("type", "password");
	    }
	});

	$(window).resize(function() {
	    $('.mobile_nav_header').height($(window).height() - 46);
	});
	$(window).bind("load",function(){
		$('.mobile_nav_header').height($(window).height() - 46);
	});

});