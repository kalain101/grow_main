jQuery(document).ready(function($){
    $('#contactForm').on('submit', function(e){
        e.preventDefault();
        var that = $(this),
        url = that.attr('action'),
        type = that.attr('method');
        var user_name = $('.user_name').val();
        var user_email = $('.user_email').val();
        var user_message = $('.user_message').val();
        $.ajax({
            url: ajax_object_contact.ajax_url,
            type:"POST",
            dataType:'text',
            data: {
                action:'set_form',
                user_name:user_name,
                user_email:user_email,
                user_message:user_message,
            },   
            success: function(response){
                $(".success_msg").css("display","block");
            }, 
            error: function(data){
                $(".error_msg").css("display","block");      
            }
        });
        $('#contactForm')[0].reset();
    });
});