<?php get_header(); ?>

		<main>

        <?php $default_banner = get_theme_mod( 'gfjp_ec4_gen_banner_background_setting', GFJP_IMG_URL. '/bg_banner.jpg' ); ?>
        <?php $shop_banner = get_theme_mod( 'gfjp_ec4_shop_banner_background_setting', $default_banner); ?>

        <?php if ($shop_banner !== '' ) { ?>
			<section class="all_shop_banner shop_banner wrap_space" style="background-image: url(<?php echo ( is_int( $shop_banner ) )? wp_get_attachment_url( $shop_banner ) : $shop_banner; ?>);"></section>
        <?php } else { ?>
            <section class="all_shop_banner shop_banner wrap_space" style="background-image: url(<?php echo ( is_int( $default_banner ) )? wp_get_attachment_url( $default_banner ) : $default_banner; ?>);"></section>
        <?php } ?>

			<div class="featured_products aligncenter maxwidth">
				<ul class="product_featured_list flex"> 
				<?php
                $args = array(
                    'post_type' => 'product',
                    'orderby' => 'date',
                    'order' => 'DESC',
                    'posts_per_page' => -1,
                    'paged' => get_query_var( 'paged' ),
                );
                //ob_start();
                $products = new WP_Query( $args );?> 
                
                <?php if ( $products->have_posts() ):
                    while ( $products->have_posts() ) : $products->the_post(); ?>
                        <li>
                    		<?php $prod_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' );?>
                            <?php $temp_image = wc_placeholder_img_src('full'); ?>
    						<div class="product_col_main aligncenter" data-id="<?php echo $post->ID; ?>">
    							<a href="<?php echo get_permalink();?>">
                                    <div class="product_image" style="background-image: url(<?php echo $prod_image ? $prod_image[0] : $temp_image ?>)">
    									<div class="inner_product_hover">
    											<span class="btn_default btn_small uppercase">View Product</span>
    									</div>
    								</div>
                                </a>
    							<div class="product_info">
    								<?php
    								$terms = get_the_terms( $post->ID, 'product_cat' );
    								if ( $terms && ! is_wp_error( $terms ) ) :
    								    $cat_links = array();
    								    foreach ( $terms as $term ) {
    								        $cat_links[] = $term->name;
    								    }
    								    $on_cat = join( ", ", $cat_links );
    								    ?>
    								    <p class="product_category uppercase"><?php echo $on_cat; ?></p>
    								<?php endif; ?>
    								<a href="<?php echo get_permalink();?>"><h3 class="product_title alegreya_regular"><?php the_title(); ?></h3></a>
    								<?php $product = wc_get_product( get_the_ID() );?>
    								<p class="product_price alegreya_bold"><?php echo $product->get_price_html(); ?></p>
    							</div>
    						</div>
    					</li>
                        <?php
                    endwhile;
                    else:
                        echo '<div class="empty-content"><p class="aligncenter">No products found.</p></div>';
                    endif; ?>
                </ul>
			</div>

		</main>

<?php get_footer(); ?>