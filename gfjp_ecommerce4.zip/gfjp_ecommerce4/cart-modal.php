<div class="modal_cart_container"> 
		<div class="modal_cart_filter" hidden="hidden"></div>
		<div class="modal_cart" hidden="hidden">
				<div class="modal_cart_header flex">
						<div class="modal_cart_close">
								<span class="iconify" data-icon="bx:bx-chevron-right" data-inline="false"></span>
						</div>
						<div class="modal_cart_title alegreya_bold">Cart</div>
				</div>
				<div class="modal_cart_body">
						<table class="modal_products_tbl">
								<tbody>
										<tr>
												<td class="modal_prod_img"><img src="<?php echo GFJP_IMG_URL?>/cart/img_cart_3piece_soap.jpg" alt=""></td>
												<td class="modal_prod_details"><span class="modal_prod_name alegreya_regular bright_red_txt">3-piece soap set</span><span class="modal_prod_total alegreya_bold">₱696.00</span></td>
												<td class="modal_prod_qty">
												<div class="quantity">
														<input type="number" min="1" max="100" step="1" value="1">
												</div>
												</td>
										</tr>
								</tbody>
						</table>
				</div>
				<div class="modal_cart_footer">
						<div class="modal_cart_subtotal">
								<p class="alegreya_regular">Subtotal</p>
								<p class="alegreya_bold">₱696.00</p>
						</div>
						<div class="modal_cart_btn">
								<a class="btn_default uppercase btn_border" href="#">View Cart</a>
						</div>
				</div>
		</div>
</div>