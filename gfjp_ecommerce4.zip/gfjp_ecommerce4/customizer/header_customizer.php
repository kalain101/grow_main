<?php

add_action( 'customize_register', 'gfjp_ec4_header' );
function gfjp_ec4_header( $wp_customize ){

    $wp_customize->add_section( 'gfjp_ec4_header_section', array(
        'title' => 'Header'
    ) );

    //  Header Logo
    $wp_customize->add_setting( 'gfjp_ec4_header_desktop_logo_setting', array(
        'default'     => GFJP_IMG_URL .'/logo.png'
    ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_header_desktop_logo_control', array(
        'label'       => 'Header Logo',
        'section'     => 'gfjp_ec4_header_section',
        'settings'    => 'gfjp_ec4_header_desktop_logo_setting',
        'flex_width'  => true,
        'flex_height' => true
    ) ) );

}