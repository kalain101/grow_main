<?php

add_action( 'customize_register', 'gfjp_ec4_footer' );
function gfjp_ec4_footer( $wp_customize ){

    // MAIN PANEL
    $wp_customize->add_panel( 'gfjp_ec4_footer_panel', array(
        'title'   => 'Footer',
    ) );
    

    /*  
        FOOTER INFO
    ---------------------*/
    $wp_customize->add_section( 'gfjp_ec4_footer_section', array(
        'title'    => 'Footer Info',
        'panel'    => 'gfjp_ec4_footer_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_footer_logo_setting', array(
        'default'     => GFJP_IMG_URL .'/logo.png'
    ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_footer_logo_control', array(
        'label'       => 'Footer Logo',
        'section'     => 'gfjp_ec4_footer_section',
        'settings'    => 'gfjp_ec4_footer_logo_setting',
        'flex_width'  => true,
        'flex_height' => true
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_footer_description_setting', array(
        'default'  => 'Pure and organic products made just for you.'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_footer_description_control', array(
        'label'    => 'Footer Description',
        'section'  => 'gfjp_ec4_footer_section',
        'settings' => 'gfjp_ec4_footer_description_setting',
        'type'     => 'textarea',
    ) ) );


    /*  
        FOOTER BOTTOM
    ---------------------*/
    $wp_customize->add_section( 'gfjp_ec4_footer_bottom_section', array(
        'title'    => 'Footer Bottom Bar',
        'panel'    => 'gfjp_ec4_footer_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_footer_copyright_setting', array(
        'default'  => '© 2020 Beautylab - Designed and Develop by <a href="#">Grow Itech</a>. All rights reserved.'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_footer_copyright_control', array(
        'label'    => 'Copyright Text',
        'section'  => 'gfjp_ec4_footer_bottom_section',
        'settings' => 'gfjp_ec4_footer_copyright_setting',
        'type'     => 'textarea',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_footer_telephone_setting', array(
        'default'  => '09123456789'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_footer_telephone_control', array(
        'label'    => 'Contact Number',
        'section'  => 'gfjp_ec4_footer_bottom_section',
        'settings' => 'gfjp_ec4_footer_telephone_setting',
        'type'     => 'text',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_footer_email_setting', array(
        'default'  => 'info@beautylab.com'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_footer_email_control', array(
        'label'    => 'Email',
        'section'  => 'gfjp_ec4_footer_bottom_section',
        'settings' => 'gfjp_ec4_footer_email_setting',
        'type'     => 'text',
    ) ) );

}