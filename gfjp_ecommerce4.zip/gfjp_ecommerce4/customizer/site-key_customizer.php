<?php

add_action( 'customize_register', 'gfjp_ec4_sitekey' );
function gfjp_ec4_sitekey( $wp_customize ){

    $wp_customize->add_section( 'gfjp_ec4_sitekey_section', array(
        'title'    => 'Site Key',
        'priority' => 200,
    ) );

    //  Main Title
    $wp_customize->add_setting( 'gfjp_ec4_recaptha_sitekey_setting', array( ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_recaptha_sitekey_control', array(
        'label'         => 'reCaptcha Site Key',
        'section'       => 'gfjp_ec4_sitekey_section',
        'settings'      => 'gfjp_ec4_recaptha_sitekey_setting',
        'description'   => 'You can setup you site key by visiting this page <a href="https://www.google.com/recaptcha/admin/" target="_blank">reCAPTCHA</a>',
        'type'          => 'text',
    ) ) );

}