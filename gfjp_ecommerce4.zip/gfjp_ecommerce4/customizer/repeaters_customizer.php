<?php
require_once( GFJP_CLASS_DIR.'/customizer-repeater-control.php' );

function customizer_repeater_sanitize($input){
    $input_decoded = json_decode($input,true);

    if(!empty($input_decoded)) {
        foreach ($input_decoded as $boxk => $box ){
            foreach ($box as $key => $value){
                $input_decoded[$boxk][$key] = wp_kses_post( force_balance_tags( $value ) );
            }
        }
        return json_encode($input_decoded);
    }
    return $input;
}