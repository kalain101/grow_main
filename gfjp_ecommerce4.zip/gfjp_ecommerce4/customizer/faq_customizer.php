<?php

add_action( 'customize_register', 'gfjp_ec4_faq' );
function gfjp_ec4_faq( $wp_customize ){

    $wp_customize->add_section( 'gfjp_ec4_faq_section', array(
        'title'    => 'FAQ',
    ) );

    //  Banner
    $wp_customize->add_setting( 'gfjp_ec4_faq_banner_background_setting', array( ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_faq_banner_background_control', array(
        'label'         => 'Banner Background Image',
        'section'       => 'gfjp_ec4_faq_section',
        'settings'      => 'gfjp_ec4_faq_banner_background_setting',
        'description'   => 'If you remove this image, the default image of General Banner Image settings will display on the page.',
        'flex_width'    => true,
        'flex_height'   => true,
        'height'        => 100, 
        'width'         => 1600
    ) ) );

    //  Main Title
    $wp_customize->add_setting( 'gfjp_ec4_faq_title_setting', array(
        'default'  => 'Common Queries'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_faq_title_control', array(
        'label'    => 'FAQ Title',
        'section'  => 'gfjp_ec4_faq_section',
        'settings' => 'gfjp_ec4_faq_title_setting',
        'type'     => 'text',
    ) ) );

    //  Layout Settings
    $wp_customize->add_setting( 'gfjp_ec4_faq_layout_setting', array(
        'default'  => 'standard-layout'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_faq_layout_control', array(
        'label'    => 'Select FAQ Layout',
        'section'  => 'gfjp_ec4_faq_section',
        'settings' => 'gfjp_ec4_faq_layout_setting',
        'type'     => 'radio',
        'choices'  => array( 
             'standard-layout'    => __('Standard Layout'),
             'dropdown-layout'    => __('Dropdown Layout'),
        )
    ) ) );

}