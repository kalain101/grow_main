<?php

add_action( 'customize_register', 'gfjp_ec4_homepage' );
function gfjp_ec4_homepage( $wp_customize ){

    // MAIN PANEL
    $wp_customize->add_panel( 'gfjp_ec4_homepage_panel', array(
        'title'         => 'Homepage',
    ) );
    
    /*  
        BANNER
    ---------------------*/
    $wp_customize->add_section( 'gfjp_ec4_homepage_section', array(
        'title'         => 'Banner Section',
        'panel'         => 'gfjp_ec4_homepage_panel'
    ) );

    //  Banner Background image
    $wp_customize->add_setting( 'gfjp_ec4_homepage_banner_background_setting', array(
        'default'       => GFJP_IMG_URL .'/bg_banner.jpg'
    ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_homepage_banner_background_control', array(
        'label'         => 'Banner Background Image',
        'section'       => 'gfjp_ec4_homepage_section',
        'settings'      => 'gfjp_ec4_homepage_banner_background_setting',
        'flex_width'    => true,
        'flex_height'   => true
    ) ) );

    //  Banner Title
    $wp_customize->add_setting( 'gfjp_ec4_home_banner_headline_setting', array(
        'default'  => 'Pure & Natural <br>Organic Beauty'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home_banner_headline_control', array(
        'label'    => 'Banner Title',
        'section'  => 'gfjp_ec4_homepage_section',
        'settings' => 'gfjp_ec4_home_banner_headline_setting',
        'type'     => 'text',
    ) ) );

    //  Banner Short Description
    $wp_customize->add_setting( 'gfjp_ec4_home_banner_description_setting', array(
        'default'  => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home_banner_description_control', array(
        'label'    => 'Banner Short Description',
        'section'  => 'gfjp_ec4_homepage_section',
        'settings' => 'gfjp_ec4_home_banner_description_setting',
        'type'     => 'textarea',
    ) ) );

    /*  
        HOMEPAGE LAYOUT
    ---------------------*/
    $wp_customize->add_section( 'gfjp_ec4_home_layout_section', array(
        'title'    => 'Homepage Layout',
        'panel'    => 'gfjp_ec4_homepage_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_home_layout_setting', array(
        'default'  => 'layout-1'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home_layout_control', array(
        'label'    => 'Select Homepage Layout',
        'section'  => 'gfjp_ec4_home_layout_section',
        'settings' => 'gfjp_ec4_home_layout_setting',
        'type'     => 'radio',
        'choices'  => array( 
             'layout-1'  => __( 'Homepage Layout 1' ),
             'layout-2'  => __( 'Homepage Layout 2' ),
        )
    ) ) );

    /*  
        LAST SECTION LAYOUT
    ---------------------------------*/
    $wp_customize->add_section( 'gfjp_ec4_home_last_layout_section', array(
        'title'    => 'Last Section Layout',
        'panel'    => 'gfjp_ec4_homepage_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_home_lastlayout_setting', array(
        'default'  => 'newsletter-layout'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home_lastlayout_control', array(
        'label'    => 'Select Homepage Layout',
        'section'  => 'gfjp_ec4_home_last_layout_section',
        'settings' => 'gfjp_ec4_home_lastlayout_setting',
        'type'     => 'radio',
        'choices'  => array( 
             'newsletter-layout'  => __('Newsletter Layout'),
             'carousel-layout'    => __('Carousel Slider Layout'),
        )
    ) ) );

    /* ---------------------------------------
        START HOMEPAGE LAYOUT 1
    ----------------------------------------*/

    // FEATURED PRODUCTS
    $wp_customize->add_section( 'gfjp_ec4_home_featuredProduct_section', array(
        'title'         => 'Featured Products Section',
        'panel'         => 'gfjp_ec4_homepage_panel'
    ) );

    // PRODUCT 1
    $wp_customize->add_setting( 'gfjp_ec4_home_featuredProduct1_img_setting', array(
        'default'       => GFJP_IMG_URL .'/product_home_1.png'
    ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_home_featuredProduct1_img_control', array(
        'label'         => 'Product 1 Image',
        'section'       => 'gfjp_ec4_home_featuredProduct_section',
        'settings'      => 'gfjp_ec4_home_featuredProduct1_img_setting',
        'flex_width'    => true,
        'flex_height'   => true
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_home_featuredProduct1_title_setting', array(
        'default'       => 'Radiant Glow <br>Day Cream'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home_featuredProduct1_title_control', array(
        'label'         => 'Product 1 Title',
        'section'       => 'gfjp_ec4_home_featuredProduct_section',
        'settings'      => 'gfjp_ec4_home_featuredProduct1_title_setting',
        'type'          => 'text',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_home_featuredProduct1_subtitle_setting', array(
        'default'       => 'Radiant Glow Series'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home_featuredProduct1_subtitle_control', array(
        'label'         => 'Product 1 Top Subtitle',
        'section'       => 'gfjp_ec4_home_featuredProduct_section',
        'settings'      => 'gfjp_ec4_home_featuredProduct1_subtitle_setting',
        'type'          => 'text',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_home_featuredProduct1_desc_setting', array(
        'default'       => '<li>SPF 50</li>
<li>Natural Ingredients</li>
<li>Perfect for dull, dry, and sensitive skin</li>
<li>Feel fresh all day</li>
<li>Achieve that natural glow</li>'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home_featuredProduct1_desc_control', array(
        'label'         => 'Product 1 List Description',
        'description'   => 'Please wrap each list on &lt;li&gt; and &lt;&sol;li&gt;',
        'section'       => 'gfjp_ec4_home_featuredProduct_section',
        'settings'      => 'gfjp_ec4_home_featuredProduct1_desc_setting',
        'type'          => 'textarea',
    ) ) );

    // PRODUCT 2
    $wp_customize->add_setting( 'gfjp_ec4_home_featuredProduct2_img_setting', array(
        'default'       => GFJP_IMG_URL .'/product_home_2.png'
    ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_home_featuredProduct2_img_control', array(
        'label'         => 'Product 2 Image',
        'section'       => 'gfjp_ec4_home_featuredProduct_section',
        'settings'      => 'gfjp_ec4_home_featuredProduct2_img_setting',
        'flex_width'    => true,
        'flex_height'   => true
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_home_featuredProduct2_title_setting', array(
        'default'       => 'All Natural <br>Moisturizing Boost'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home_featuredProduct2_title_control', array(
        'label'         => 'Product 2 Title',
        'section'       => 'gfjp_ec4_home_featuredProduct_section',
        'settings'      => 'gfjp_ec4_home_featuredProduct2_title_setting',
        'type'          => 'text',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_home_featuredProduct2_subtitle_setting', array(
        'default'       => 'Hydrating Boost Series'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home_featuredProduct2_subtitle_control', array(
        'label'         => 'Product 2 Top Subtitle',
        'section'       => 'gfjp_ec4_home_featuredProduct_section',
        'settings'      => 'gfjp_ec4_home_featuredProduct2_subtitle_setting',
        'type'          => 'text',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_home_featuredProduct2_desc_setting', array(
        'default'       => '<li>Hypoallergenic</li>
<li>Natural Ingredients</li>
<li>Perfect for dull, dry, and sensitive skin</li>
<li>Has brigthening effect</li>
<li>24-hour moisturizing effect</li>'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home_featuredProduct2_desc_control', array(
        'label'         => 'Product 2 List Description',
        'description'   => 'Please wrap each list on &lt;li&gt; and &lt;&sol;li&gt;',
        'section'       => 'gfjp_ec4_home_featuredProduct_section',
        'settings'      => 'gfjp_ec4_home_featuredProduct2_desc_setting',
        'type'          => 'textarea',
    ) ) );

    /*  
        FAV PRODUCTS
    ---------------------*/
    $wp_customize->add_section( 'gfjp_ec4_home_favProduct_section', array(
        'title'         => 'Favorite Products Section',
        'panel'         => 'gfjp_ec4_homepage_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_home_favProd_title_setting', array(
        'default'       => 'Our Customers’ Favorites'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home_favProd_title_control', array(
        'label'         => 'Favorite Products Title',
        'section'       => 'gfjp_ec4_home_favProduct_section',
        'settings'      => 'gfjp_ec4_home_favProd_title_setting',
        'type'          => 'text',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_home_favProd_img_setting', array(
        'default'       => GFJP_IMG_URL .'/home/ico_cake.png'
    ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_home_favProd_img_control', array(
        'label'         => 'Favorite Products Icon Image',
        'section'       => 'gfjp_ec4_home_favProduct_section',
        'settings'      => 'gfjp_ec4_home_favProd_img_setting',
        'flex_width'    => true,
        'flex_height'   => true
    ) ) );

    /*  
        SHOP SECTION
    ---------------------*/
    $wp_customize->add_section( 'gfjp_ec4_home_shopProduct_section', array(
        'title'         => 'Shop Products Section',
        'panel'         => 'gfjp_ec4_homepage_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_home_shopProd_title_setting', array(
        'default'       => 'Products made <br>just for you'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home_shopProd_title_control', array(
        'label'         => 'Shop Title',
        'section'       => 'gfjp_ec4_home_shopProduct_section',
        'settings'      => 'gfjp_ec4_home_shopProd_title_setting',
        'type'          => 'text',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_home_shopProd_desc_setting', array(
        'default'       => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ultricies amet pellentesque vulputate sed id.'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home_shopProd_desc_control', array(
        'label'         => 'Shop Description',
        'section'       => 'gfjp_ec4_home_shopProduct_section',
        'settings'      => 'gfjp_ec4_home_shopProd_desc_setting',
        'type'          => 'textarea',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_home_shopProd_img_setting', array(
        'default'       => GFJP_IMG_URL .'/home/bg_shop_now.jpg'
    ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_home_shopProd_img_control', array(
        'label'         => 'Shop Left Image',
        'section'       => 'gfjp_ec4_home_shopProduct_section',
        'settings'      => 'gfjp_ec4_home_shopProd_img_setting',
        'flex_width'    => true,
        'flex_height'   => true
    ) ) );

    /*  
        NEWSLETTER
    ---------------------*/
    $wp_customize->add_section( 'gfjp_ec4_home_newsletter_section', array(
        'title'         => 'Newsletter Section',
        'panel'         => 'gfjp_ec4_homepage_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_home_newsletter_title_setting', array(
        'default'       => 'Join our newsletter'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home_newsletter_title_control', array(
        'label'         => 'Newsletter Title',
        'section'       => 'gfjp_ec4_home_newsletter_section',
        'settings'      => 'gfjp_ec4_home_newsletter_title_setting',
        'type'          => 'text',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_home_newsletter_desc_setting', array(
        'default'       => 'Subscribe to get special offers, and exclusive deals.'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home_newsletter_desc_control', array(
        'label'         => 'Newsletter Description',
        'section'       => 'gfjp_ec4_home_newsletter_section',
        'settings'      => 'gfjp_ec4_home_newsletter_desc_setting',
        'type'          => 'textarea',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_home_newsletter_img_setting', array(
        'default'       => GFJP_IMG_URL .'/home/bg_newsletter.png'
    ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_home_newsletter_img_control', array(
        'label'         => 'Newsletter Background Image',
        'section'       => 'gfjp_ec4_home_newsletter_section',
        'settings'      => 'gfjp_ec4_home_newsletter_img_setting',
        'flex_width'    => true,
        'flex_height'   => true
    ) ) );

    /*  
        CAROUSEL
    ---------------------*/
    $wp_customize->add_section( 'gfjp_ec4_home_carousel_section', array(
        'title'         => 'Carousel Section',
        'panel'         => 'gfjp_ec4_homepage_panel'
    ) );

    $wp_customize->add_setting( 'customizer_repeater_slider', array(
        'sanitize_callback' => 'customizer_repeater_sanitize',
        'default' => json_encode( array(
            array("image_url" => GFJP_IMG_URL.'/home/bg_slide1.jpg' ,"link" => "#", "id" => "customizer_repeater_56d7ea7f40f56" ), 
            array("image_url" => GFJP_IMG_URL.'/home/bg_slide2.jpg' ,"link" => "#", "id" => "customizer_repeater_56d7ea7f40f57" ),
            array("image_url" => GFJP_IMG_URL.'/home/bg_slide3.jpg' ,"link" => "#", "id" => "customizer_repeater_56d7ea7f40f58" ),
        ) )
    ));

    $wp_customize->add_control( new Customizer_Repeater( $wp_customize, 'customizer_repeater_slider', array(
        'label'     => 'Banner Images',
        'section'   => 'gfjp_ec4_home_carousel_section',
        'priority'  => 1,
        'customizer_repeater_image_control'     => true,
        'customizer_repeater_icon_control'      => true,
        'customizer_repeater_repeater_control'  => true
    ) ) );

    //--------------------------------------------------------------

    /* -----------------------------------------------
        START HOMEPAGE LAYOUT 2
    -------------------------------------------------*/

    $wp_customize->add_section( 'gfjp_ec4_home2_category_section', array(
        'title'         => 'Featured Categories Section',
        'panel'         => 'gfjp_ec4_homepage_panel'
    ) );

    //------------------------ CAT 1 --------------------------------

    $wp_customize->add_setting( 'gfjp_ec4_home2_category1_img_setting', array(
        'default'       => GFJP_IMG_URL .'/home/bg_bath.jpg'
    ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_home2_category1_img_control', array(
        'label'         => 'Category 1 Image',
        'description'   => 'Suggested image dimensions: 540 by 350 pixels',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category1_img_setting',
        'flex_width'    => false,
        'flex_height'   => false,
        'height'        => 350,
        'width'         => 540,
    ) ) );


    $wp_customize->add_setting( 'gfjp_ec4_home2_category1_cat_setting', array(
        'default'       => 'Bath & Body'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home2_category1_cat_control', array(
        'label'         => 'Category Name',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category1_cat_setting',
        'type'          => 'text',
    ) ) );


    $wp_customize->add_setting( 'gfjp_ec4_home2_category1_tl_setting', array(
        'default'       => 'Always stay fresh'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home2_category1_tl_control', array(
        'label'         => 'Category 1 Title',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category1_tl_setting',
        'type'          => 'text',
    ) ) );


    $wp_customize->add_setting( 'gfjp_ec4_home2_category1_desc_setting', array(
        'default'       => 'Aliquam purus habitasse consequat felis sociis lobortis ullamcorper eget. Pretium turpis felis ut morbi congue amet. Vulputate aliquet ullamcorper hac eu proin lorem mi.'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home2_category1_desc_control', array(
        'label'         => 'Category 1 Description',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category1_desc_setting',
        'type'          => 'textarea',
    ) ) );


    $wp_customize->add_setting( 'gfjp_ec4_home2_category1_btntxt_setting', array(
        'default'       => 'Shop Now'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home2_category1_btntxt_control', array(
        'label'         => 'Category 1 Button Text',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category1_btntxt_setting',
        'type'          => 'text',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_home2_category1_btnlnk_setting', array(
        'default'       => '/shop'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home2_category1_btnlnk_control', array(
        'label'         => 'Category 1 Button Link',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category1_btnlnk_setting',
        'type'          => 'text',
    ) ) );

    //--------------------------------------------------------------

    //------------------------ CAT 2 -------------------------------

    $wp_customize->add_setting( 'gfjp_ec4_home2_category2_img_setting', array(
        'default'       => GFJP_IMG_URL .'/home/bg_skin.jpg'
    ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_home2_category2_img_control', array(
        'label'         => 'Category 2 Image',
        'description'   => 'Suggested image dimensions: 540 by 350 pixels',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category2_img_setting',
        'flex_width'    => false,
        'flex_height'   => false,
        'height'        => 350,
        'width'         => 540,
    ) ) );


    $wp_customize->add_setting( 'gfjp_ec4_home2_category2_cat_setting', array(
        'default'       => 'Skin Care'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home2_category2_cat_control', array(
        'label'         => 'Category Name',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category2_cat_setting',
        'type'          => 'text',
    ) ) );


    $wp_customize->add_setting( 'gfjp_ec4_home2_category2_tl_setting', array(
        'default'       => 'Glow naturally'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home2_category2_tl_control', array(
        'label'         => 'Category 2 Title',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category2_tl_setting',
        'type'          => 'text',
    ) ) );


    $wp_customize->add_setting( 'gfjp_ec4_home2_category2_desc_setting', array(
        'default'       => 'Aliquam purus habitasse consequat felis sociis lobortis ullamcorper eget. Pretium turpis felis ut morbi congue amet. Vulputate aliquet ullamcorper hac eu proin lorem mi.'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home2_category2_desc_control', array(
        'label'         => 'Category 1 Description',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category2_desc_setting',
        'type'          => 'textarea',
    ) ) );


    $wp_customize->add_setting( 'gfjp_ec4_home2_category2_btntxt_setting', array(
        'default'       => 'Shop Now'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home2_category2_btntxt_control', array(
        'label'         => 'Category 2 Button Text',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category2_btntxt_setting',
        'type'          => 'text',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_home2_category2_btnlnk_setting', array(
        'default'       => '/shop'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home2_category2_btnlnk_control', array(
        'label'         => 'Category 2 Button Link',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category2_btnlnk_setting',
        'type'          => 'text',
    ) ) );


    //--------------------------------------------------------------

    //------------------------ CAT 3 -------------------------------


    $wp_customize->add_setting( 'gfjp_ec4_home2_category3_img_setting', array(
        'default'       => GFJP_IMG_URL .'/home/bg_makeup.jpg'
    ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_home2_category3_img_control', array(
        'label'         => 'Category 3 Image',
        'description'   => 'Suggested image dimensions: 540 by 350 pixels',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category3_img_setting',
        'flex_width'    => false,
        'flex_height'   => false,
        'height'        => 350,
        'width'         => 540,
    ) ) );


    $wp_customize->add_setting( 'gfjp_ec4_home2_category3_cat_setting', array(
        'default'       => 'Make Up'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home2_category3_cat_control', array(
        'label'         => 'Category Name',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category3_cat_setting',
        'type'          => 'text',
    ) ) );


    $wp_customize->add_setting( 'gfjp_ec4_home2_category3_tl_setting', array(
        'default'       => 'Pure Beauty'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home2_category3_tl_control', array(
        'label'         => 'Category 3 Title',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category3_tl_setting',
        'type'          => 'text',
    ) ) );


    $wp_customize->add_setting( 'gfjp_ec4_home2_category3_desc_setting', array(
        'default'       => 'Aliquam purus habitasse consequat felis sociis lobortis ullamcorper eget. Pretium turpis felis ut morbi congue amet. Vulputate aliquet ullamcorper hac eu proin lorem mi.'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home2_category3_desc_control', array(
        'label'         => 'Category 3 Description',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category3_desc_setting',
        'type'          => 'textarea',
    ) ) );


    $wp_customize->add_setting( 'gfjp_ec4_home2_category3_btntxt_setting', array(
        'default'       => 'Shop Now'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home2_category3_btntxt_control', array(
        'label'         => 'Category 3 Button Text',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category3_btntxt_setting',
        'type'          => 'text',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_home2_category3_btnlnk_setting', array(
        'default'       => '/shop'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_home2_category3_btnlnk_control', array(
        'label'         => 'Category 3 Button Link',
        'section'       => 'gfjp_ec4_home2_category_section',
        'settings'      => 'gfjp_ec4_home2_category3_btnlnk_setting',
        'type'          => 'text',
    ) ) );

}