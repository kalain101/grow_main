<?php

//include_once 'repeater_customizer.php';
include_once 'repeaters_customizer.php';
include_once 'site-key_customizer.php';

include_once 'header_customizer.php';
include_once 'footer_customizer.php';

include_once 'social_media_customizer.php';
include_once 'homepage_customizer.php';
include_once 'faq_customizer.php';

include_once 'banner-title_customizer.php';
