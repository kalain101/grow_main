<?php

add_action( 'customize_register', 'gfjp_ec4_socials' );
function gfjp_ec4_socials( $wp_customize ){

    $wp_customize->add_section( 'gfjp_ec4_socials_section', array(
        'title' => 'Social Media'
    ) );

    // SOCIAL NETWORKS
    $wp_customize->add_setting( 'gfjp_ec4_link_facebook_setting', array (
        'default'     => 'https://www.facebook.com/',
    ));
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_link_facebook_control', array(
        'label'       => 'Facebook',
        'section'     => 'gfjp_ec4_socials_section',
        'settings'    => 'gfjp_ec4_link_facebook_setting',
        'type'        => 'url',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_link_instagram_setting', array(
        'default'     => 'https://www.instagram.com/',
    ));
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_link_instagram_control', array(
        'label'       => 'Instagram',
        'section'     => 'gfjp_ec4_socials_section',
        'settings'    => 'gfjp_ec4_link_instagram_setting',
        'type'        => 'url',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_link_linkedin_setting');
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_link_linkedin_control', array(
        'label'       => 'Linkedin',
        'section'     => 'gfjp_ec4_socials_section',
        'settings'    => 'gfjp_ec4_link_linkedin_setting',
        'type'        => 'url',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_link_twitter_setting', array (
        'default'     => 'https://www.twitter.com/',
    ));
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_link_twitter_control', array(
        'label'       => 'Twitter',
        'section'     => 'gfjp_ec4_socials_section',
        'settings'    => 'gfjp_ec4_link_twitter_setting',
        'type'        => 'url',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_link_googlep_setting');
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_link_googlep_control', array(
        'label'       => 'Google +',
        'section'     => 'gfjp_ec4_socials_section',
        'settings'    => 'gfjp_ec4_link_googlep_setting',
        'type'        => 'url',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_link_youtube_setting');
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_link_youtube_control', array(
        'label'       => 'Youtube',
        'section'     => 'gfjp_ec4_socials_section',
        'settings'    => 'gfjp_ec4_link_youtube_setting',
        'type'        => 'url',
    ) ) );

}