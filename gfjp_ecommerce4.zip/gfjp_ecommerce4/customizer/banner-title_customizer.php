<?php

add_action( 'customize_register', 'gfjp_ec4_banner_title' );
function gfjp_ec4_banner_title( $wp_customize ){

    $wp_customize->add_panel( 'gfjp_ec4_banner_title_panel', array(
        'title'    => 'Inner Pages Banner and Title',
        'priority' => 35,
    ) );

    /*
        GENERAL BANNER AND TITLE
    --------------------------- */
    $wp_customize->add_section( 'gfjp_ec4_gen_banner_section', array(
        'title'         => 'General Banner Image',
        'panel'         => 'gfjp_ec4_banner_title_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_gen_banner_background_setting', array(
        'default'       => GFJP_IMG_URL .'/bg_banner.jpg'
    ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_gen_banner_background_control', array(
        'label'         => 'Banner Background Image',
        'section'       => 'gfjp_ec4_gen_banner_section',
        'settings'      => 'gfjp_ec4_gen_banner_background_setting',
        'description'   => 'This banner image will take effect on all inner pages of the site except homepage. If you remove this image, the default image of each inner pages banner settings will display on the site.',
        'flex_width'    => true,
        'flex_height'   => true,
        'height'        => 100, 
        'width'         => 1600
    ) ) );


    /*
        CONTACT PAGE
    --------------------------- */
    $wp_customize->add_section( 'gfjp_ec4_contact_section', array(
        'title'    => 'Contact Page',
        'panel'    => 'gfjp_ec4_banner_title_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_contact_banner_background_setting', array( ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_contact_banner_background_control', array(
        'label'         => 'Banner Background Image',
        'section'       => 'gfjp_ec4_contact_section',
        'settings'      => 'gfjp_ec4_contact_banner_background_setting',
        'description'   => 'This banner image will take effect on all inner pages of the site except homepage. If you remove this image, the default image of each inner pages banner settings will display on the site.',
        'flex_width'    => true,
        'flex_height'   => true,
        'height'        => 100, 
        'width'         => 1600
    ) ) );
    $wp_customize->add_setting( 'gfjp_ec4_contact_title_setting', array(
        'default'  => 'Contact us and say hello.'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_contact_title_control', array(
        'label'    => 'Contact Title',
        'section'  => 'gfjp_ec4_contact_section',
        'settings' => 'gfjp_ec4_contact_title_setting',
        'type'     => 'text',
    ) ) );


    /*
        PRIVACY POLICY PAGE
    --------------------------- */
    $wp_customize->add_section( 'gfjp_ec4_privacy_section', array(
        'title'    => 'Privacy Policy Page',
        'panel'    => 'gfjp_ec4_banner_title_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_privacy_banner_background_setting', array( ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_privacy_banner_background_control', array(
        'label'         => 'Banner Background Image',
        'section'       => 'gfjp_ec4_privacy_section',
        'settings'      => 'gfjp_ec4_privacy_banner_background_setting',
        'description'   => 'This banner image will take effect on all inner pages of the site except homepage. If you remove this image, the default image of each inner pages banner settings will display on the site.',
        'flex_width'    => true,
        'flex_height'   => true,
        'height'        => 100, 
        'width'         => 1600
    ) ) );
    $wp_customize->add_setting( 'gfjp_ec4_privacy_title_setting', array(
        'default'  => 'Privacy Policy'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_privacy_title_control', array(
        'label'    => 'Privacy Policy Title',
        'section'  => 'gfjp_ec4_privacy_section',
        'settings' => 'gfjp_ec4_privacy_title_setting',
        'type'     => 'text',
    ) ) );


    /*
        LOGIN PAGE
    --------------------------- */
    $wp_customize->add_section( 'gfjp_ec4_signin_section', array(
        'title'    => 'Login Page',
        'panel'    => 'gfjp_ec4_banner_title_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_signin_banner_background_setting', array( ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_signin_banner_background_control', array(
        'label'         => 'Banner Background Image',
        'section'       => 'gfjp_ec4_signin_section',
        'settings'      => 'gfjp_ec4_signin_banner_background_setting',
        'description'   => 'This banner image will take effect on all inner pages of the site except homepage. If you remove this image, the default image of each inner pages banner settings will display on the site.',
        'flex_width'    => true,
        'flex_height'   => true,
        'height'        => 100, 
        'width'         => 1600
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_signin_title_setting', array(
        'default'  => 'Login'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_signin_title_control', array(
        'label'    => 'Login Title',
        'section'  => 'gfjp_ec4_signin_section',
        'settings' => 'gfjp_ec4_signin_title_setting',
        'type'     => 'text',
    ) ) );


    /*
        SIGNUP PAGE
    --------------------------- */
    $wp_customize->add_section( 'gfjp_ec4_signup_section', array(
        'title'    => 'Signup Page',
        'panel'    => 'gfjp_ec4_banner_title_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_signup_banner_background_setting', array( ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_signup_banner_background_control', array(
        'label'         => 'Banner Background Image',
        'section'       => 'gfjp_ec4_signup_section',
        'settings'      => 'gfjp_ec4_signup_banner_background_setting',
        'description'   => 'This banner image will take effect on all inner pages of the site except homepage. If you remove this image, the default image of each inner pages banner settings will display on the site.',
        'flex_width'    => true,
        'flex_height'   => true,
        'height'        => 100, 
        'width'         => 1600
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_signup_title_setting', array(
        'default'  => 'Sign Up'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_signup_title_control', array(
        'label'    => 'Sign Up Title',
        'section'  => 'gfjp_ec4_signup_section',
        'settings' => 'gfjp_ec4_signup_title_setting',
        'type'     => 'text',
    ) ) );


    /*
        SHOP PAGE
    --------------------------- */
    $wp_customize->add_section( 'gfjp_ec4_shop_banner_section', array(
        'title'         => 'Shop Page',
        'panel'         => 'gfjp_ec4_banner_title_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_shop_banner_background_setting', array( ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_shop_banner_background_control', array(
        'label'         => 'Banner Background Image',
        'section'       => 'gfjp_ec4_shop_banner_section',
        'settings'      => 'gfjp_ec4_shop_banner_background_setting',
        'description'   => 'If you remove this image, the default image of General Banner Image settings will display on the page.',
        'flex_width'    => true,
        'flex_height'   => true,
        'height'        => 100, 
        'width'         => 1600
    ) ) );


    /*
        SINGLE PRODUCT PAGE
    --------------------------- */
    $wp_customize->add_section( 'gfjp_ec4_product_banner_section', array(
        'title'         => 'Single Product Pages',
        'panel'         => 'gfjp_ec4_banner_title_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_product_banner_background_setting', array( ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_product_banner_background_control', array(
        'label'         => 'Banner Background Image',
        'section'       => 'gfjp_ec4_product_banner_section',
        'settings'      => 'gfjp_ec4_product_banner_background_setting',
        'description'   => 'If you remove this image, the default image of General Banner Image settings will display on the page.',
        'flex_width'    => true,
        'flex_height'   => true,
        'height'        => 100, 
        'width'         => 1600
    ) ) );


    /*
        MY ACCOUNT PAGE
    --------------------------- */
    $wp_customize->add_section( 'gfjp_ec4_account_banner_section', array(
        'title'         => 'My Account Page',
        'panel'         => 'gfjp_ec4_banner_title_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_myaccount_banner_background_setting', array( ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_myaccount_banner_background_control', array(
        'label'         => 'Banner Background Image',
        'section'       => 'gfjp_ec4_account_banner_section',
        'settings'      => 'gfjp_ec4_myaccount_banner_background_setting',
        'description'   => 'This will take effect on both <strong>Order History</strong>, <strong>My Address</strong>, and <strong>Account Details</strong> Page. <br>If you remove this image, the default image of General Banner Image settings will display on the page.',
        'flex_width'    => true,
        'flex_height'   => true,
        'height'        => 100, 
        'width'         => 1600
    ) ) );


    /*
        CART PAGE
    --------------------------- */
    $wp_customize->add_section( 'gfjp_ec4_cart_banner_section', array(
        'title'         => 'Cart Page',
        'panel'         => 'gfjp_ec4_banner_title_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_cart_banner_background_setting', array( ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_cart_banner_background_control', array(
        'label'         => 'Banner Background Image',
        'section'       => 'gfjp_ec4_cart_banner_section',
        'settings'      => 'gfjp_ec4_cart_banner_background_setting',
        'description'   => 'If you remove this image, the default image of General Banner Image settings will display on the page.',
        'flex_width'    => true,
        'flex_height'   => true,
        'height'        => 100, 
        'width'         => 1600
    ) ) );


    /*
        CHECKOUT PAGE
    --------------------------- */
    $wp_customize->add_section( 'gfjp_ec4_checkout_banner_section', array(
        'title'         => 'Checkout Page',
        'panel'         => 'gfjp_ec4_banner_title_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_checkout_banner_background_setting', array( ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_checkout_banner_background_control', array(
        'label'         => 'Banner Background Image',
        'section'       => 'gfjp_ec4_checkout_banner_section',
        'settings'      => 'gfjp_ec4_checkout_banner_background_setting',
        'description'   => 'If you remove this image, the default image of General Banner Image settings will display on the page.',
        'flex_width'    => true,
        'flex_height'   => true,
        'height'        => 100, 
        'width'         => 1600
    ) ) );


    /*
        FORGOT PWORD
    --------------------------- */
    $wp_customize->add_section( 'gfjp_ec4_forgot_banner_section', array(
        'title'         => 'Forgot Password Page',
        'panel'         => 'gfjp_ec4_banner_title_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_forgot_banner_background_setting', array( ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_forgot_banner_background_control', array(
        'label'         => 'Banner Background Image',
        'section'       => 'gfjp_ec4_forgot_banner_section',
        'settings'      => 'gfjp_ec4_forgot_banner_background_setting',
        'description'   => 'If you remove this image, the default image of General Banner Image settings will display on the page.',
        'flex_width'    => true,
        'flex_height'   => true,
        'height'        => 100, 
        'width'         => 1600
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_forgot_title_setting', array(
        'default'  => 'Reset your password'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_forgot_title_control', array(
        'label'    => 'Banner Title',
        'section'  => 'gfjp_ec4_forgot_banner_section',
        'settings' => 'gfjp_ec4_forgot_title_setting',
        'type'     => 'text',
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_forgot_subtitle_setting', array(
        'default'  => 'We will send you an email to reset your password.'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_forgot_subtitle_control', array(
        'label'    => 'Page Subtitle',
        'section'  => 'gfjp_ec4_forgot_banner_section',
        'settings' => 'gfjp_ec4_forgot_subtitle_setting',
        'type'     => 'textarea',
    ) ) );


    /*
        RESET ACCOUNT PWORD
    --------------------------- */
    $wp_customize->add_section( 'gfjp_ec4_reset_banner_section', array(
        'title'         => 'Reset Account Password Page',
        'panel'         => 'gfjp_ec4_banner_title_panel'
    ) );

    $wp_customize->add_setting( 'gfjp_ec4_reset_banner_background_setting', array( ) );
    $wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'gfjp_ec4_reset_banner_background_control', array(
        'label'         => 'Banner Background Image',
        'section'       => 'gfjp_ec4_reset_banner_section',
        'settings'      => 'gfjp_ec4_reset_banner_background_setting',
        'description'   => 'If you remove this image, the default image of General Banner Image settings will display on the page.',
        'flex_width'    => true,
        'flex_height'   => true,
        'height'        => 100, 
        'width'         => 1600
    ) ) );

    $wp_customize->add_setting( 'gfjp_ec4_reset_title_setting', array(
        'default'  => 'Reset account password'
    ) );
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gfjp_ec4_reset_title_control', array(
        'label'    => 'Banner Title',
        'section'  => 'gfjp_ec4_reset_banner_section',
        'settings' => 'gfjp_ec4_reset_title_setting',
        'type'     => 'text',
    ) ) );


}