<?php
if (!class_exists('WP_Customize_Image_Control')) {
    return null;
}

class Multi_Image_Custom_Control extends WP_Customize_Control {
    public function enqueue() {
      wp_enqueue_style('multi-image-style', GFJP_CSS_URL.'/multi-image.css');
      wp_enqueue_script('multi-image-script', GFJP_JS_URL.'/multi-image.js', array( 'jquery' ), rand(), true);
    }

    public function render_content() { ?>
          <label>
            <span class='customize-control-title'>Carousel Images</span>
            <span class="description customize-control-description">Please upload 1440px X 500px image size for best resolution.</span>
          </label>
          <div>
            <ul class='images'></ul>
          </div>
          <div class='actions'>
            <a class="button-secondary upload">Add Images</a>
          </div>

          <input class="wp-editor-area" id="images-input" type="hidden" <?php $this->link(); ?>>
      <?php
    }
}

class Separator_Custom_control extends WP_Customize_Control {
    public $type = 'separator';
    public function render_content(){
        ?>
        <p><hr></p>
        <?php
    }
}
?>