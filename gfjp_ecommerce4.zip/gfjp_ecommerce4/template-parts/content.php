	<?
	global $shop_content;
	?>

	<div class="entry-content <?php echo $shop_content;?>">
		<?php
			the_content( );
		?>
	</div>
