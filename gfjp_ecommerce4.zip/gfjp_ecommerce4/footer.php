        <?php 
            $facebookLink   = get_theme_mod('gfjp_ec4_link_facebook_setting', 'https://www.facebook.com/'); 
            $twitterLink    = get_theme_mod('gfjp_ec4_link_twitter_setting', 'https://www.twitter.com/'); 
            $instagramLink  = get_theme_mod('gfjp_ec4_link_instagram_setting', 'https://www.instagram.com/'); 
            $linkedinLink   = get_theme_mod('gfjp_ec4_link_linkedin_setting'); 
            $googleLink     = get_theme_mod('gfjp_ec4_link_googlep_setting'); 
            $youtubeLink    = get_theme_mod('gfjp_ec4_link_youtube_setting');
        ?>
        <footer class="footer_main">
            <div class="footer_widgets aligncenter maxwidth">
                <div class="footer_logo">
                    <?php $footer_desktop_logo_url = get_theme_mod( 'gfjp_ec4_footer_logo_setting', GFJP_IMG_URL. '/logo.png' ); ?>
                    <a href="<?php echo home_url();?>" class="logo"><img class="logo-pc" src="<?php echo ( is_int( $footer_desktop_logo_url ) )? wp_get_attachment_url( $footer_desktop_logo_url ) : $footer_desktop_logo_url ?>" alt="<?php echo get_bloginfo( 'name' );?>"></a>
                </div>
                <p class="small_description"><?php echo get_theme_mod('gfjp_ec4_footer_description_setting','Pure and organic products made just for you.');?></p>
                <ul class="social_icons">
                    <?php if (!empty($instagramLink)) { ?>
                        <li><a href="<?php echo $instagramLink ?>"><span class="iconify" data-icon="bx:bxl-instagram" data-inline="false"></span></a></li>
                    <?php } ?>
                    <?php if (!empty($facebookLink)) { ?>
                        <li><a href="<?php echo $facebookLink ?>"><span class="iconify" data-icon="dashicons:facebook" data-inline="false"></span></a></li>
                    <?php } ?>
                    <?php if (!empty($twitterLink)) { ?>
                        <li><a href="<?php echo $twitterLink ?>"><span class="iconify" data-icon="bx:bxl-twitter" data-inline="false"></span></a></li>
                    <?php } ?>
                    <?php if (!empty($linkedinLink)) { ?>
                        <li><a href="<?php echo $linkedinLink ?>"><span class="iconify" data-icon="bx:bxl-linkedin-square" data-inline="false"></span></a></li>
                    <?php } ?>
                    <?php if (!empty($googleLink)) { ?>
                        <li><a href="<?php echo $googleLink ?>"><span class="iconify" data-icon="bx:bxl-google-plus" data-inline="false"></span></a></li>
                    <?php } ?>
                    <?php if (!empty($youtubeLink)) { ?>
                        <li><a href="<?php echo $youtubeLink ?>"><span class="iconify" data-icon="bx:bxl-youtube" data-inline="false"></span></a></li>
                    <?php } ?>
                </ul>
            </div>
            <div class="footer_bootom_bar">
                <div class="maxwidth flex">
                    <p class="footer_copyright"><?php echo get_theme_mod('gfjp_ec4_footer_copyright_setting','© 2020 Beautylab - Designed and Develop by <a href="#">Grow Itech</a>. All rights reserved.');?></p>
                    <ul class="footer_info">
                        <li>
                            <a href="tel:<?php echo get_theme_mod('gfjp_ec4_footer_telephone_setting','09123456789');?>"><span class="iconify" data-icon="clarity:phone-handset-solid" data-inline="false"></span><span class="footer_lbl"><?php echo get_theme_mod('gfjp_ec4_footer_telephone_setting','09123456789');?></span></a>
                        </li>
                        <li>
                            <a href="mailto:<?php echo get_theme_mod('gfjp_ec4_footer_email_setting','info@beautylab.com')?>"><span class="iconify" data-icon="whh:emailalt" data-inline="false"></span><span class="footer_lbl"><?php echo get_theme_mod('gfjp_ec4_footer_email_setting','info@beautylab.com')?></span></a>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="back-to-top-con">
                <a href="#" class="back-to-top clearfix"><span class="iconify" data-icon="bx:bx-chevron-up" data-inline="false"></span></a>
            </div>
        </footer>

        <?php wp_footer(); ?>

    </body>
</html>