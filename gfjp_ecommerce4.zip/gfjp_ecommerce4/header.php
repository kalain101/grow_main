<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="format-detection" content="telephone=no">

        <title><?php echo get_bloginfo( 'name' ); ?></title>
        <link rel="profile" href="http://gmpg.org/xfn/11">

        <!-- CSS -->
        <?php wp_head(); ?>
    </head>
    <body <?php body_class(); ?>>
        <div class="top_search_header clearfix">
            <form role="search" method="get" id="search_form" action="<?php echo home_url();?>" >
                <input type="text" value="" name="s" id="search_field" placeholder="SEARCH" />
                <input type="submit" id="search_submit" value="Search" />
            </form>
            <span class="iconify close_form" data-icon="carbon:close" data-inline="false"></span>
        </div>
        
        <header class="wrap_space">
            <?php 
                $facebookLink   = get_theme_mod('gfjp_ec4_link_facebook_setting', 'https://www.facebook.com/'); 
                $twitterLink    = get_theme_mod('gfjp_ec4_link_twitter_setting', 'https://www.twitter.com/'); 
                $instagramLink  = get_theme_mod('gfjp_ec4_link_instagram_setting', 'https://www.instagram.com/'); 
                $linkedinLink   = get_theme_mod('gfjp_ec4_link_linkedin_setting'); 
                $googleLink     = get_theme_mod('gfjp_ec4_link_googlep_setting'); 
                $youtubeLink    = get_theme_mod('gfjp_ec4_link_youtube_setting');
                $shop_url       = wc_get_page_permalink( 'shop' );
            ?>
            <div class="main_header flex">
                <ul class="social_icons">
                    <?php if (!empty($instagramLink)) { ?>
                        <li><a href="<?php echo $instagramLink ?>"><span class="iconify" data-icon="bx:bxl-instagram" data-inline="false"></span></a></li>
                    <?php } ?>
                    <?php if (!empty($facebookLink)) { ?>
                        <li><a href="<?php echo $facebookLink ?>"><span class="iconify" data-icon="dashicons:facebook" data-inline="false"></span></a></li>
                    <?php } ?>
                    <?php if (!empty($twitterLink)) { ?>
                        <li><a href="<?php echo $twitterLink ?>"><span class="iconify" data-icon="bx:bxl-twitter" data-inline="false"></span></a></li>
                    <?php } ?>
                    <?php if (!empty($linkedinLink)) { ?>
                        <li><a href="<?php echo $linkedinLink ?>"><span class="iconify" data-icon="bx:bxl-linkedin-square" data-inline="false"></span></a></li>
                    <?php } ?>
                    <?php if (!empty($googleLink)) { ?>
                        <li><a href="<?php echo $googleLink ?>"><span class="iconify" data-icon="bx:bxl-google-plus" data-inline="false"></span></a></li>
                    <?php } ?>
                    <?php if (!empty($youtubeLink)) { ?>
                        <li><a href="<?php echo $youtubeLink ?>"><span class="iconify" data-icon="bx:bxl-youtube" data-inline="false"></span></a></li>
                    <?php } ?>
                </ul>
                <div class="header_logo">
                    <?php echo ( is_page( 'home' ) )? '<h1>': ''; ?>
                    <?php $header_desktop_logo_url = get_theme_mod( 'gfjp_ec4_header_desktop_logo_setting', GFJP_IMG_URL. '/logo.png' ); ?>
                    <a href="<?php echo home_url();?>" class="logo"><img class="logo-pc" src="<?php echo ( is_int( $header_desktop_logo_url ) )? wp_get_attachment_url( $header_desktop_logo_url ) : $header_desktop_logo_url ?>" alt="<?php echo get_bloginfo( 'name' );?>"></a>
                    <?php echo ( is_page( 'home' ) )? '</h1>': ''; ?>
                </div>
                <ul class="header_widgets uppercase opensans_bold">
                    <li class="header_search"><span class="iconify" data-icon="ant-design:search-outlined" data-inline="false"></span><span class="header_widget_lbl">Search</span></li>
                    <li class="header_login">
                        <?php if ( !is_user_logged_in() ) {?>
                            <a href="<?php echo home_url();?>/login"><span class="iconify" data-icon="clarity:user-line" data-inline="false"></span><span class="header_widget_lbl">Login</span></a>
                        <?php } else { ?>
                            <a href="<?php echo home_url(); ?>/my-account"><span class="iconify" data-icon="clarity:user-line" data-inline="false"></span><span class="header_widget_lbl">My Account</span></a>
                        <?php } ?>
                    </li>
                    <li class="header_cart"><a href="<?php echo home_url();?>/cart"><span class="iconify" data-icon="ant-design:shopping-cart-outlined" data-inline="false"></span></a><span class="header_widget_lbl cart_counts"><?php echo WC()->cart->get_cart_contents_count(); ?></span></li>
                </ul>
            </div>
            <nav class="main-menu aligncenter">
                <ul class="uppercase opensans_bold">
                    <li><a href="<?php echo home_url();?>" class="<?php echo ( is_page( 'home' ) )? 'active': ''; ?>">Home</a></li>
                    <li class="shop_megamenu">
                        <a href="#" class="<?php echo ( is_page( 'shop' ) )? 'active': ''; ?>">Shop</a>
                        <ul class="shop_sub_megamenu">
                            <?php 
                            $orderby = 'name';
                            $order = 'asc';
                            $hide_empty = false ;
                            $cat_args = array(
                                'orderby'    => $orderby,
                                'order'      => $order,
                                'hide_empty' => $hide_empty,
                                'exclude'    => array(),
                            );
                             
                            $product_categories = get_terms( 'product_cat', $cat_args );
                            $exclude = array('uncategorized');
                            
                            if( !empty($product_categories) ){
                                foreach ($product_categories as $key => $category) {
                                    if (!in_array($category->slug, $exclude)) {
                                        echo '<li>';
                                            echo '<a href="'.get_term_link($category).'" >';
                                                echo $category->name;
                                            echo '</a>';
                                        echo '</li>';
                                    }
                                }
                            }?>
                            <li><a href="<?php echo $shop_url;?>" class="<?php echo ( is_page( 'shop' ) )? 'active': ''; ?>">Shop All</a></li>
                        </ul>
                        
                        
                    </li>
                    <li class="normalcase"><a href="<?php echo home_url();?>/faq" class="<?php echo ( is_page( 'faq' ) )? 'active': ''; ?>">FAQs</a></li>
                    <li><a href="<?php echo home_url();?>/contact" class="<?php echo ( is_page( 'contact' ) )? 'active': ''; ?>">Contact</a></li>
                </ul>
            </nav>

            <div class="mobile_header">
                <div class="header_mobile_wrapper flex">
                    <ul class="header_widgets">
                        <li class="header_search"><span class="iconify" data-icon="ant-design:search-outlined" data-inline="false"></span></li>
                        <li class="header_login">
                            <?php if ( !is_user_logged_in() ) {?>
                                <a href="<?php echo home_url();?>/login"><span class="iconify" data-icon="clarity:user-line" data-inline="false"></span></a>
                            <?php } else { ?>
                                <a href="<?php echo wp_logout_url( home_url() ); ?>"><span class="iconify" data-icon="clarity:user-line" data-inline="false"></span></a>
                            <?php } ?>
                        </li>
                        <li class="header_cart"><a href="<?php echo home_url();?>/cart"><span class="iconify" data-icon="ant-design:shopping-cart-outlined" data-inline="false"></span></a></li>
                    </ul>
                    <div class="header_logo">
                        <?php $header_desktop_logo_url = get_theme_mod( 'gfjp_ec4_header_desktop_logo_setting', GFJP_IMG_URL. '/logo.png' ); ?>
                        <a href="<?php echo home_url();?>" class="logo"><img class="logo-pc" src="<?php echo ( is_int( $header_desktop_logo_url ) )? wp_get_attachment_url( $header_desktop_logo_url ) : $header_desktop_logo_url ?>" alt="<?php echo get_bloginfo( 'name' );?>"></a>
                    </div>
                    <div class="mobile_menu_header">
                        <div class="menu">
                            <span class="bar_1"></span>
                            <span class="bar_2"></span>
                            <span class="bar_3"></span>
                            <span class="bar_4"></span>
                        </div>
                    </div>
                </div>
                <div class="mobile_nav_header">
                    <nav class="mobile_main_menu aligncenter">
                        <ul class="uppercase opensans_bold">
                            <li><a href="<?php echo home_url();?>" class="<?php echo ( is_page( 'home' ) )? 'active': ''; ?>">Home</a></li>
                            <li class="shop_megamenu">
                                <a href="#">Shop</a>
                                <ul class="shop_sub_megamenu">
                                    <?php 
                                    $orderby = 'name';
                                    $order = 'asc';
                                    $hide_empty = false ;
                                    $cat_args = array(
                                        'orderby'    => $orderby,
                                        'order'      => $order,
                                        'hide_empty' => $hide_empty,
                                        'exclude'    => array(),
                                    );
                                     
                                    $product_categories = get_terms( 'product_cat', $cat_args );
                                    $exclude = array('uncategorized');
                                     
                                    if( !empty($product_categories) ){
                                        foreach ($product_categories as $key => $category) {
                                            if (!in_array($category->slug, $exclude)) {
                                                echo '<li>';
                                                    echo '<a href="'.get_term_link($category).'" >';
                                                        echo $category->name; 
                                                    echo '</a>';
                                                echo '</li>';
                                            }
                                        }
                                    }?>
                                    <li><a href="<?php echo $shop_url;?>" class="<?php echo ( is_page( 'shop' ) )? 'active': ''; ?>">Shop All</a></li>
                                </ul>
                            </li>
                            <li class="normalcase"><a href="<?php echo home_url();?>/faq" class="<?php echo ( is_page( 'faq' ) )? 'active': ''; ?>">FAQs</a></li>
                            <li><a href="<?php echo home_url();?>/contact" class="<?php echo ( is_page( 'contact' ) )? 'active': ''; ?>">Contact</a></li>
                        </ul>
                    </nav>
                    <ul class="social_icons">
                        <?php if (!empty($instagramLink)) { ?>
                            <li><a href="<?php echo $instagramLink ?>"><span class="iconify" data-icon="bx:bxl-instagram" data-inline="false"></span></a></li>
                        <?php } ?>
                        <?php if (!empty($facebookLink)) { ?>
                            <li><a href="<?php echo $facebookLink ?>"><span class="iconify" data-icon="dashicons:facebook" data-inline="false"></span></a></li>
                        <?php } ?>
                        <?php if (!empty($twitterLink)) { ?>
                            <li><a href="<?php echo $twitterLink ?>"><span class="iconify" data-icon="bx:bxl-twitter" data-inline="false"></span></a></li>
                        <?php } ?>
                        <?php if (!empty($linkedinLink)) { ?>
                            <li><a href="<?php echo $linkedinLink ?>"><span class="iconify" data-icon="bx:bxl-linkedin-square" data-inline="false"></span></a></li>
                        <?php } ?>
                        <?php if (!empty($googleLink)) { ?>
                            <li><a href="<?php echo $googleLink ?>"><span class="iconify" data-icon="bx:bxl-google-plus" data-inline="false"></span></a></li>
                        <?php } ?>
                        <?php if (!empty($youtubeLink)) { ?>
                            <li><a href="<?php echo $youtubeLink ?>"><span class="iconify" data-icon="bx:bxl-youtube" data-inline="false"></span></a></li>
                        <?php } ?>
                    </ul>
                </div>
            </div>

        </header>