<?php get_header(); ?>

	<main>

	<?php $default_banner = get_theme_mod( 'gfjp_ec4_gen_banner_background_setting', GFJP_IMG_URL. '/bg_banner.jpg' ); ?>
	<?php $reset_banner = get_theme_mod( 'gfjp_ec4_reset_banner_background_setting', $default_banner); ?>

	<?php if ($reset_banner !== '' ) { ?>
		<div class="inner_banner" style="background-image: url(<?php echo ( is_int( $reset_banner ) )? wp_get_attachment_url( $reset_banner ) : $reset_banner; ?>);"></div>
	<?php } else { ?>
		<div class="inner_banner" style="background-image: url(<?php echo ( is_int( $default_banner ) )? wp_get_attachment_url( $default_banner ) : $default_banner; ?>);"></div>
	<?php } ?>

		<div class="inner_content reset_content aligncenter reset_pword">

			<section class="maxwidth">
				<h1><?php echo get_theme_mod('gfjp_ec4_reset_title_setting','Reset account password')?></h1>
                <?php
                $errors = new WP_Error();
                $user = check_password_reset_key($_GET['key'], $_GET['login'], $_GET['email']);
                ?>
				<p class="form_sub_label">Enter a new password for <?php echo esc_attr( $_GET['email'] ); ?></p>
				
				<?php
				if ( is_wp_error( $user ) ) {
					if ( $user->get_error_code() === 'expired_key' )
						$errors->add( 'expiredkey', __( '<div id="message"><p>Sorry, that key has expired. Please try again.</p></div>' ) );
					else
						$errors->add( 'invalidkey', __( '<div id="message"><p>Sorry, that key does not appear to be valid.</p></div>' ) );
				}
				// display error message
				if ( $errors->get_error_code() )
					echo $errors->get_error_message( $errors->get_error_code() );
				?>
				
				<form id="resetPasswordForm" class="reset_pword_form" method="post" autocomplete="off">

					<div id="message"></div>

					<?php
					if ( function_exists( 'wp_nonce_field' ) ) 
						wp_nonce_field( 'rs_user_reset_password_action', 'rs_user_reset_password_nonce' );
					?>
					<input type="hidden" name="user_key" id="user_key" value="<?php echo esc_attr( $_GET['key'] ); ?>" autocomplete="off" />
					<input type="hidden" name="user_login" id="user_login" value="<?php echo esc_attr( $_GET['login'] ); ?>" autocomplete="off" />

					<div class="floating_label_wrap">
						<input type="password" name="pass1" id="pass1" class="new_pword floating_label_field input" value="" placeholder="Password" autocomplete="off" required>
						<label class="floating_label">New Password</label>
						<span class="iconify toggle_pword" data-toggle="#pass1" data-icon="carbon:view-filled" data-inline="false"></span>
					</div>

					<div class="floating_label_wrap">
						<input type="password" name="pass2" id="pass2" class="new_pword_confirm floating_label_field input" value="" placeholder="Password" autocomplete="off" required>
						<label class="floating_label">Confirm Password</label>
						<span class="iconify toggle_pword" data-toggle="#pass2" data-icon="carbon:view-filled" data-inline="false"></span>
					</div>

					<?php do_action( 'resetpass_form', $user ); ?>
					

					<input type="submit" name="wp-submit" id="wp-submit" class="btn_default uppercase" value="Reset Password" />
					<img src="<?php echo GFJP_IMG_URL ?>/ajax-loader.gif" id="preloader" alt="Preloader" />

				</form>

			</section>
		</div>
	</main>

<?php get_footer(); ?>