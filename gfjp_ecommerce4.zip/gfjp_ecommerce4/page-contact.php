<?php get_header(); ?>

		<main>

		<?php $default_banner = get_theme_mod( 'gfjp_ec4_gen_banner_background_setting', GFJP_IMG_URL. '/bg_banner.jpg' ); ?>
		<?php $contact_banner = get_theme_mod( 'gfjp_ec4_contact_banner_background_setting', $default_banner); ?>

		<?php if ($contact_banner !== '' ) { ?>
			<div class="inner_banner" style="background-image: url(<?php echo ( is_int( $contact_banner ) )? wp_get_attachment_url( $contact_banner ) : $contact_banner; ?>);"></div>
		<?php } else { ?>
			<div class="inner_banner" style="background-image: url(<?php echo ( is_int( $default_banner ) )? wp_get_attachment_url( $default_banner ) : $default_banner; ?>);"></div>
		<?php } ?>

			<div class="inner_content contact_content">
				<section class="maxwidth flex">
					<h1><?php echo get_theme_mod('gfjp_ec4_contact_title_setting','Contact us and say hello.') ?></h1>

					<form action="POST" id="contactForm" method="post" class="contact_form" enctype="multipart/form-data">

						<div class="success_msg " style="display: none">Message Sent Successfully</div>
						<div class="error_msg" style="display: none">Message Not Sent, There is some error.</div>

						<div class="floating_label_wrap">
							<input type="text" name="user_name" class="user_name floating_label_field" placeholder="Your name" required>
							<label class="floating_label">Your name</label>
						</div>
						
						<div class="floating_label_wrap">
							<input type="email" name="user_email" class="user_email floating_label_field" placeholder="Your mail" required>
							<label class="floating_label">Your mail</label>
						</div>

						<div class="floating_label_wrap">
							<textarea name="user_message" class="user_message floating_label_field" rows="10" placeholder="Message" required></textarea>
							<label class="floating_label">Message</label>
						</div>
						<input type="submit" class="btn_default uppercase" value="Send">

					</form>
				</section>
			</div>
		</main>

<?php get_footer(); ?>