<?php get_header(); 

global $wp_query;
$classes = get_body_class();

$prod_cat = is_product_category();
$class_cat = $prod_cat?'category_content':'';

// CATEGORY NAME BANNER
$shop_content = 'shop_category_content';

$cat = $wp_query->get_queried_object();
$thumbnail_id = get_term_meta ( $cat->term_id, 'thumbnail_id', true ); 
$temp_shop = GFJP_IMG_URL. '/bg_banner.jpg';
$catimage = $thumbnail_id?wp_get_attachment_url( $thumbnail_id ):$temp_shop; 
$theCount = $cat->count;

// BANNER IMAGES
$default_banner = get_theme_mod( 'gfjp_ec4_gen_banner_background_setting', GFJP_IMG_URL. '/bg_banner.jpg' ); 

$myaccount = in_array('woocommerce-account',$classes);
$class_account = $myaccount?'account_content':'';
$account_banner = get_theme_mod( 'gfjp_ec4_myaccount_banner_background_setting', $default_banner ); 

$checkout = in_array('woocommerce-checkout',$classes);
$class_checkout = $checkout?'checkout_content':'';
$checkout_banner = get_theme_mod( 'gfjp_ec4_checkout_banner_background_setting', $default_banner ); 

$cart = in_array('woocommerce-cart',$classes);
$class_cart = $cart?'cart_content':'';
$cart_banner = get_theme_mod( 'gfjp_ec4_cart_banner_background_setting', $default_banner ); 

?>

    <main role="main">
        <div class="inner_content <?php echo $class_cat, $class_account, $class_checkout, $class_cart?>">
            <?php
            /// PRODUCT CATEGORY BANNER AND TITLE 
            if ( $prod_cat ) { ?>
                <section class="shop_banner wrap_space  aligncenter" style="background-image: url('<?php echo $catimage?>')">
                    <h1 class="product_category_name"><?php echo the_title();?></h1>
                </section>
                <?php if ($theCount <= 0) {
                    echo '<div class="empty-content"><p class="aligncenter">No products found.</p></div>';
                } ?>
            <?php }
            
            /// MY ACCOUNT BANNER
            if ($myaccount) { ?>
                <?php if ($account_banner !== '' ) { ?>
                    <div class="inner_banner" style="background-image: url(<?php echo ( is_int( $account_banner ) )? wp_get_attachment_url( $account_banner ) : $account_banner; ?>);"></div>
                <?php } else { ?>
                    <div class="inner_banner" style="background-image: url(<?php echo ( is_int( $default_banner ) )? wp_get_attachment_url( $default_banner ) : $default_banner; ?>);"></div>
                <?php } ?>
            <?php } 

            /// CHECKOUT BANNER
            if ($checkout) { ?>
                <?php if ($checkout_banner !== '' ) { ?>
                    <div class="inner_banner" style="background-image: url(<?php echo ( is_int( $checkout_banner ) )? wp_get_attachment_url( $checkout_banner ) : $checkout_banner; ?>);"></div>
                <?php } else { ?>
                    <div class="inner_banner" style="background-image: url(<?php echo ( is_int( $default_banner ) )? wp_get_attachment_url( $default_banner ) : $default_banner; ?>);"></div>
                <?php } ?>
            <?php } 

            /// CART BANNER
            if ($cart) { ?>
                <?php if ($cart_banner !== '' ) { ?>
                    <div class="inner_banner" style="background-image: url(<?php echo ( is_int( $cart_banner ) )? wp_get_attachment_url( $cart_banner ) : $cart_banner; ?>);"></div>
                <?php } else { ?>
                    <div class="inner_banner" style="background-image: url(<?php echo ( is_int( $default_banner ) )? wp_get_attachment_url( $default_banner ) : $default_banner; ?>);"></div>
                <?php } ?>
            <?php } ?>

            <div class="maxwidth">
                <?php
                if ( have_posts() ) :
                    while ( have_posts() ) : the_post();
                        get_template_part( 'template-parts/content', get_post_type() );
                    endwhile;
                else : 
                    echo '<div class="empty-content"><p class="aligncenter">No content found.</p></div>';
                endif;
                ?>
            </div>
        </div>
    </main>

<?php get_footer();