<?php 

 	global $wpdb, $wp_hasher;

    $nonce = $_POST['nonce'];
    
    if ( ! wp_verify_nonce( $nonce, 'rs_user_lost_password_action' ) )
        die ( 'Security checked!');

    $user_login = $_POST['user_login'];

    $errors = new WP_Error();
 
    if ( empty( $user_login ) ) {
        $errors->add('empty_username', __('<p>Enter e-mail address.</p>'));
    } else if ( strpos( $user_login, '@' ) ) {
        $user_data = get_user_by( 'email', trim( $user_login ) );
        if ( empty( $user_data ) ) 
            $errors->add('invalid_email', __('<p class="no-reg-email">There is no user registered with that email address.</p>'));
    } else {
        $login = trim( $user_login );
        $user_data = get_user_by('login', $login);
    }

    do_action( 'lostpassword_post', $errors );

    if ( $errors->get_error_code() )
        //return $errors;
        echo ''. $errors->get_error_message( $errors->get_error_code() ) .'';
        //die();

    if ( !$user_data ) {
        $errors->add('invalidcombo', __('<p>Invalid username or email.</p>'));
        return $errors;
    }

    $user_login = $user_data->user_login;
    $user_email = $user_data->user_email;

    $key = get_password_reset_key( $user_data );
    
    if ( is_wp_error( $key ) ) {
        return $key;
    }

    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

    $message = "<html><body>";
    $message = "<div style='background-color:#fff; padding:25px 40px; max-width:645px; width:100%;'>
                    <h1>" .get_bloginfo( 'name' )."</h1>
                    <h2>Reset your password</h2>
                    <p>Follow this link to reset your customer account password at <a href=".network_home_url()." style='color:#1990c6; text-decoration: none;'>".get_bloginfo( 'name' )."</a>. If you didn't request a new password, you can safely delete this email.</p>
                    <p><a href=".network_home_url().'/reset-password/?action=rp&email='.$user_email.'&key='.$key.'&login='.rawurlencode($user_login)." style='color: #fff; background-color: #1990c6; display: inline-block; padding:20px 25px; border-radius:4px; text-decoration: none;'>Reset your password</a> or <a href=".network_home_url('/shop')." style='color:#1990c6; text-decoration: none;'>Visit our store</a></p>
                </div>";
    $message .= "</body></html>";
 
    if ( is_multisite() )
        $blogname = $GLOBALS['current_site']->site_name;
    else
        $blogname = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);
 
    $title = sprintf( __('[%s] Password Reset'), $blogname );
    $title = apply_filters( 'retrieve_password_title', $title, $user_login, $user_data );

    $message = apply_filters( 'retrieve_password_message', $message, $key, $user_login, $user_data );
    
    if ( wp_mail( $user_email, wp_specialchars_decode( $title ), $message, $headers ) )
        $errors->add('confirm', __('<p>Check your e-mail for the confirmation link.</p>'), 'message');
    else
        $errors->add('could_not_sent', __('<p>The e-mail could not be sent.') . "<br />\n" . __('Possible reason: your host may have disabled the mail() function.</p>'), 'message');
    
    if ( $errors->get_error_code() )
        echo ''. $errors->get_error_message( $errors->get_error_code() ) .'';
        
    die();

?>