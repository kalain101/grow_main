<?php

check_ajax_referer( 'gfjp_ec4-register-nonce', 'security' );

$admin_email   = get_bloginfo('admin_email');

$user_login    = $_POST["gfjp_ec4_user_login"];
$user_email    = $_POST["gfjp_ec4_email"];
$user_first    = $_POST["gfjp_ec4_fname"];
$user_last     = $_POST["gfjp_ec4_lname"];
$user_pass     = $_POST["gfjp_ec4_pword"];
$pass_confirm  = $_POST["gfjp_ec4_pword_confirm"];

// USER EMAIL
$usubject = 'Registration from '. get_home_url();
$umessage = 'Thank you for registering with '. get_bloginfo( 'name' ) .'. One of our colleagues will get back in touch with you soon! <br><br>Have a great day!';
$uheaders = array( 'From: '. get_bloginfo( 'name' ).' <'. $admin_email .'>', 'Content-Type: text/html; charset=UTF-8' );

// ADMIN EMAIL
$subject = 'New User Registration';
$message = 'Hi admin, '.$user_first.''.$user_last.' registered on your website, please check on your wp-dashboard admin to check the additional details.';
$headers = array( 'From: '. $user_first.' <'. $user_email .'>', 'Content-Type: text/html; charset=UTF-8' );

if(username_exists($user_login)) {
    echo json_encode( array( 'signup'=>false, 'message'=>__( '<p class="error_message">Username already taken.</p>' )));
}
else if(!validate_username($user_login)) {
    echo json_encode( array( 'signup'=>false, 'message'=>__( '<p class="error_message">Invalid username.</p>' )));
}
else if($user_login == '') {
    echo json_encode( array( 'signup'=>false, 'message'=>__( '<p class="error_message">Please enter a username.</p>' )));
}
else if(!is_email($user_email)) {
    echo json_encode( array( 'signup'=>false, 'message'=>__( '<p class="error_message">Invalid email.</p>' )));
}
else if(email_exists($user_email)) {
    echo json_encode( array( 'signup'=>false, 'message'=>__( '<p class="error_message">Email already registered.</p>' )));
}
else if($user_pass == '') {
    echo json_encode( array( 'signup'=>false, 'message'=>__( '<p class="error_message">Please enter a password.</p>' )));
}
else if($user_pass != $pass_confirm) {
    echo json_encode( array( 'signup'=>false, 'message'=>__( '<p class="error_message">Passwords do not match.</p>' )));
} 
else {
    $user_signup = wp_insert_user(array(
        'user_login'        => $user_login,
        'user_pass'         => $user_pass,
        'user_email'        => $user_email,
        'first_name'        => $user_first,
        'last_name'         => $user_last,
        'user_registered'   => date('Y-m-d H:i:s'),
        'role'              => 'subscriber'
    ) );

    wp_mail($admin_email, $subject, $message, $headers);
    wp_mail($user_email, $usubject, $umessage, $uheaders); 

    echo json_encode( array( 'signup'=>true, 'message'=>__('<p class="error_message">Registration Successfully</p>' )));
}
die();
    
?>