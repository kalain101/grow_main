<?php 

    check_ajax_referer( 'rs_user_reset_password_action', 'rs_user_reset_password_nonce' );
    
    $pass1  = $_POST['pass1'];
    $pass2  = $_POST['pass2'];
    $key    = $_POST['user_key'];
    $login  = $_POST['user_login'];
    
    $user = check_password_reset_key( $key, $login );
 
    if( empty( $pass1 ) || empty( $pass2 ) ) {
        echo json_encode( array( 'reset'=>false, 'message'=>__( '<p class="error_message">Password is required field.</p>' )));
    }
    else if ( $pass1 != $pass2 ) {
        echo json_encode( array( 'reset'=>false, 'message'=>__( '<p class="error_message">The passwords do not match.</p>' )));
    }
    else {
        reset_password($user, $pass1);
        echo json_encode( array( 'reset'=>true, 'message'=>__( '<p class="error_message">Your password has been reset.</p>' )));
    }
    
    die();

?>