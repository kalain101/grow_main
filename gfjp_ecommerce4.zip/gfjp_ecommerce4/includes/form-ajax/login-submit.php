<?php 

    check_ajax_referer( 'ajax-login-nonce', 'security' );

    $info = array();
    $info['user_login'] = $_POST['username'];
    $info['user_password'] = $_POST['password'];
    $info['remember'] = true;
    $user_signon = wp_signon( $info, false );

    if ( is_wp_error( $user_signon )) {
        echo json_encode( array( 'loggedin'=>false, 'message'=>__( '<p class="error_message">Incorrect email or password.</p>' )));
    } else {
        echo json_encode( array( 'loggedin'=>true, 'message'=>__('<p class="error_message">Login successful, redirecting...</p>' )));
        wp_signon( $info, true );
    }
    die();

?>