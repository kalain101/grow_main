<?php

$adminEmail = get_bloginfo('admin_email');

$user_email     = $_POST['list_email'];
$user_message   = $_POST["email_message"];
$emails_hidden  = $_POST["emails_hidden"];
$user_subject   = $_POST["emails_subject"];

$umessage = htmlentities(stripslashes($user_message));
$gmessage = html_entity_decode($umessage);

//$group_emails = explode(',', $emails_hidden);
//$uheaders = array( 'From: '. get_bloginfo( 'name' ).' <'. $adminEmail .'>', 'Content-Type: text/html; charset=UTF-8' );

$uheaders1 = array( 'From: '. get_bloginfo( 'name' ).' <'. $adminEmail .'>', 'Bcc:'. $emails_hidden .'', 'Content-Type: text/html; charset=UTF-8' );

wp_mail('', $user_subject, $gmessage, $uheaders1);