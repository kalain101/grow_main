<?php

check_ajax_referer( 'ajax-newsletter-nonce', 'newsletter_security' );


$emailTo          = get_bloginfo( 'admin_email' );
$newsletter_email = $_POST['newsletter_email'];
$user_subject     = 'Newsletter Submission';


$subject  = $user_subject;
$message  = 'Hi admin, someone subscribe to your website with the email '.$newsletter_email.'. Please check the email on your dashboard for the confirmation. <br> Thank you!';
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";


$usubject = 'Message confirmation from '. get_home_url();
$umessage = '<div style="background-color: #ececec; width: 100%; height: 100%; padding: 50px 20px;">
<div style="max-width: 600px; width: 100%; background-color: #ff6846; padding: 20px; margin: 0 auto; text-align: center; color: #fff; font-size: 30px;">Welcome</div>
<div style="max-width: 600px; width: 100%; background-color: #fff; padding: 40px 20px; margin: 0 auto; text-align: center;">Thanks for subscribing to our newsletter.<br>Have a great day!</div>
<div style="max-width: 600px; width: 100%; background-color: #d3bb7a; padding: 10px 20px; margin: 0 auto; text-align: center; color: #fff; font-size: 14px;">'. get_bloginfo( 'name' ).' - '. date("Y") .'</div>
</div>';
$uheaders = array( 'From: '. get_bloginfo( 'name' ).' <'. $emailTo .'>', 'Content-Type: text/html; charset=UTF-8' );

$new_post = array(
   'post_title'    => $newsletter_email,
   'post_status'   => 'publish',
   'post_type'     => 'newsletter-email'
);

if(post_exists( $newsletter_email,'','','newsletter-email')) {
    echo json_encode( array( 'newsletter'=>false, 'message'=>__( '<p class="error_message">Email already taken.</p>' )));
}
else {
    $pid = wp_insert_post($new_post);

    echo json_encode( array( 'newsletter'=>false, 'message'=>__( '<p class="error_message">Email successfully added.</p>' )));

    wp_mail($emailTo, $subject, $message, $headers);
    wp_mail($newsletter_email, $usubject, $umessage, $uheaders); 
}


die();

?>