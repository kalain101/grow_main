<?php
$emailTo = get_bloginfo('admin_email');
$user_name     = $_POST['user_name'];
$user_email    = $_POST['user_email'];
$user_message  = $_POST['user_message'];
$user_subject  = 'Contact Form Submission';

$subject = $user_subject;
$message = $user_message? $_POST['user_message'] .' <br><br> - '. $user_name. '<br>' . $user_name: 'Message is empty';
$headers = array( 'From: '. $user_name.' <'. $user_email .'>', 'Content-Type: text/html; charset=UTF-8' );

$usubject = 'Message confirmation from '. get_home_url();
$umessage = 'Thank you for getting in touch! <br><br>We appreciate you contacting us '. get_bloginfo( 'name' ) .'. One of our colleagues will get back in touch with you soon! <br><br>Have a great day!';
$uheaders = array( 'From: '. get_bloginfo( 'name' ).' <'. $emailTo .'>', 'Content-Type: text/html; charset=UTF-8' );

wp_mail($emailTo, $subject, $message, $headers);
wp_mail($user_email, $usubject, $umessage, $uheaders); 

die();