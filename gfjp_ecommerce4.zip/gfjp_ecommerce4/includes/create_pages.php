<?php

//  Create the homepage
add_action( 'init', 'create_home_page' );
function create_home_page(){

    if( is_null( get_page_by_path( 'home' ) ) ){
        $post_details   = array(
            'post_title'    => 'Home',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
            'post_name'     => 'home'
        );
        wp_insert_post( $post_details );

        //  Set the home page as homepage
        $home = get_page_by_path( 'home' );
        update_option( 'page_on_front', $home->ID );
        update_option( 'show_on_front', 'page' );
    }
}

//  Create the contact page
add_action( 'init', 'create_contact_page' );
function create_contact_page(){

    if( is_null( get_page_by_path( 'contact' ) ) ){
        $post_details = array(
            'post_title'    => 'Contact',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
            'post_name'     => 'contact'
        );
        wp_insert_post( $post_details );
    }
}

//  Create the faq page
add_action( 'init', 'create_faq_page' );
function create_faq_page(){

    if( is_null( get_page_by_path( 'faq' ) ) ){
        $post_details = array(
            'post_title'    => 'FAQ',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
            'post_name'     => 'faq'
        );
        wp_insert_post( $post_details );
    }
}

//  Create the privacy page
add_action( 'init', 'create_privacy_page' );
function create_privacy_page(){

    if( is_null( get_page_by_path( 'privacy-policy' ) ) ){
        $post_details = array(
            'post_title'    => 'Privacy Policy',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
            'post_name'     => 'privacy-policy'
        );
        wp_insert_post( $post_details );
    }
}

//  Create the login page
add_action( 'init', 'create_login_page' );
function create_login_page(){

    if( is_null( get_page_by_path( 'login' ) ) ){
        $post_details = array(
            'post_title'    => 'Login',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
            'post_name'     => 'login'
        );
        wp_insert_post( $post_details );
    }
}

//  Create the signup page
add_action( 'init', 'create_signup_page' );
function create_signup_page(){

    if( is_null( get_page_by_path( 'signup' ) ) ){
        $post_details = array(
            'post_title'    => 'Signup',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
            'post_name'     => 'signup'
        );
        wp_insert_post( $post_details );
    }
}

//  Create the forgot pword page
add_action( 'init', 'create_forgot_pword_page' );
function create_forgot_pword_page(){

    if( is_null( get_page_by_path( 'forgot-password' ) ) ){
        $post_details = array(
            'post_title'    => 'Forgot Password',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
            'post_name'     => 'forgot-password'
        );
        wp_insert_post( $post_details );
    }
}

//  Create the reset pword page
add_action( 'init', 'create_reset_pword_page' );
function create_reset_pword_page(){

    if( is_null( get_page_by_path( 'reset-password' ) ) ){
        $post_details = array(
            'post_title'    => 'Reset Password',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
            'post_name'     => 'reset-password'
        );
        wp_insert_post( $post_details );
    }
}

//  Create the shop page
add_action( 'init', 'create_shop_page' );
function create_shop_page(){

    if( is_null( get_page_by_path( 'shop' ) ) ){
        $post_details = array(
            'post_title'    => 'Shop',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_type'     => 'page',
            'post_name'     => 'shop'
        );
        wp_insert_post( $post_details );
    }
}