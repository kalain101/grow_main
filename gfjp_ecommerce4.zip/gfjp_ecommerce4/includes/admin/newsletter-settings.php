<?php
function gfjp_ec4_newsletter_admin_menu() {
    add_menu_page(
        __( 'Newsletter page', 'gfjp_ec4_newsletter' ),
        __( 'Newsletter', 'gfjp_ec4_newsletter' ),
        'manage_options', 
        'newsletter', 
        'gfjp_ec4_newsletter_admin_page_contents', 
        'dashicons-edit'
    );
    add_submenu_page( 
        'newsletter', 
        __('Registered Emails Page',  'gfjp_ec4_newsletter' ),
        __('Registered Emails', 'gfjp_ec4_newsletter' ),
        'manage_options', 
        '/edit.php?post_type=newsletter-email',
        false
    );
    remove_menu_page( 'edit.php?post_type=newsletter-email' );
}
add_action( 'admin_menu', 'gfjp_ec4_newsletter_admin_menu' );

function gfjp_ec4_newsletter_admin_page_contents() { ?>
    <h1> <?php esc_html_e( 'Newsletter Settings', 'gfjp_ec4_newsletter_textdomain' ); ?> </h1>
    <form method="POST" action="options.php">
        <?php
        settings_fields( 'newsletter' );
        do_settings_sections( 'newsletter' );
        submit_button();
        ?>
    </form>
    <div class="admin-email-lists">
        <?php 
        $query_args = array(
            'post_type'      => 'newsletter-email',
            'posts_per_page' => -1,
        );
        $the_query = new WP_Query( $query_args );
        
        if ( $the_query->have_posts() ) : 
            global $wp_query;
            $total_posts = $wp_query->post_count;
            $i=0;
            while ( $the_query->have_posts() ) : $the_query->the_post(); 
                $output .= '"'.get_the_title().'",';
                $output2 .= ''.get_the_title().',';
                $i++;
            endwhile; 
            if($i != $total_posts) {
                $output .= '';
                $output2 .= '';
            } 
 
            $content = get_option('newsletter_content', '<html><body><div style="background-color: #ececec; width: 100%; height: 100%; padding: 50px 20px;">
            <div style="max-width: 600px; width: 100%; background-color: #ff6846; padding: 20px; margin: 0 auto; text-align: center; color: #fff; font-size: 30px;">Welcome</div>
            <div style="max-width: 600px; width: 100%; background-color: #fff; padding: 40px 20px; margin: 0 auto; text-align: center;">Thanks for subscribing to our newsletter.</div>
            <div style="max-width: 600px; width: 100%; background-color: #d3bb7a; padding: 10px 20px; margin: 0 auto; text-align: center; color: #fff; font-size: 14px;">'. get_bloginfo( 'name' ).' - '. date("Y") .'</div>
            </div></html></body>');
            $email_subject = get_option('newsletter_subject','Updates Newsletter');
            ?>
            <h3>Send Email</h3>
            <form name="send-email" id="adminNewsletter" method="post" enctype="multipart/form-data">
                <div class="dropdown-menu-list scroller">
                    <div class="form-group">    
                        <h4>Recipients:</h4>
                        <div class="input-group input-group-md">
                            <input type='text' id='list_email' placeholder="Add email here..." name='list_email' class='form-control' value='[<?php echo rtrim($output, ',');?>]'>
                            <span class="input-group-btn">
                                <button class="btn red" type="button"><span class="dashicons dashicons-plus"></span></button>
                            </span>
                        </div>

                        <input type='hidden' name='emails_hidden' id='emails_hidden' value='<?php echo rtrim($output2, ',');?>'>
                        <input type='hidden' name='email_message' id='email_message' value='<?php echo $content;?>'>
                        <input type='hidden' name='emails_subject' id='emails_subject' value='<?php echo $email_subject;?>'>

                        <p class="error_msg" style="display:none;">Something went wrong...</p>
                        <p class="success_msg" style="display:none;">Email successfully sent...</p>
                        <input type="submit" name="submit" id="send" class="button button-primary" value="Send Email">
                    </div>
                </div>
            </form>
            <?php
        else:
            echo "no email";
            endif; 
        ?>
    </div>
    <?php
}


function gfjp_ec4_newsletter_init() {
    add_settings_section(
        'gfjp_ec4_newsletter_setting_section', __( '', 'gfjp_ec4_newsletter' ),
        'gfjp_ec4_newsletter_setting_section_callback_function',
        'newsletter'
    );
    add_settings_field(
       'newsletter_subject', __( 'Subscriber subject field settings', 'gfjp_ec4_newsletter' ),
       'gfjp_ec4_newsletter_setting_subject',
       'newsletter',
       'gfjp_ec4_newsletter_setting_section'
    );
    add_settings_field(
       'newsletter_content', __( 'Subscriber email layout setting field', 'gfjp_ec4_newsletter' ),
       'gfjp_ec4_newsletter_setting_markup',
       'newsletter',
       'gfjp_ec4_newsletter_setting_section'
    );
    register_setting( 'newsletter', 'newsletter_content' );
    register_setting( 'newsletter', 'newsletter_subject' );
}
add_action( 'admin_init', 'gfjp_ec4_newsletter_init' );


function gfjp_ec4_newsletter_setting_subject() { 
    ?>
        <input type="text" id="newsletter_subject" name="newsletter_subject" value="<?php echo get_option( 'newsletter_subject', 'Updates Newsletter' ); ?>">
    <?php
}

function gfjp_ec4_newsletter_setting_markup() {
    $content = get_option('newsletter_content', '<div style="background-color: #ececec; width: 100%; height: 100%; padding: 50px 20px;">
<div style="max-width: 600px; width: 100%; background-color: #ff6846; padding: 20px; margin: 0 auto; text-align: center; color: #fff; font-size: 30px;">Welcome</div>
<div style="max-width: 600px; width: 100%; background-color: #fff; padding: 40px 20px; margin: 0 auto; text-align: center;">Thanks for subscribing to our newsletter.</div>
<div style="max-width: 600px; width: 100%; background-color: #d3bb7a; padding: 10px 20px; margin: 0 auto; text-align: center; color: #fff; font-size: 14px;">'. get_bloginfo( 'name' ).' - '. date("Y") .'</div>
</div>');

    wp_editor( $content, 'newslettercontent', 
        $settings = array(
            'textarea_rows'  => '20', 
            'textarea_name'  => 'newsletter_content'
        ) );
    
}

function gfjp_ec4_newsletter_setting_section_callback_function() { }

function gfjp_ec4_menu_active_newsletter() {
    global $parent_file, $post_type;
    if ( $post_type == 'newsletter-email' ) {
        $parent_file = 'newsletter';
    }
}
add_action( 'admin_head', 'gfjp_ec4_menu_active_newsletter' );


function gfjp_ec4_remove_row_actions( $actions ) {
    if( get_post_type() === 'newsletter-email' )
        unset( $actions['view'] );
    return $actions;
}
add_filter( 'post_row_actions', 'gfjp_ec4_remove_row_actions', 10, 1 );


/* 
    TITLE PLACEHOLDER
-------------------------------- */
function gfjp_ec4_title_text( $title ){
     $screen = get_current_screen();
     if  ( 'newsletter-email' == $screen->post_type ) {
          $title = 'Email Address';
     }
     return $title;
}
add_filter( 'enter_title_here', 'gfjp_ec4_title_text' );