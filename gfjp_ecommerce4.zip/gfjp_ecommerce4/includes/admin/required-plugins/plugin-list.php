<?php

add_action( 'tgmpa_register', 'gfjp_ec4_register_required_plugins', 5 );

function gfjp_ec4_register_required_plugins() {

	$plugins = array(
		array(
			'name'	=> 'Woocommerce',
			'slug'	=> 'woocommerce',
			'required'	=> true,
			'force_activation'	=> true,
		),
	);

	$config = array(
		'id'           	=> 'gfjp',
		'default_path' 	=> '',
		'menu'         	=> 'gfjp-install-plugins',
		'has_notices'  	=> true,
		'dismissable'  	=> true,
		'dismiss_msg'  	=> '',
		'is_automatic' 	=> false,
		'message'      	=> sprintf( '<h4>%s</h4>', __( 'Grow Forward JP Ecommerce Template 4 Theme requires the following plugins below. Make sure to activate the required plugins, else the front end will show some errors or missing sections.' ) ),
		'parent_slug'	=> 'gfjp',
	);

	$plugins = apply_filters( 'gfjp_ec4_register_required_plugins', $plugins );
	
	tgmpa( $plugins, $config );
}