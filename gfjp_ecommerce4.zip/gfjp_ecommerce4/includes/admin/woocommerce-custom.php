<?php

/* 
    WOOCOMMERCE ACTIONS
-------------------------------- */
remove_action( 'woocommerce_before_shop_loop' , 'woocommerce_result_count', 20 );
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );


/*
    My Account Menu Hooks
--------------------------------------------------------------*/
function gfjp_ec4_account_menu_items( $items ) {
    $items = array(
        'orders'             => __( 'Order History', 'woocommerce' ),
        'edit-address'       => __( 'My Addresses', 'woocommerce' ),
        'edit-account'       => __( 'Account Details', 'woocommerce' ),
        'customer-logout'    => __( 'Log out', 'woocommerce' ),
    );
    return $items;
}
add_filter( 'woocommerce_account_menu_items', 'gfjp_ec4_account_menu_items' );


/*
   Auto Update Cart on Quantity
--------------------------------------------------------------*/
function gfjp_ec4_cart_refresh_update_qty() {
    if (is_cart()) {
        ?>
        <script type="text/javascript">
            jQuery('div.woocommerce').on('change', 'input.qty', function(){
                jQuery("[name='update_cart']").trigger("click");
            });
        </script>
        <?php
    }
}
add_action( 'wp_footer', 'gfjp_ec4_cart_refresh_update_qty' ); 

/*
    Billing Address Fields
--------------------------------------------------------------*/
function gfjp_ec4_address_checkout_fields( $address_fields ) {
    $address_fields['first_name']['placeholder']    = 'First Name';
    $address_fields['last_name']['placeholder']     = 'First Name';
    $address_fields['company']['placeholder']       = 'Company Name';
    $address_fields['city']['placeholder']          = 'Town / City';
    $address_fields['postcode']['placeholder']      = 'Postcode';
    return $address_fields;
}
add_filter('woocommerce_default_address_fields', 'gfjp_ec4_address_checkout_fields', 20, 1);

function gfjp_ec4_billing_checkout_fields( $fields ) {
    $fields['billing']['billing_phone']['placeholder']  = 'Phone';
    $fields['billing']['billing_phone']['label']        = 'Contact Number';
    $fields['billing']['billing_email']['placeholder']  = 'Email Address';
    return $fields;
}
add_filter( 'woocommerce_checkout_fields' , 'gfjp_ec4_billing_checkout_fields', 20, 1 );


function gfjp_ec4_override_billing_fields( $fields ) {
    $fields['billing_phone']['placeholder'] = 'Phone Number';
    $fields['billing_email']['placeholder'] = 'Email';
    return $fields;
}
add_filter( 'woocommerce_billing_fields' , 'gfjp_ec4_override_billing_fields' );


/*
    Additional Custom Product Data Tab
--------------------------------------------------------------*/

function gfjp_ec4_custom_product_data_tab( $product_data_tabs ) {
    $product_data_tabs['additonal-info-tab'] = array(
        'label' => __( 'Additional Info', 'GFJP_ECOMMERCE4' ),
        'target' => 'additional_information',
    );
    return $product_data_tabs;
}
add_filter( 'woocommerce_product_data_tabs', 'gfjp_ec4_custom_product_data_tab' );


function gfjp_ec4_custom_product_data_fields() {
    global $woocommerce, $post;
    ?>
    <div id="additional_information" class="panel woocommerce_options_panel">
        <?php
        $args = array(
            'id'          => 'addition_info_1',
            'label'       => __( 'Additional Information 1', 'GFJP_ECOMMERCE4' ),
            'class'       => 'gfjp-custom-field',
            'desc_tip'    => false,
            'description' => '',
        );
        woocommerce_wp_textarea_input( $args );

        $args = array(
            'id'          => 'addition_info_2',
            'label'       => __( 'Additional Information 2', 'GFJP_ECOMMERCE4' ),
            'class'       => 'gfjp-custom-field',
            'desc_tip'    => false,
            'description' => '',
        );
        woocommerce_wp_textarea_input( $args );
        ?>
    </div>
    <?php
}
add_action( 'woocommerce_product_data_panels', 'gfjp_ec4_custom_product_data_fields' );

/*
    Saves the custom field data to product meta data
--------------------------------------------------------------*/
function gfjp_ec4_save_custom_field( $post_id ) {

    $product_info = wc_get_product( $post_id );

    $info_1 = isset( $_POST['addition_info_1'] ) ? $_POST['addition_info_1'] : '';
    $info_2 = isset( $_POST['addition_info_2'] ) ? $_POST['addition_info_2'] : '';

    $product_info->update_meta_data( 'addition_info_1', sanitize_text_field( $info_1 ) );
    $product_info->update_meta_data( 'addition_info_2', sanitize_text_field( $info_2 ) );

    $product_info->save();
    
}
add_action( 'woocommerce_process_product_meta', 'gfjp_ec4_save_custom_field' );


// AUTO UPDATE QUANTITY CART - HEADER
function gfjp_ec4_add_to_cart_fragments( $fragments ) {
    $fragments['span.header_widget_lbl.cart_counts'] = '<span class="header_widget_lbl cart_counts">' . WC()->cart->get_cart_contents_count() . '</span>';
    return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'gfjp_ec4_add_to_cart_fragments', 10, 1 );


// REMOVE PASSWORD STRENGTH
function gfjp_ec4_remove_password_strength() {
if ( wp_script_is( 'wc-password-strength-meter', 'enqueued' ) ) {
    wp_dequeue_script( 'wc-password-strength-meter' );
  }
} 
add_action( 'wp_print_scripts', 'gfjp_ec4_remove_password_strength', 100 );


// LOGOUT REDIRECTION
function gfjp_ec4_logout_redirect() {
  wp_redirect( home_url() );
  exit;
}
add_action('wp_logout','gfjp_ec4_logout_redirect');


/*---------------------------------------------*/
// CUSTOM META BOX
/*---------------------------------------------*/

function gfjp_ec4_featured_meta() {
    add_meta_box( 'gfjp_ec4_meta', __( 'Customer’s Favorite', GFJP_ECOMMERCE4 ), 'gfjp_ec4_meta_callback', 'product', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'gfjp_ec4_featured_meta' );


// Outputs the content of the meta box
function gfjp_ec4_meta_callback( $post ) {
    wp_nonce_field( basename( __FILE__ ), 'gfjp_ec4_nonce' );
    $gfjp_ec4_stored_meta = get_post_meta( $post->ID ); ?>

    <div class="gfjp_ec4-row-content">
        <label for="featured-prod">
            <input type="checkbox" name="featured-prod" id="featured-prod" value="yes" <?php if ( isset ( $gfjp_ec4_stored_meta['featured-prod'] ) ) checked( $gfjp_ec4_stored_meta['featured-prod'][0], 'yes' ); ?> />
            <?php _e( 'Display on Customer’s Favorite?', GFJP_ECOMMERCE4 )?>
        </label>
    </div>  
    <?php
}

// Saves the custom meta input
function gfjp_ec4_meta_save( $post_id ) {

    // Checks save status - overcome autosave, etc.
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'gfjp_ec4_nonce' ] ) && wp_verify_nonce( $_POST[ 'gfjp_ec4_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

    // Exits script depending on save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }
    // Checks for input and saves - save checked as yes and unchecked at no
    if( isset( $_POST[ 'featured-prod' ] ) ) {
        update_post_meta( $post_id, 'featured-prod', 'yes' );
    } else {
        update_post_meta( $post_id, 'featured-prod', 'no' );
    }
}
add_action( 'save_post', 'gfjp_ec4_meta_save' );

/*----------------------------------------------*/


add_filter( 'manage_edit-product_columns', 'bbloomer_admin_products_visibility_column', 9999 );
 
function bbloomer_admin_products_visibility_column( $columns ){
   $columns['visibility'] = 'Favorites';
   return $columns;
}
 
add_action( 'manage_product_posts_custom_column', 'bbloomer_admin_products_visibility_column_content', 10, 2 );
 
function bbloomer_admin_products_visibility_column_content( $column, $product_id ){
    if ( $column == 'visibility' ) {
        $product = wc_get_product( $product_id );
        echo get_post_meta( $product->get_id(), 'featured-prod', true );
    }
}