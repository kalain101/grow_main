<?php

class gfjp_temp3_FAQ_Post_Type {

    function __construct() {
        add_action( 'init', array( $this, 'gfjp_temp3_create_faq_post_type' ) );
        //add_action( 'init', array( $this, 'books_register_ref_page' ) );
    }

    function gfjp_temp3_create_faq_post_type(){

        if( !post_type_exists( 'faqs' ) ){

        $labels = array(
            'name'               => 'FAQs',
            'singular_name'      => 'FAQ',
            'add_new'            => 'Add New FAQ',
            'all_items'          => 'All FAQs',
            'add_new_item'       => 'Add New FAQs Item',
            'edit_item'          => 'Edit A FAQ',
            'new_item'           => 'New FAQ',
            'view_item'          => 'View FAQ',
            'search_item'        => 'Search FAQ',
            'not_found'          => 'No Items Found in This',
            'not_found_in_trash' => 'No items found in Trash',
            'parent_item_column' => 'Parent Item'
        );
        
        $args = array(
            'labels'             => $labels,
            'public'             => TRUE,
            'has_archive'        => TRUE,
            'publicly_queryable' => TRUE,
            'query_var'          => TRUE,
            'rewrite'            => TRUE,
            'capability'         => 'page',
            'heirarchical'       => FALSE,
            'supports'           => array(
                'title',
                'editor',
                'author',
                'excerpt',
                //'thumbnail'
            ),
            'exclude_from_search' => TRUE
        );

        register_post_type( 'faqs', $args );
        }
    }

}
new gfjp_temp3_FAQ_Post_Type;