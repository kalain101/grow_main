<?php
function gfjp_ec4_privacy_admin_menu() {
    add_menu_page(
        __( 'Privacy Policy page', 'gfjp_ec4_policy' ),
        __( 'Privacy Policy', 'gfjp_ec4_policy' ),
        'manage_options', 
        'privacy-policy', 
        'gfjp_ec4_privacy_admin_page_contents', 
        'dashicons-edit'
    );
}
add_action( 'admin_menu', 'gfjp_ec4_privacy_admin_menu' );

function gfjp_ec4_privacy_admin_page_contents() { ?>
    <h1> <?php esc_html_e( 'Privacy Policy Page Settings', 'gfjp_ec4_policy_textdomain' ); ?> </h1>
    <form method="POST" action="options.php">
        <?php
        settings_fields( 'privacy-policy' );
        do_settings_sections( 'privacy-policy' );
        submit_button();
        ?>
    </form>
    <?php
}

function gfjp_ec4_privacy_settings_init() {
    add_settings_section(
        'gfjp_ec4_privacy_page_setting_section', __( '', 'gfjp_ec4_policy' ),
        'gfjp_ec4_policy_setting_section_callback_function',
        'privacy-policy'
    );
    add_settings_field(
       'privacy_content', __( 'Privacy Policy setting field', 'gfjp_ec4_policy' ),
       'gfjp_ec4_privacy_setting_markup',
       'privacy-policy',
       'gfjp_ec4_privacy_page_setting_section'
    );
    register_setting( 'privacy-policy', 'privacy_content' );
}
add_action( 'admin_init', 'gfjp_ec4_privacy_settings_init' );

function gfjp_ec4_policy_setting_section_callback_function() {
    echo '<p>Please insert your Privacy Policy content below. You may update it to your own content and make sure you save changes made.</p>';
}

function gfjp_ec4_privacy_setting_markup() {
    $content = get_option('privacy_content', '<p>Effective date: June 20, 2020</p>
    <p>This page informs you of our policies regarding the collection, use, disclosure of personal data when you use our Service and the choices you have associated with that data.</p>
    <br>

        <section>
            <h2>Information Collection and Use</h2>
            <p>We collect several different types of information for various purposes to provide and improve our Service to you.</p>

            <section>
                <h3>Types of Data Collected</h3>

                <section>
                    <h4>Personal Data</h4>
                    <p>While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you (“Personal Data”). Personally identifiable information may include, but is not limited to:</p>
                    <ul>
                        <li>Email Address</li>
                        <li>First name and last name</li>
                        <li>Phone Number</li>
                        <li>Address, State, Province, ZIP/Postal code, City</li>
                        <li>Cookies and Usage Data</li>
                    </ul>

                    <h4>Usage Data</h4>
                    <p>This may include information such as your computer’s Internet Protocol address (e.g. IP address), browser type, browser version, the pages of our Service that you visit, the time and date of your visit, the time spent on those pages, unique device identifiers and other diagnostic data.</p>

                    <h4>Tracking & Cookies Data</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ipsum rhoncus maecenas orci, mi. Imperdiet sed orci lobortis ut tristique nunc at fermentum nulla. Mauris sit nam cursus tellus mi pharetra. Gravida dignissim ultricies bibendum ac aliquam in elit, lobortis nibh.</p>
                    <p>Feugiat magna a proin libero, elit metus, iaculis turpis viverra. Odio nec enim leo arcu, amet praesent ut feugiat donec. Risus augue sagittis vitae, nulla scelerisque. Sed diam neque vel tempus. Magna est nibh nibh cras.</p>
                </section>
            </section>
        </section>
        
        <section>
            <h2>How We Use Your Information</h2>
            <p>Nunc volutpat, leo, leo interdum tristique porttitor fames. Odio nec facilisi aenean diam quisque sed. In vitae odio donec scelerisque in. Morbi condimentum consectetur sem platea neque, nisl, nulla. Malesuada nunc tincidunt eu, tellus in porta magna bibendum hendrerit. Elementum ac mattis pellentesque amet, in. Donec dignissim mattis montes, leo libero, massa mauris. Nisi, vel nibh volutpat in tincidunt elementum sed pellentesque. Tempor, sit arcu pellentesque viverra. Aliquam molestie arcu pharetra consectetur. Nec vel aliquet mauris maecenas aliquet rutrum. Tellus cursus quam tempus scelerisque diam ac egestas semper porta. Mauris facilisi ut ut in elementum sociis lectus.</p>
        </section>

        <section>
            <h2>Links To Other Sites</h2>
            <p>Nascetur malesuada ac proin elementum feugiat. Urna non velit purus quis massa bibendum urna lorem eu. Pulvinar odio lacinia vulputate ullamcorper.</p>
            <p>Pharetra dolor nunc vel lobortis sed nec eget. Maecenas scelerisque orci, sed vitae.</p>
        </section>

        <section>
            <h2>Changes To This Privacy Policy</h2>
            <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.</p>
            <p>Nibh nullam diam enim odio. Adipiscing at a praesent vitae a pharetra sed morbi condimentum.</p>
            <p>Vehicula nascetur sed vitae nunc sed neque sodales. Odio scelerisque elit pharetra sit. Etiam ultrices in lobortis id vel, scelerisque. Sem varius lectus nunc lorem eu a.</p>
        </section>

        <section>
            <h2>Contact Us</h2>
            <p>If you have any questions about this Privacy Policy, please contact us:</p>
            <ul>
                <li>By email: info@beautylab.com</li>
                <li>By phone number: 09123456789</li>
            </ul>
        </section>');
    wp_editor( $content, 'privacycontent', 
        $settings = array(
            'textarea_rows'  => '20', 
            'textarea_name'  => 'privacy_content'
        ) );
}