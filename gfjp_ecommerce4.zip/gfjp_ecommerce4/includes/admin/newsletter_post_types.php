<?php

class gfjp_ec4_Newsletter_Email_Post_Type {

    function __construct() {
        add_action( 'init', array( $this, 'gfjp_ec4_create_newsletter_post_type' ) );
    }

    function gfjp_ec4_create_newsletter_post_type(){

        if( !post_type_exists( 'newsletter-email' ) ){

        $labels = array(
            'name'               => 'Newsletter Email',
            'singular_name'      => 'Newsletter Email',
            'add_new'            => 'Add New Email',
            'all_items'          => 'All Email',
            'add_new_item'       => 'Add New Email Item',
            'edit_item'          => 'Edit Email',
            'new_item'           => 'New Email',
            'view_item'          => 'View Email',
            'search_item'        => 'Search Email',
            'not_found'          => 'No Items Found in This',
            'not_found_in_trash' => 'No items found in Trash',
            'parent_item_column' => 'Parent Item'
        );
        
        $args = array(
            'labels'             => $labels,
            'public'             => FALSE,
            'show_ui'            => TRUE,
            'has_archive'        => TRUE,
            'publicly_queryable' => TRUE,
            'query_var'          => TRUE,
            'rewrite'            => TRUE,
            'capability'         => 'page',
            'heirarchical'       => FALSE,
            'supports'           => array(
                'title',
            ),
            'exclude_from_search' => TRUE,
            'capability_type'     => 'post',
            'capabilities'        => array(
                'create_posts' => 'do_not_allow', // false < WP 4.5, credit @Ewout
            ),
            'map_meta_cap'        => array(
                'edit_post'    => FALSE,
                'delete_post'  => TRUE
            ),
        );

        register_post_type( 'newsletter-email', $args );
        }
    }

}
new gfjp_ec4_Newsletter_Email_Post_Type;