<?php get_header(); ?>

		<main>

		<?php $default_banner = get_theme_mod( 'gfjp_ec4_gen_banner_background_setting', GFJP_IMG_URL. '/bg_banner.jpg' ); ?>
		<?php $faq_banner = get_theme_mod( 'gfjp_ec4_faq_banner_background_setting', $default_banner ); ?>

		<?php if ($faq_banner !== '' ) { ?>
			<div class="inner_banner" style="background-image: url(<?php echo ( is_int( $faq_banner ) )? wp_get_attachment_url( $faq_banner ) : $faq_banner; ?>);"></div>
		<?php } else {?>
			<div class="inner_banner" style="background-image: url(<?php echo ( is_int( $default_banner ) )? wp_get_attachment_url( $default_banner ) : $default_banner; ?>);"></div>
		<?php } ?>

			<div class="inner_content faq_content">
				<section class="maxwidth ">
					<h1 class="aligncenter"><?php echo get_theme_mod('gfjp_ec4_faq_title_setting','Common Queries')?></h1>	
					<?php $faq_layout = get_theme_mod( 'gfjp_ec4_faq_layout_setting', 'standard-layout' );?>
					<!-- FAQ STANDARD -->
					<?php if ( $faq_layout == 'standard-layout' ) { ?>
						<ul class="faq_lists">
							<?php
			                $faq_list_args = array(
			                    'post_per_page' => -1,
			                    'post_type' 	=> 'faqs'
			                );
			                $faq_list_query = new WP_Query( $faq_list_args );

			                if( $faq_list_query->have_posts() ){
			                    while( $faq_list_query->have_posts() ){
			                    $faq_list_query->the_post(); ?>
									<li>
										<p class="faq_question bright_red_txt alegreya_regular"><?php echo get_the_title();?></p>
										<div class="faq_answer">
											<?php echo wpautop(get_the_content());?>
										</div>
									</li>
			                        <?php
			                    }
			                    wp_reset_postdata();
			                } else {
			                    echo '<p class="aligncenter">No FAQ found...</p>';
			                }
				            ?>
						</ul>
					<!-- FAQ DROPDOWN -->
					<?php } if ( $faq_layout == 'dropdown-layout' ) { ?>
						<ul class="faq_lists faq_accordion">
									<?php
			                $faq_list_args = array(
			                    'post_per_page' => -1,
			                    'post_type' 	=> 'faqs'
			                );
			                $faq_list_query = new WP_Query( $faq_list_args );
			                if( $faq_list_query->have_posts() ){
			                    while( $faq_list_query->have_posts() ){
			                    $faq_list_query->the_post(); ?>
									<li>
										<p class="faq_question bright_red_txt alegreya_regular"><span class="faq_inner_question"><?php echo get_the_title();?></span><span class="iconify" data-icon="bx:bx-chevron-down" data-inline="false"></span></p>
										<div class="faq_answer">
											<?php echo wpautop(get_the_content());?>
										</div>
									</li>
			                        <?php
			                    }
			                    wp_reset_postdata();
			                } else {
			                    echo '<p class="aligncenter">No FAQ found...</p>';
			                }
			            ?>
						</ul>
					<?php } ?>
				</section>
			</div>
		</main>

<?php get_footer(); ?>