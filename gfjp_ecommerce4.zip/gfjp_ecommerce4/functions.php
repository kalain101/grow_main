<?php

define( 'GFJP_ECOMMERCE4',  'Grow Forward JP Ecommerce Template 4' );
define( 'CUSTOMIZER_REPEATER_VERSION', '1.1.0' );

define( 'GFJP_DIR', get_template_directory() );
define( 'GFJP_INC_DIR', GFJP_DIR . '/includes' );
define( 'GFJP_CUSTOMIZER_DIR', GFJP_DIR . '/customizer' );
define( 'GFJP_CLASS_DIR', GFJP_DIR . '/class' );

define( 'GFJP_URL', get_template_directory_uri() );
define( 'GFJP_COMMON_URL', GFJP_URL . '/common' );
define( 'GFJP_JS_URL', GFJP_COMMON_URL . '/js' );
define( 'GFJP_CSS_URL', GFJP_COMMON_URL . '/css' );
define( 'GFJP_IMG_URL', GFJP_COMMON_URL . '/images' );

define( 'GFJP_ADMIN_DIR', GFJP_INC_DIR . '/admin' );
define( 'GFJP_TEMPLATES_DIR',  GFJP_DIR . '/templates' );

/* 
    INCLUDE TEMPLATES 
-------------------------------- */
include_once ( GFJP_CUSTOMIZER_DIR . '/add_customizer.php' );
include_once ( GFJP_INC_DIR . '/create_pages.php' );

// USER RESTRICTIONS
include_once ( GFJP_INC_DIR . '/create_client_admin.php' );
include_once ( GFJP_INC_DIR . '/minor_admin_access_restriction.php' );

// ADMIN SIDE AND OTHER SETTINGS
include_once ( GFJP_ADMIN_DIR . '/faq_post_types.php' );
include_once ( GFJP_ADMIN_DIR . '/newsletter_post_types.php' );
include_once ( GFJP_ADMIN_DIR . '/newsletter-settings.php' );
include_once ( GFJP_ADMIN_DIR . '/woocommerce-custom.php' );
include_once ( GFJP_ADMIN_DIR . '/privacy_policy_settings.php' );
include_once ( GFJP_ADMIN_DIR . '/required-plugins/class-tgm-plugin-activation.php' );
include_once ( GFJP_ADMIN_DIR . '/required-plugins/plugin-list.php' );

/* 
    ENQUEUE FRONTEND SCRIPTS AND STYLES 
-------------------------------------- */
function gfjp_ec4_add_theme_scripts(){
  
wp_enqueue_style( 'style_css_style', GFJP_URL . '/style.css' );
wp_enqueue_style( 'common_style', GFJP_CSS_URL . '/common.css' );

    wp_enqueue_script( 'jquery_script', GFJP_JS_URL .'/jquery-3.4.1.min.js', NULL, 1.1, true );
    wp_enqueue_script( 'iconify_script', GFJP_JS_URL .'/iconify.min.js', array ( 'jquery' ), 1.1, true );
    wp_enqueue_script( 'common_script', GFJP_JS_URL .'/common.js', array ( 'jquery' ), 1.1, true );

    if( is_page( 'home' ) ){
        wp_enqueue_style( 'home_style', GFJP_CSS_URL . '/home.css' );
        wp_enqueue_style( 'slick_style', GFJP_CSS_URL . '/slick.css' );
        wp_enqueue_style( 'slick_theme_style', GFJP_CSS_URL . '/slick-theme.css' );
        
        wp_enqueue_script( 'slick_min_script', GFJP_JS_URL .'/slick.min.js', array ( 'jquery' ), 1.1, true );
        wp_enqueue_script( 'home_script', GFJP_JS_URL .'/home.js', array ( 'jquery' ), 1.1, true );
        
        wp_enqueue_script( 'newsletter_submit', GFJP_JS_URL . '/newsletter-submit.js', array( 'jquery' ), '1.0', false );
        wp_localize_script( 'newsletter_submit', 'ajax_object_newsletter', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ), 'lettermessage' => __('<p class="error_message">Validating email address...</p>')
        ));
    }
    if( is_page( 'contact' ) ){
        wp_enqueue_style( 'contact_style', GFJP_CSS_URL . '/contact.css' );

        wp_enqueue_script( 'form_submit', GFJP_JS_URL . '/contact-submit.js', array( 'jquery' ), '1.0', false );
        wp_localize_script( 'form_submit', 'ajax_object_contact', array('ajax_url' => admin_url( 'admin-ajax.php' ) ) );
    }
    if( is_page( 'faq' ) ){
        wp_enqueue_style( 'faq_style', GFJP_CSS_URL . '/faq.css' );
        wp_enqueue_script( 'faq_script', GFJP_JS_URL .'/faq.js', array ( 'jquery' ), 1.1, true );
    }
    if( is_page( 'privacy-policy' ) ){
        wp_enqueue_style( 'privacy_style', GFJP_CSS_URL . '/privacy.css' );
    }
    if( is_page( 'login' ) ){
        wp_enqueue_style( 'login_style', GFJP_CSS_URL . '/login.css' );

        wp_register_script('ajax_login_script', GFJP_JS_URL.'/ajax-login-script.js', array('jquery'), 1.1, true ); 
        wp_enqueue_script('ajax_login_script');
        wp_localize_script( 'ajax_login_script', 'ajax_login_object', array( 
            'ajaxurl' => admin_url( 'admin-ajax.php' ), 'redirecturl' => home_url(), 'loadingmessage' => __('<p class="error_message">Validating email address...</p>')
        ));
    }
    if( is_page( 'signup' ) ){
        wp_enqueue_style( 'signup_style', GFJP_CSS_URL . '/signup.css' );

        wp_register_script('ajax_signup_script', GFJP_JS_URL.'/ajax-signup-script.js', array('jquery'), 1.1, true ); 
        wp_enqueue_script('ajax_signup_script');
        wp_localize_script( 'ajax_signup_script', 'ajax_signup_object', array( 
            'ajaxurl' => admin_url( 'admin-ajax.php' ), 'redirecturl' => home_url('/login'), 'loadingmessage' => __('<p class="error_message">Validating entries...</p>')
        ));
    }
    if( is_page( array('forgot-password' , 'reset-password') ) ){
        wp_enqueue_style( 'forgot_pword_style', GFJP_CSS_URL . '/reset_pword.css' );
        wp_enqueue_script( 'recaptcha-script', 'https://www.google.com/recaptcha/api.js', array( 'jquery' ) );

        wp_enqueue_script( 'rsclean-request-script', GFJP_JS_URL. '/reset-ajax.js', array( 'jquery' ) );
        wp_localize_script( 'rsclean-request-script', 'theme_ajax', array(
            'url'               => admin_url( 'admin-ajax.php' ), 
            'site_url'          => get_bloginfo('url'), 
            'theme_url'         => get_bloginfo('template_directory'), 
            'redirecturl'       => home_url('/login'), 
            'loadingmessage'    => __('<p class="error_message">Validating entries...</p>')
        ) );
    }
    if( is_page( 'shop' ) || is_product_category() ){
        wp_enqueue_style( 'shop_style', GFJP_CSS_URL . '/shop.css' );
    }
    if( is_page( 'cart' ) ){
        wp_enqueue_style( 'cart_style', GFJP_CSS_URL . '/cart.css' );
    }
    if( is_singular( 'product' ) ){
        wp_enqueue_style( 'single_product_style', GFJP_CSS_URL . '/single_product.css' );
        wp_enqueue_script( 'single_product_script', GFJP_JS_URL .'/single_product.js', array ( 'jquery' ), 1.1, true );
        wp_enqueue_script( 'blockUI_script', GFJP_JS_URL .'/jquery.blockUI.min.js', array ( 'jquery' ), 1.1, true );

        wp_enqueue_style( 'cart_style', GFJP_CSS_URL . '/cart-popup.css' );

        $data = array( 'home_urls' => __( home_url() ) );
        wp_localize_script( 'single_product_script', 'object_name', $data );
    }

    $classes = get_body_class();
    if (in_array('woocommerce-account',$classes)) {
        wp_enqueue_style( 'account_style', GFJP_CSS_URL . '/myaccount.css' );
        wp_enqueue_script( 'account_script', GFJP_JS_URL .'/myaccount.js', array ( 'jquery' ), 1.1, true );
    }
    if (in_array('woocommerce-checkout',$classes)) {
        wp_enqueue_style( 'checkout_style', GFJP_CSS_URL . '/checkout.css' );
        wp_enqueue_script( 'checkout_script', GFJP_JS_URL .'/checkout.js', array ( 'jquery' ), 1.1, true );
    }
    if (in_array('woocommerce-cart',$classes)) {
        wp_enqueue_style( 'cart_style', GFJP_CSS_URL . '/cart.css' );
    }
    if (in_array('woocommerce-edit-address',$classes)) {
        wp_enqueue_style( 'address_style', GFJP_CSS_URL . '/myaddress.css' );
        wp_enqueue_script( 'account_script', GFJP_JS_URL .'/myaccount.js', array ( 'jquery' ), 1.1, true );
    }
    if (in_array('woocommerce-edit-account',$classes)) {
        wp_enqueue_style( 'edit_account_style', GFJP_CSS_URL . '/edit_account.css' );
    }
    
}
add_action( 'wp_enqueue_scripts', 'gfjp_ec4_add_theme_scripts' );


/*
    ADMIN ENQUEUE
-------------------------------- */
function gfjp_ec4_admin_script($hook_suffix){
    wp_enqueue_script('custom_admin_script', GFJP_JS_URL.'/admin/admin-custom-script.js', array('jquery'), 1.1, true ); 
    wp_enqueue_style( 'privacy_admin_style', GFJP_CSS_URL . '/admin/privacy_policy.css' );

    if($hook_suffix == 'toplevel_page_newsletter') {
        wp_enqueue_style( 'newsletter_admin_style', GFJP_CSS_URL . '/admin/newsletter-style.css' );

        wp_enqueue_script('newsletter_admin_script', GFJP_JS_URL.'/admin/newsletter-script.js', array('jquery'), 1.1, true ); 
        wp_enqueue_script('latest_admin_script', GFJP_JS_URL.'/admin/jquery-latest.min.js', array('jquery'), 1.1, true ); 

        wp_localize_script( 'latest_admin_script', 'ajax_object_email', array('ajax_url' => admin_url( 'admin-ajax.php' ) ) );
    }
}
add_action( 'admin_enqueue_scripts', 'gfjp_ec4_admin_script' );


/*
    ADD THEME SUPPORT 
-------------------------------- */
function gfjp_ec4_theme_support(){
    add_theme_support( 'post-thumbnails' );
}
add_action( 'init', 'gfjp_ec4_theme_support' );

add_image_size( 'home_category_size', 540, 350, true );
add_filter( 'use_block_editor_for_post', '__return_false' );


/* 
    AJAX LOGIN
-------------------------------- */
function gfjp_ec4_ajax_login() {
    require_once ( GFJP_INC_DIR . '/form-ajax/login-submit.php' );  
}
add_action( 'wp_ajax_nopriv_ajaxlogin', 'gfjp_ec4_ajax_login' );

/* 
    AJAX REGISTRATION
-------------------------------- */
function gfjp_ec4_ajax_signup() {
    require_once ( GFJP_INC_DIR . '/form-ajax/signup-submit.php' );  
}
add_action( 'wp_ajax_nopriv_ajaxsignup', 'gfjp_ec4_ajax_signup' );
add_action( 'wp_ajax_ajaxsignup', 'gfjp_ec4_ajax_signup' );

/* 
    AJAX RESET PASS
-------------------------------- */
function gfjp_ec4_lost_pass_callback() {
    require_once ( GFJP_INC_DIR . '/form-ajax/forgot-pword-submit.php' );  
}
add_action( 'wp_ajax_nopriv_lost_pass', 'gfjp_ec4_lost_pass_callback' );
add_action( 'wp_ajax_lost_pass', 'gfjp_ec4_lost_pass_callback' );

function gfjp_ec4_reset_pass_callback() {
    require_once ( GFJP_INC_DIR . '/form-ajax/reset-pword-submit.php' ); 
}
add_action( 'wp_ajax_nopriv_reset_pass', 'gfjp_ec4_reset_pass_callback' );
add_action( 'wp_ajax_reset_pass', 'gfjp_ec4_reset_pass_callback' );

/* 
    AJAX CONTACT
-------------------------------- */
function gfjp_ec4_set_contact_form(){
    require_once ( GFJP_INC_DIR . '/form-ajax/contact-submit.php' );  
}
add_action( 'wp_ajax_set_form', 'gfjp_ec4_set_contact_form' );   
add_action( 'wp_ajax_nopriv_set_form', 'gfjp_ec4_set_contact_form'); 

/* 
    AJAX NEWSLETTER
-------------------------------- */
function gfjp_ec4_set_newsletter_form(){
    require_once ( GFJP_INC_DIR . '/form-ajax/newsletter-submit.php' );  
}
add_action( 'wp_ajax_set_newsletter_form', 'gfjp_ec4_set_newsletter_form' );   
add_action( 'wp_ajax_nopriv_set_newsletter_form', 'gfjp_ec4_set_newsletter_form'); 

/* 
    AJAX EMAIL
-------------------------------- */
function gfjp_ec4_set_email_form(){ 
    require_once ( GFJP_INC_DIR . '/form-ajax/newsletter-admin_email.php' );  
}
add_action( 'wp_ajax_set_email_form', 'gfjp_ec4_set_email_form' );   
add_action( 'wp_ajax_nopriv_set_email_form', 'gfjp_ec4_set_email_form'); 