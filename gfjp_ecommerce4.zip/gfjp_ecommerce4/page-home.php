<?php get_header(); ?>

	<main>
		<?php $homepage_banner = get_theme_mod( 'gfjp_ec4_homepage_banner_background_setting', GFJP_IMG_URL. '/bg_banner.jpg' );  ?>
		<section class="home_banner wrap_space"  style="background-image: url(<?php echo ( is_int( $homepage_banner ) )? wp_get_attachment_url( $homepage_banner ) : $homepage_banner; ?>);">
			<h2><?php echo get_theme_mod('gfjp_ec4_home_banner_headline_setting','Pure & Natural <br>Organic Beauty')?></h2>
			<p class="italic_font"><?php echo get_theme_mod('gfjp_ec4_home_banner_description_setting','Lorem ipsum dolor sit amet, consectetur adipiscing elit.')?></p>
		</section>

		<?php $homepage_layout = get_theme_mod( 'gfjp_ec4_home_layout_setting', 'layout-1' );

		if ( $homepage_layout == 'layout-1' ) {
			include (GFJP_TEMPLATES_DIR.'/layout/home-layout1.php');
		} if ( $homepage_layout == 'layout-2' ) { 
			include (GFJP_TEMPLATES_DIR.'/layout/home-layout2.php');
		} ?>

		<?php $last_layout = get_theme_mod( 'gfjp_ec4_home_lastlayout_setting', 'newsletter-layout' );?>

		<?php if ( $last_layout == 'newsletter-layout' ) {?>

			<?php $newsletter_img = get_theme_mod( 'gfjp_ec4_home_newsletter_img_setting', GFJP_IMG_URL. '/home/bg_newsletter.png' );?>
			<section class="newsletter aligncenter" style="background-image: url('<?php echo ( is_int( $newsletter_img ) )? wp_get_attachment_url( $newsletter_img ) : $newsletter_img; ?>')">
				<div class="maxwidth">
					<h2><?php echo get_theme_mod('gfjp_ec4_home_newsletter_title_setting','Join our newsletter')?></h2>
					<p class="italic_font"><?php echo get_theme_mod('gfjp_ec4_home_newsletter_desc_setting','Subscribe to get special offers, and exclusive deals.')?></p>
					<form id="newsletter_form" method="post">
						<input type="email" id="newsletter_email" name="newsletter_email" placeholder="E-mail Address" required>
						<input type="submit" value="Subscribe" id="newsletter_submit">

						<div class="success_msg " style="display: none">Email Sent Successfully</div>
						<div class="error_msg" style="display: none">Email Not Sent, There is some error.</div>

						<div class="newsletter_msg"></div>
						<?php wp_nonce_field( 'ajax-newsletter-nonce', 'newsletter_security' ); ?>
					</form>
					
				</div>
			</section>

		<?php } if ( $last_layout == 'carousel-layout' ) { ?>

        <div class="carousel_images">

            <ul class="carousel_images_list">
                <?php
                $customizer_repeater_slider = get_theme_mod('customizer_repeater_slider', json_encode( array(
                    array("image_url" => GFJP_IMG_URL.'/home/bg_slide1.jpg' ,"link" => "#", "id" => "customizer_repeater_56d7ea7f40f56" ), 
                    array("image_url" => GFJP_IMG_URL.'/home/bg_slide2.jpg' ,"link" => "#", "id" => "customizer_repeater_56d7ea7f40f57" ),
                    array("image_url" => GFJP_IMG_URL.'/home/bg_slide3.jpg' ,"link" => "#", "id" => "customizer_repeater_56d7ea7f40f58" ),
                )));
                $customizer_repeater_slider_decoded = json_decode($customizer_repeater_slider);
                foreach($customizer_repeater_slider_decoded as $repeater_item){
                    ?><li><img src="<?php echo $repeater_item->image_url; ?>" alt=""></li><?php
                } ?>
            </ul>

        </div>

		<?php } ?>
	</main>

<?php get_footer(); ?>